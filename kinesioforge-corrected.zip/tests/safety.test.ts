import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const sourceRoot=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'kinesio-safety-'));
process.chdir(temp);
const {GeminiService}=await import('../src/server/geminiService');
const {ComfyUiService,comfyUiService}=await import('../src/server/comfyUiService');
const {geminiService}=await import('../src/server/geminiService');
const {pipelineManager}=await import('../src/server/pipelineManager');
const {exportService}=await import('../src/server/exportService');
const {default:JSZip}=await import('jszip');
const {default:sharp}=await import('sharp');
const original=structuredClone(pipelineManager.getAllExercises()[0]);
const file=path.join(temp,'public/storage/test.png');fs.mkdirSync(path.dirname(file),{recursive:true});
const image=await sharp({create:{width:256,height:256,channels:3,background:'#456789'}}).png().toBuffer();
function exercise(seed=false){
 const e=structuredClone(original);e.phases=e.phases.slice(0,1);e.totalPhases=1;
 const p=e.phases[0];p.outputPath='storage/test.png';p.provenance.type=seed?'PROGRAMMATIC_SEED':'GENERATED_AI_VERIFIED';p.provenance.isSeeded=seed;fs.writeFileSync(file,image);return e;
}
test.after(()=>{process.chdir(sourceRoot);fs.rmSync(temp,{recursive:true,force:true});});
test('Fresh Gemini service does not invent an eleven-hour quota failure',()=>assert.equal(new GeminiService().isQuotaExhausted(),false));
test('Connectivity alone does not claim GPU or VRAM optimization',async(t)=>{
 t.mock.method(globalThis,'fetch',async(url:any)=>new Response(JSON.stringify(String(url).endsWith('/system_stats')?{devices:[{name:'CPU'}]}:{}),{status:200}));
 const r=await new ComfyUiService().checkConnectivity();assert.equal(r.online,true);assert.equal(r.device,'CPU');assert.equal(r.vramOptimized,false);
});
test('Sofia export excludes seed fixtures by default',async(t)=>{
 t.mock.method(pipelineManager,'getAllExercises',()=>[exercise(true)]);
 t.mock.method(comfyUiService,'checkConnectivity',async()=>({online:false,serverUrl:'http://127.0.0.1:8188',vramOptimized:false,availableCheckpoints:[]}));
 t.mock.method(geminiService,'checkStatus',async()=>({available:false,model:'fixture'}));
 const z=await JSZip.loadAsync(await exportService.createSofiaBundle());assert.equal(Object.keys(z.files).filter(n=>n.endsWith('.webp')).length,0);
});
test('Sofia export hashes the actual converted WebP bytes',async(t)=>{
 t.mock.method(pipelineManager,'getAllExercises',()=>[exercise()]);
 t.mock.method(comfyUiService,'checkConnectivity',async()=>({online:false,serverUrl:'http://127.0.0.1:8188',vramOptimized:false,availableCheckpoints:[]}));
 t.mock.method(geminiService,'checkStatus',async()=>({available:false,model:'fixture'}));
 const z=await JSZip.loadAsync(await exportService.createSofiaBundle());const index=JSON.parse(await z.file('exercise-images.json')!.async('string'));const p=Object.values(index)[0] as any;const row=p.phases[1];const b=await z.file(row.imagePath)!.async('nodebuffer');
 const {createHash}=await import('node:crypto');assert.equal(row.checksum,createHash('sha256').update(b).digest('hex'));assert.equal((await sharp(b).metadata()).format,'webp');
});
test('Failed conversion cannot relabel corrupt input as WebP',async(t)=>{
 const e=exercise();fs.writeFileSync(file,'not an image');
 t.mock.method(pipelineManager,'getAllExercises',()=>[e]);
 t.mock.method(comfyUiService,'checkConnectivity',async()=>({online:false,serverUrl:'http://127.0.0.1:8188',vramOptimized:false,availableCheckpoints:[]}));
 t.mock.method(geminiService,'checkStatus',async()=>({available:false,model:'fixture'}));
 await assert.rejects(()=>exportService.createSofiaBundle());
});
test('Sofia intake preserves exact supplied phase prompts instead of generic defaults',async()=>{
 const {sofiaCatalogService}=await import('../src/server/sofiaCatalogService');
 const id='sofia-safety-exact-prompts';
 const phases=Array.from({length:4},(_,i)=>({phaseNumber:i+1,title:'Exact phase '+(i+1),promptText:'AUTHORITATIVE SOFIA POSE '+(i+1)}));
 sofiaCatalogService.commitSofiaCatalog([{id,name:'Safety exercise',phases}]);
 const ex=pipelineManager.getExerciseById(id)!;
 assert.deepEqual(ex.phases.map(p=>p.fullPrompt),phases.map(p=>p.promptText));
 ex.phases[0].humanReview.status='approved';ex.phases[0].outputPath='storage/approved.png';
 sofiaCatalogService.commitSofiaCatalog([{id,name:'Safety exercise',phases:phases.map(p=>({...p,promptText:'REPLACEMENT'}))}]);
 assert.equal(ex.phases[0].fullPrompt,phases[0].promptText,'Existing reviewed content cannot be silently reassigned');
});
test('Checkpoint selection preserves completed jobs and updates only resumable jobs',async()=>{
 const {productionQueue}=await import('../src/server/productionQueue');
 const jobs=productionQueue.getJobs();jobs[0].status='completed';jobs[0].modelTarget='preserved-model';jobs[1].status='queued';
 productionQueue.setCheckpoint('actual-installed-filename.safetensors');
 assert.equal(jobs[0].modelTarget,'preserved-model');assert.equal(jobs[1].modelTarget,'actual-installed-filename.safetensors');
});
test('Catalog merge refuses to discard an existing image phase',()=>{
 const e=pipelineManager.getAllExercises().find(e=>e.totalPhases===6)!;e.phases[5].outputPath='storage/preserved.png';
 assert.throws(()=>pipelineManager.addOrMergeExercise({id:e.id,english_name:e.english_name,totalPhases:5}),/Cannot remove/);
 assert.equal(e.phases.length,6);
});
