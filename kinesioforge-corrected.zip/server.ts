import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { pipelineManager } from './src/server/pipelineManager';
import { comfyUiService } from './src/server/comfyUiService';
import { geminiService } from './src/server/geminiService';
import { exportService } from './src/server/exportService';
import { runAutomatedPipelineTests } from './src/server/testRunner';
import { productionQueue } from './src/server/productionQueue';
import { athleteManager } from './src/server/athleteProfiles';
import { sofiaCatalogService } from './src/server/sofiaCatalogService';
import { windowsStarterKitService } from './src/server/windowsStarterKit';
import { WORKFLOW_TEMPLATES, checkWorkflowCompatibility } from './src/server/workflowLibrary';

dotenv.config({ path: ['.env.local', '.env'] });

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve stored exercise images and fixtures
app.use('/storage', express.static(path.resolve(process.cwd(), 'public/storage')));
app.use(express.static(path.resolve(process.cwd(), 'public')));

// API Routes

// 1. Diagnostics & Integrity Status
app.get('/api/status', async (_req, res) => {
  try {
    const comfyStatus = await comfyUiService.checkConnectivity();
    const geminiStatus = await geminiService.checkStatus();
    const stats = pipelineManager.getIntegrityStats(
      {
        online: comfyStatus.online,
        url: comfyStatus.serverUrl,
        message: comfyStatus.error || 'Connected to ComfyUI',
        vramOptimized: comfyStatus.vramOptimized,
      },
      geminiStatus
    );
    res.json({ success: true, stats, comfyStatus, geminiStatus });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 2. All 11 Exercises & 64 Phases
app.get('/api/exercises', (_req, res) => {
  try {
    const exercises = pipelineManager.getAllExercises();
    res.json({ success: true, count: exercises.length, exercises });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/exercises/:id', (req, res) => {
  try {
    const ex = pipelineManager.getExerciseById(req.params.id);
    if (!ex) {
      return res.status(404).json({ success: false, error: 'Exercise not found' });
    }
    res.json({ success: true, exercise: ex });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 3. Trigger Real Generation
app.post('/api/exercises/:exerciseId/phases/:phaseNumber/generate', async (req, res) => {
  const { exerciseId, phaseNumber } = req.params;
  const pNum = parseInt(phaseNumber, 10);
  const { provider = 'gemini', checkpoint } = req.body;

  const phase = pipelineManager.getPhase(exerciseId, pNum);
  if (!phase) {
    return res.status(404).json({ success: false, error: 'Phase not found' });
  }

  phase.jobStatus = 'generating';

  try {
    if (provider === 'comfyui') {
      const result = await comfyUiService.executeGeneration(phase.fullPrompt, checkpoint);
      const updatedPhase = pipelineManager.registerGeneratedImage(
        exerciseId,
        pNum,
        result.buffer,
        'comfyui',
        checkpoint || 'sdxl-base-1.0',
        result.promptId
      );
      return res.json({ success: true, phase: updatedPhase });
    } else {
      // Gemini provider
      const result = await geminiService.generateImage(phase.fullPrompt);
      const updatedPhase = pipelineManager.registerGeneratedImage(
        exerciseId,
        pNum,
        result.buffer,
        'gemini',
        result.modelUsed
      );
      return res.json({ success: true, phase: updatedPhase });
    }
  } catch (err: any) {
    phase.jobStatus = 'failed';
    phase.errorMessage = err.message || 'Generation failed';
    pipelineManager.saveState();

    return res.status(500).json({
      success: false,
      error: err.message,
      phase,
    });
  }
});

// 4. Vision-based Biomechanical QC
app.post('/api/exercises/:exerciseId/phases/:phaseNumber/qc', async (req, res) => {
  const { exerciseId, phaseNumber } = req.params;
  const pNum = parseInt(phaseNumber, 10);

  const phase = pipelineManager.getPhase(exerciseId, pNum);
  if (!phase || !phase.outputPath) {
    return res.status(404).json({
      success: false,
      error: 'Cannot perform QC: No image binary exists for this phase.',
    });
  }

  const fullPath = path.resolve(process.cwd(), 'public', phase.outputPath);
  if (!fs.existsSync(fullPath)) {
    return res.status(404).json({ success: false, error: 'Image file missing on disk.' });
  }

  try {
    const buffer = fs.readFileSync(fullPath);
    const qc = await geminiService.performBiomechanicalQC(
      buffer,
      phase.exerciseName,
      phase.phaseNumber,
      phase.fullPrompt
    );

    // Also verify duplicate frame detection
    if (phase.imageChecksum) {
      const stats = pipelineManager.getIntegrityStats(
        { online: false, url: '', message: '', vramOptimized: false },
        { available: false, model: '' }
      );
      const dup = stats.duplicateDetections.find((d) => d.hash === phase.imageChecksum);
      if (dup && dup.phases.length > 1) {
        qc.isDuplicate = true;
        qc.duplicateOfPhaseId = dup.phases.find((p) => p.phaseId !== phase.id)?.phaseId;
        qc.overallStatus = 'failed';
        if (!qc.detectedIssues.some((i) => i.includes('Duplicate'))) {
          qc.detectedIssues.unshift(
            `Duplicate binary: Identical SHA-256 matches ${qc.duplicateOfPhaseId}`
          );
        }
      }
    }

    phase.qcReport = qc;
    pipelineManager.saveState();

    res.json({ success: true, qcReport: qc });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 5. Human Review Approval / Rejection
app.post('/api/exercises/:exerciseId/phases/:phaseNumber/review', (req, res) => {
  const { exerciseId, phaseNumber } = req.params;
  const pNum = parseInt(phaseNumber, 10);
  const { status, notes, reviewer } = req.body;

  if (!['pending', 'approved', 'rejected', 'needs_regeneration'].includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid review status.' });
  }

  const phase = pipelineManager.updatePhaseReview(exerciseId, pNum, status, notes, reviewer);
  if (!phase) {
    return res.status(404).json({ success: false, error: 'Phase not found.' });
  }

  res.json({ success: true, phase });
});

// 6. ComfyUI Configuration & Test
app.post('/api/comfyui/test', async (req, res) => {
  const { serverUrl } = req.body;
  if (serverUrl) {
    comfyUiService.setServerUrl(serverUrl);
  }
  const result = await comfyUiService.checkConnectivity();
  res.json({ success: true, result });
});

// 7. Automated Test Suite (Tests A-H)
app.get('/api/tests/run', async (_req, res) => {
  try {
    const report = await runAutomatedPipelineTests();
    res.json({ success: true, report });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 8. Re-audit Disk Assets
app.post('/api/audit', (_req, res) => {
  try {
    pipelineManager.auditDiskAssets();
    res.json({ success: true, message: 'Disk audit completed.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 9. Exports
app.get('/api/export/kinesioforge', async (req, res) => {
  try {
    const includeFixtures = req.query.fixtures === 'true';
    const buffer = await exportService.createKinesioForgeBatch(includeFixtures);
    const filename = `kinesioforge_batch_${Date.now()}.zip`;

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.get('/api/export/sofia', async (req, res) => {
  try {
    const includeFixtures = req.query.fixtures === 'true';
    const buffer = await exportService.createSofiaBundle(includeFixtures);
    const filename = `sofia-exercise-bundle-webp-${Date.now()}.zip`;

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(buffer);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 10. Windows Starter Kit Download
app.get('/api/download/windows-starter-kit', async (_req, res) => {
  try {
    const buffer = await windowsStarterKitService.generateStarterKitZip();
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="kinesioforge-windows-starter-kit.zip"'
    );
    res.send(buffer);
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 11. Production Queue API
app.get('/api/queue', (_req, res) => {
  try {
    const jobs = productionQueue.getJobs();
    const progress = productionQueue.getProgress();
    res.json({ success: true, progress, jobs });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/start', (_req, res) => {
  try {
    productionQueue.startRunner();
    res.json({ success: true, message: 'Queue runner started.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/pause', (_req, res) => {
  try {
    productionQueue.pauseQueue();
    res.json({ success: true, message: 'Queue paused.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/resume', (_req, res) => {
  try {
    productionQueue.resumeQueue();
    res.json({ success: true, message: 'Queue resumed.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/cancel', (_req, res) => {
  try {
    productionQueue.cancelPending();
    res.json({ success: true, message: 'Pending jobs cancelled.' });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/retry-failed', (_req, res) => {
  try {
    const count = productionQueue.retryFailed();
    res.json({ success: true, retriedCount: count });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/enqueue-all', (_req, res) => {
  try {
    const count = productionQueue.enqueueAllMissing();
    res.json({ success: true, queuedCount: count });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/queue/settings', async (req, res) => {
  try {
    const { concurrency, provider, checkpoint } = req.body;
    if (checkpoint !== undefined) {
      const installed = await comfyUiService.getAvailableCheckpoints();
      if (typeof checkpoint !== 'string' || !installed.includes(checkpoint)) {
        return res.status(400).json({ success: false, error: 'Checkpoint must exactly match an installed ComfyUI checkpoint filename.' });
      }
      productionQueue.setCheckpoint(checkpoint);
    }
    if (typeof concurrency === 'number') {
      productionQueue.setConcurrency(concurrency);
    }
    if (provider === 'comfyui' || provider === 'gemini') {
      productionQueue.setProvider(provider);
    }
    res.json({ success: true, progress: productionQueue.getProgress() });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 12. Athlete Profiles API
app.get('/api/athletes', (_req, res) => {
  try {
    const profiles = athleteManager.getProfiles();
    const defaultProfile = athleteManager.getDefaultProfile();
    res.json({ success: true, profiles, defaultProfile });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

app.post('/api/athletes', (req, res) => {
  try {
    const { id, ...data } = req.body;
    if (id) {
      const updated = athleteManager.updateProfile(id, data);
      return res.json({ success: true, profile: updated });
    }
    const created = athleteManager.addProfile(data);
    res.json({ success: true, profile: created });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 13. Sofia Catalog Intake & Dry-Run API
app.post('/api/sofia/dry-run', (req, res) => {
  try {
    const { catalog } = req.body;
    const report = sofiaCatalogService.analyzeSofiaCatalogDryRun(catalog);
    res.json({ success: true, report });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

app.post('/api/sofia/commit', (req, res) => {
  try {
    const { catalog } = req.body;
    const result = sofiaCatalogService.commitSofiaCatalog(catalog);
    res.json({ success: true, result });
  } catch (err: any) {
    res.status(400).json({ success: false, error: err.message });
  }
});

// 14. Workflows Library API
app.get('/api/workflows', async (_req, res) => {
  try {
    const comfyStatus = await comfyUiService.checkConnectivity();
    const installed = comfyStatus.availableCheckpoints || [];
    const templates = WORKFLOW_TEMPLATES.map((w) => {
      const compat = checkWorkflowCompatibility(w, installed);
      return {
        ...w,
        compatibility: compat,
      };
    });
    res.json({ success: true, workflows: templates });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// 15. Backup & Restore API
app.post('/api/backup/create', (_req, res) => {
  try {
    const storageDir = path.resolve(process.cwd(), 'public/storage');
    const backupDir = path.resolve(process.cwd(), 'backups');
    if (!fs.existsSync(backupDir)) {
      fs.mkdirSync(backupDir, { recursive: true });
    }
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const targetFile = path.join(backupDir, `backup_${timestamp}.json`);

    const data = {
      timestamp,
      exercises: pipelineManager.getAllExercises(),
      athletes: athleteManager.getProfiles(),
      queue: productionQueue.getJobs(),
    };
    fs.writeFileSync(targetFile, JSON.stringify(data, null, 2), 'utf8');
    res.json({ success: true, backupFile: `backup_${timestamp}.json` });
  } catch (err: any) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Vite Integration in Development
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '127.0.0.1', () => {
    console.log(`[KinesioForge] Studio Server running on http://127.0.0.1:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[KinesioForge] Server failed to start:', err);
});
