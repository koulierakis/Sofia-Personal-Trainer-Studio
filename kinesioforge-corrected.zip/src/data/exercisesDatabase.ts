import { ExerciseRecord, PhaseRecord } from '../types/pipeline';

const ATHLETE_PROFILE =
  'Athletic young Greek male under 30 years old with short dark hair and a chiseled physique, wearing a fitted black t-shirt and tight black training leggings with black training shoes. Setting: modern minimal luxury gym studio with clean polished concrete floor, matte dark wall panels, soft warm directional studio rim lighting, zero text, no clutter, photorealistic 8k commercial photography.';

export const RAW_EXERCISES_DATA: Omit<ExerciseRecord, 'phases'>[] = [
  {
    id: 'ex-01-rotational-cossack-squat-to-diagonal-landm',
    onomasia_askisis:
      'Αντιπεριστροφικό Κάθισμα Κοζάκου με Διαγώνιο Landmine Push-Press (Rotational Cossack Squat to Diagonal Landmine Push-Press)',
    english_name: 'Rotational Cossack Squat to Diagonal Landmine Push-Press',
    epipedo_dyskalias: 'Elite',
    stoxos:
      'Πολυεπίπεδη ισχύς κάτω άκρων, σταθεροποίηση πυρήνα στο εγκάρσιο επίπεδο και εκρηκτική μεταφορά ισχύος διαμέσου της κινητικής αλυσίδας (triple extension & contralateral press).',
    apaitoumenos_exoplismos: [
      'Μπάρα Ολυμπιακού τύπου (Olympic Barbell)',
      'Προσάρτημα Landmine (ή γωνιακή βάση περιστροφής)',
      'Δίσκοι βαρών',
    ],
    myikes_omades: {
      kyries: [
        'Μείζων & Μέσος Γλουτιαίος (Gluteus Maximus & Medius)',
        'Τετρακέφαλος (Quadriceps Femoris)',
        'Μείζων Προσαγωγός (Adductor Magnus)',
        'Πρόσθια & Πλάγια Μοίρα Δελτοειδούς (Anterior & Lateral Deltoid)',
        'Τρικέφαλος Βραχιόνιος (Triceps Brachii)',
      ],
      synergistes_statheropoiites: [
        'Εγκάρσιος & Έσω/Έξω Λοξοί Κοιλιακοί (Core Anti-Rotation)',
        'Πρόσθιος Οδοντωτός (Serratus Anterior)',
        'Εκτείνοντες τη Σπονδυλική Στήλη / Πολυσχιδείς',
        'Στροφικό Πέταλο Ώμου (Rotator Cuff)',
      ],
    },
    mixaniki_analysi:
      'Η άσκηση συνδυάζει μία έκκεντρη φόρτιση στο μετωπιαίο επίπεδο (frontal plane Cossack squat) με μία εκρηκτική περιστροφική επιτάχυνση στο εγκάρσιο και οβελιαίο επίπεδο (transverse/sagittal plane landmine drive).',
    odigies_ektelesis: {
      phase_1_setup:
        'Αρχική όρθια θέση με ευρύ άνοιγμα πελμάτων (1.5x ώμων), δάχτυλα 15-20 μοίρες έξω. Κράτημα Landmine με δεξί χέρι σε ύψος δεξιάς κλείδας σε ουδέτερη λαβή.',
      phase_2_movement:
        'Βαθύ κάθισμα Cossack προς το αριστερό πόδι, δεξί πόδι τεντωμένο με φτέρνα στο έδαφος και δάχτυλα προς τα πάνω. Μπάρα σταθερή στο δεξί ώμο.',
      phase_3_transition:
        'Πίεση εδάφους με αριστερό πέλμα και περιστροφή κορμού/ισχίων 90 μοίρες δεξιά σε εκρηκτική θέση διαγώνιας προβολής.',
      phase_4_peak:
        'Τριπλή έκταση άκρων και εκρηκτική ώθηση Landmine διαγώνια εμπρός και ψηλά (γωνία 45 μοιρών) σε πλήρη έκταση αγκώνα.',
      phase_5_return:
        'Έλεγχος καθόδου μπάρας σε 2 δευτερόλεπτα με περιστροφή ισχίων πίσω στο μετωπιαίο επίπεδο.',
      phase_6_reset:
        'Σταθεροποίηση στην αρχική όρθια ευθυγράμμιση και επαναφορά αναπνοής.',
    },
    simeia_prosoxis_lathi: [
      'Ανύψωση φτέρνας στο πόδι στήριξης κατά το κάθισμα Cossack.',
      'Υπερβολική κύφωση ή πλάγια κάμψη σπονδυλικής στήλης.',
      'Πρόωρη ώθηση βραχίονα πριν ολοκληρωθεί η ώθηση ισχίων.',
      'Ανεξέλεγκτη έκκεντρη φάση επαναφοράς.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 ξεχωριστές φάσεις (Setup, Cossack Squat Descent, Transverse Pivot Transition, Landmine Push-Press Peak, Eccentric Controlled Lowering, Final Reset).',
      prompts: {
        phase_1:
          'A dynamic, high-resolution full-body athletic photograph of an athletic young Greek male under 30 years old with short dark hair and a chiseled physique, standing in a wide sumo stance holding the sleeve end of a landmine barbell at collarbone level with his right hand. He is wearing a fitted black t-shirt and tight black training leggings with black training shoes. Background is a modern minimal personal gym studio with clean polished concrete floor, matte dark wall panels, soft warm directional studio rim lighting, zero text, no clutter, ultra-photorealistic.',
        phase_2:
          'A dynamic, high-resolution full-body athletic photograph of the same athletic young Greek male under 30 years old with short dark hair in a black t-shirt and tight black training leggings, executing a deep Cossack squat deep to his left side. His left knee is deeply flexed at 60 degrees, hip sunk low, while his right leg is completely extended straight to the side with toes pointed up and heel anchored. He holds the landmine barbell stable at his right shoulder with core braced. Modern minimal personal gym studio, dramatic athletic lighting, clean background without text.',
        phase_3:
          'A dynamic, high-resolution athletic photograph capturing the mid-transition phase of the same athletic young Greek male under 30 years old in a black t-shirt and tight black training leggings, pivoting explosively 90 degrees from the low Cossack squat into an athletic split lunge stance, hips driving upward, rotational force transferring through his rigid core into the right arm. High-end modern minimal gym studio background, crisp motion clarity, clean studio lighting.',
        phase_4:
          'A dynamic, high-resolution full-body athletic photograph of the same athletic young Greek male under 30 years old in a black t-shirt and tight black training leggings at the peak contraction of a landmine push-press. Both legs in powerful triple extension on ball of rear foot, right arm punched diagonally upward at a 45-degree angle in full lockout, serratus anterior contracted, core perfectly aligned without lumbar hyperextension. Modern minimal luxury gym studio, premium lighting, no text.',
        phase_5:
          'A dynamic, high-resolution athletic photograph of the same athletic young Greek male under 30 years old in a black t-shirt and tight black training leggings, controlling the eccentric descent of the landmine barbell back to collarbone level while rotating his hips back toward the front plane in a controlled athletic squat stance. Modern minimal personal gym studio, dramatic rim lighting, immaculate details, no text.',
        phase_6:
          'A dynamic, high-resolution full-body athletic photograph of the same athletic young Greek male under 30 years old in a black t-shirt and tight black training leggings, back in the upright wide starting stance, chest proud, barbell anchored at right shoulder, fully reset and composed for the next rep. Minimalist luxury gym studio background, soft spotlighting, high aesthetic consistency, zero text.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-02-zercher-curtsey-lunge-to-high-knee',
    onomasia_askisis:
      'Zercher Προβολή Curtsey με Εκρηκτική Άνοδο σε Μονοποδική Στήριξη και Υψηλό Γόνατο (Zercher Curtsey Lunge to Single-Leg High-Knee)',
    english_name: 'Zercher Curtsey Lunge to Single-Leg High-Knee Drive',
    epipedo_dyskalias: 'Advanced',
    stoxos:
      'Μονοποδική σταθερότητα, ενδυνάμωση μέσου γλουτιαίου και προσαγωγών, θωρακική έκταση και βελτίωση της ισχύος επιτάχυνσης.',
    apaitoumenos_exoplismos: ['Μπάρα με προστατευτικό pad ή Fat Bar', 'Δίσκοι βαρών'],
    myikes_omades: {
      kyries: [
        'Μέσος & Μικρός Γλουτιαίος (Gluteus Medius & Minimus)',
        'Μείζων Γλουτιαίος (Gluteus Maximus)',
        'Τετρακέφαλος (Quadriceps)',
        'Λαγονοψοΐτης (Iliopsoas)',
      ],
      synergistes_statheropoiites: [
        'Ορθός & Εγκάρσιος Κοιλιακός (Anterior Core)',
        'Άνω Τραπεζοειδής & Ρομβοειδείς (Scapular Retractors)',
        'Δικέφαλοι Βραχιόνιοι (Isometric Biceps Hold)',
      ],
    },
    mixaniki_analysi:
      'Η θέση Zercher μεταφέρει το κέντρο μάζας πρόσθια, αναγκάζοντας τους ραχιαίους και τους κοιλιακούς σε έντονη ισομετρική σύσπαση για αποφυγή πρόσθιας κλίσης του κορμού.',
    odigies_ektelesis: {
      phase_1_setup:
        'Όρθια θέση, μπάρα στις καμπές των αγκώνων (Zercher hold), στήθος ψηλά, πυρήνας σφιγμένος.',
      phase_2_curtsey_descent:
        'Διαγώνιο βήμα προς τα πίσω και σταυρωτά (curtsey lunge), χαμηλώνοντας το πίσω γόνατο κοντά στο έδαφος.',
      phase_3_isometric_hole:
        'Στιγμιαία ισομετρική παύση στο χαμηλότερο σημείο (γωνία 90 μοιρών εμπρόσθιου γόνατος) με διατήρηση κάθετου κορμού.',
      phase_4_explosive_drive:
        'Εκρηκτική πίεση από το μπροστινό πέλμα και ταυτόχρονη ανύψωση του πίσω γονάτου ψηλά προς το στήθος (high knee drive).',
      phase_5_single_leg_balance:
        'Σταθεροποίηση σε μονοποδική ισορροπία με το γόνατο στις 90+ μοίρες και μέγιστη ενεργοποίηση του γλουτού του ποδιού στήριξης.',
      phase_6_controlled_reset:
        'Ελεγχόμενη κάθοδος του αιωρούμενου ποδιού στην αρχική όρθια θέση με διατήρηση της λαβής Zercher.',
    },
    simeia_prosoxis_lathi: [
      'Κατάρρευση του μπροστινού γόνατος σε βλαισότητα (valgus collapse).',
      'Υπερβολική κάμψη του θώρακα προς τα εμπρός στη λαβή Zercher.',
      'Απώλεια ισορροπίας κατά την άνοδο του γονάτου.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 διακριτές φάσεις Zercher Curtsey Lunge to High Knee.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male in black athletic attire, standing upright holding a barbell in the crooks of his elbows in Zercher position, elbows pinned, tall chest. Modern minimal luxury gym, studio lighting.',
        phase_2:
          'Full-body photo of athletic young Greek male stepping back and diagonally into a deep Curtsey lunge, holding the Zercher barbell stable, torso strictly upright, front knee aligned over second toe.',
        phase_3:
          'Full-body athletic photo of the athletic young Greek male paused in the bottom hole of the Zercher curtsey lunge, intense muscular tension in quadriceps and glutes, zero forward torso lean.',
        phase_4:
          'Dynamic athletic action photo of the athletic young Greek male exploding upwards off the front leg, driving the rear knee powerfully forward and upward while maintaining rigid Zercher barbell stability.',
        phase_5:
          'Crisp athletic photograph capturing single-leg balance at the top: standing tall on right leg with left knee driven above hip height, glute locked, posture rock-solid in modern gym.',
        phase_6:
          'Athletic young Greek male lowering the elevated foot smoothly to bilateral standing posture, Zercher barbell resting steady in elbow crease, pristine luxury gym environment.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-03-trap-bar-deadlift-to-jump-shrug',
    onomasia_askisis:
      'Trap Bar Δυναμική Άρση Θανάτου με Εκρηκτικό Jump Shrug (Trap Bar Deadlift to Jump Shrug)',
    english_name: 'Trap Bar Dynamic Deadlift to Explosive Triple Extension Shrug',
    epipedo_dyskalias: 'Elite',
    stoxos:
      'Ανάπτυξη μέγιστου ρυθμού παραγωγής δύναμης (RFD), ισχύς οπίσθιας κινητικής αλυσίδας και αθλητική τριπλή έκταση.',
    apaitoumenos_exoplismos: ['Trap Bar (Hex Bar)', 'Ολυμπιακοί δίσκοι Bumper', 'Μαγνήσιο'],
    myikes_omades: {
      kyries: [
        'Μείζων Γλουτιαίος (Gluteus Maximus)',
        'Δικέφαλος Μηριαίος & Ημιτενοντώδης (Hamstrings)',
        'Τετρακέφαλος (Quadriceps)',
        'Τραπεζοειδής Άνω & Μέση Μοίρα (Trapezius)',
        'Γαστροκνήμιος & Υποκνημίδιος (Calves)',
      ],
      synergistes_statheropoiites: [
        'Εκτείνοντες Κορμό (Erector Spinae)',
        'Πλατύς Ραχιαίος (Latissimus Dorsi)',
        'Καμπτήρες Αντιβραχίου (Grip Strength)',
      ],
    },
    mixaniki_analysi:
      'Η κεντρική θέση του αθλητή εντός του Trap Bar μειώνει τις διατμητικές δυνάμεις στην οσφυϊκή μοίρα, επιτρέποντας μέγιστη επιτάχυνση στη 2η φάση έλξης.',
    odigies_ektelesis: {
      phase_1_hinge_grip:
        'Τοποθέτηση μέσα στο Trap Bar, ισχία πίσω σε hinge, ουδέτερη λαβή στις χειρολαβές, στήθος ανοιχτό, πλάτη κλειδωμένη.',
      phase_2_first_pull:
        'Έναρξη έλξης με πίεση του εδάφους μέσω των ποδιών μέχρι το ύψος των γονάτων με σταθερή γωνία κορμού.',
      phase_3_second_pull_acceleration:
        'Επιτάχυνση πάνω από τα γόνατα, βίαιη ώθηση ισχίων προς τα εμπρός.',
      phase_4_triple_extension_shrug:
        'Βίαιη τριπλή έκταση (αστραγάλων, γονάτων, ισχίων), ανασήκωμα ώμων (shrug) και αποκόλληση πελμάτων 2-5 εκ. από το έδαφος.',
      phase_5_athletic_catch_landing:
        'Απορρόφηση προσγείωσης σε μαλακά γόνατα σε εμβιομηχανικά ασφαλή ημικάθισμα με άψογη ευθυγράμμιση.',
      phase_6_lockout_reset:
        'Πλήρης όρθια επαναφορά, έλεγχος της μπάρας στο έδαφος και ανάσα.',
    },
    simeia_prosoxis_lathi: [
      'Κύφωση σπονδυλικής στήλης κατά την πρώτη έλξη.',
      'Πρόωρο τράβηγμα με τα χέρια (λύγισμα αγκώνων πριν την τριπλή έκταση).',
      'Προσγείωση με τεντωμένα γόνατα (σκληρή κρούση).',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Trap Bar Deadlift to Jump Shrug.',
      prompts: {
        phase_1:
          'Full-body athletic photograph of athletic young Greek male gripping the handles of a loaded Trap Bar on the floor, hips hinged back, spine neutral, chest up, modern luxury gym.',
        phase_2:
          'Action photograph of athletic young Greek male driving through midfoot in the first pull of Trap Bar deadlift, bar passing mid-shin to knees, back angle completely rigid.',
        phase_3:
          'Explosive motion capture photograph of athletic young Greek male accelerating the Trap Bar past knees, hips violently extending forward, kinetic chain engaged.',
        phase_4:
          'Peak action photograph of athletic young Greek male in full explosive triple extension and powerful shoulder shrug, feet slightly airborne above concrete floor, Trap Bar hovering, athletic power display.',
        phase_5:
          'Athletic young Greek male landing softly on forefoot into athletic quarter squat absorption, Trap Bar securely gripped at arms length, knees perfectly tracking toes.',
        phase_6:
          'Athletic young Greek male standing proud in locked-out tall posture with Trap Bar hanging at sides, breathing controlled in minimal dark gym studio.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-04-deficit-reverse-lunge-to-overhead-kettlebell-press',
    onomasia_askisis:
      'Προβολή Πίσω από Έλλειμμα με Ετερόπλευρη Πίεση Kettlebell πάνω από το Κεφάλι (Deficit Reverse Lunge to Overhead KB Press)',
    english_name: 'Deficit Reverse Lunge to Contralateral Overhead Kettlebell Press',
    epipedo_dyskalias: 'Advanced',
    stoxos:
      'Βάθος κινητικότητας ισχίου, έκκεντρη ενδυνάμωση σε αυξημένο ROM, ωμική σταθερότητα και ετερόπλευρος έλεγχος κορμού.',
    apaitoumenos_exoplismos: ['Πλατφόρμα ελλείμματος (step ή 2 bumper plates 5-10cm)', 'Kettlebell ανταγωνισμού'],
    myikes_omades: {
      kyries: [
        'Μείζων Γλουτιαίος (σε βαθιά επιμήκυνση)',
        'Τετρακέφαλος (Έκκεντρος έλεγχος)',
        'Πρόσθια & Έξω Μοίρα Δελτοειδούς',
        'Πρόσθιος Οδοντωτός (Overhead lockout)',
      ],
      synergistes_statheropoiites: [
        'Έσω & Έξω Λοξός Κοιλιακός (Anti-lateral flexion)',
        'Πυελικό Έδαφος & Εγκάρσιος',
      ],
    },
    mixaniki_analysi:
      'Το έλλειμμα αυξάνει την κάμψη του ισχίου στις 110+ μοίρες, μεγιστοποιώντας την πρόσληψη των μυϊκών ινών του γλουτού, ενώ το ετερόπλευρο φορτίο δοκιμάζει τον κορμό σε anti-lateral flexion.',
    odigies_ektelesis: {
      phase_1_deficit_rack_setup:
        'Όρθια θέση πάνω στην πλατφόρμα ελλείμματος (ύψος 7-10 εκ.). Το δεξί χέρι κρατά το Kettlebell στη θέση rack (στο στήθος).',
      phase_2_deep_lunge_descent:
        'Μεγάλο ελεγχόμενο βήμα πίσω με το δεξί πόδι, κατεβαίνοντας σε βαθύτερη προβολή λόγω της υπερύψωσης του αριστερού ποδιού.',
      phase_3_deficit_bottom_pause:
        'Στιγμιαία παύση στο μέγιστο βάθος: το αριστερό ισχίο σε βαθιά κάμψη, το δεξί γόνατο αιωρείται 1 εκ. πάνω από το έδαφος, σώμα σταθερό.',
      phase_4_concentric_drive:
        'Εκρηκτική ώθηση από την αριστερή φτέρνα επαναφέροντας το δεξί πόδι στην πλατφόρμα.',
      phase_5_overhead_press_lockout:
        'Ταυτόχρονη αυστηρή πίεση του Kettlebell πάνω από το κεφάλι σε πλήρη ευθυγράμμιση βραχίονα, αυτιού και σπονδυλικής στήλης.',
      phase_6_rack_recovery:
        'Ελεγχόμενη επαναφορά του Kettlebell στη θέση rack και ετοιμασία για την επόμενη επανάληψη.',
    },
    simeia_prosoxis_lathi: [
      'Πρόσκρουση του πίσω γονάτου στο δάπεδο.',
      'Πλάγια κάμψη του κορμού προς την πλευρά του Kettlebell.',
      'Υπερέκταση οσφυϊκής μοίρας (lordosis) κατά την πίεση overhead.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Deficit Reverse Lunge to Overhead KB Press.',
      prompts: {
        phase_1:
          'Full-body athletic photo of athletic young Greek male in black gear standing on a 3-inch elevation deficit platform, right hand holding a competition kettlebell in front rack position, poised and focused.',
        phase_2:
          'Action photograph of athletic young Greek male stepping back off the deficit platform into a deep reverse lunge, kettlebell held tightly against chest.',
        phase_3:
          'Deep athletic view of athletic young Greek male at the lowest point of deficit lunge, front hip flexed deeply past 90 degrees, rear knee hovering, kettlebell rack intact, immaculate form.',
        phase_4:
          'Dynamic photo of athletic young Greek male driving out of the hole back onto the platform, beginning the kettlebell overhead press trajectory.',
        phase_5:
          'Full-body shot of athletic young Greek male standing tall on platform with kettlebell locked out overhead in clean alignment, ribcage down, serratus anterior flexed.',
        phase_6:
          'Athletic young Greek male lowering the kettlebell safely back into the front rack notch, stable bilateral stance on deficit platform, dark aesthetic gym lighting.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-05-unilateral-romanian-deadlift-to-row',
    onomasia_askisis:
      'Μονοποδική Ρουμανική Άρση Θανάτου με Υποστηριζόμενη Κωπηλατική Αλτήρα (Single-Leg RDL to Contralateral Dumbbell Row)',
    english_name: 'Unilateral Single-Leg Romanian Deadlift to Supported Row',
    epipedo_dyskalias: 'Advanced',
    stoxos:
      'Έκκεντρος έλεγχος οπίσθιων μηριαίων, σταθερότητα πυέλου στο οριζόντιο επίπεδο και έλξη άνω κορμού σε ασύμμετρη βάση στήριξης.',
    apaitoumenos_exoplismos: ['Βαρύς αλτήρας (Hex Dumbbell)', 'Επίπεδο πάτωμα'],
    myikes_omades: {
      kyries: [
        'Δικέφαλος Μηριαίος & Ημιυμενώδης (Hamstrings)',
        'Μείζων & Μέσος Γλουτιαίος (Gluteus Medius & Maximus)',
        'Πλατύς Ραχιαίος (Latissimus Dorsi)',
        'Ρομβοειδείς & Μέσος Τραπεζοειδής',
      ],
      synergistes_statheropoiites: [
        'Πελματιαίοι Σταθεροποιητές & Προσθιοκνημιαίος',
        'Τετράγωνος Οσφυϊκός (Quadratus Lumborum)',
        'Πυρήνας (Anti-Rotation)',
      ],
    },
    mixaniki_analysi:
      'Η διατήρηση της θέσης "T" (κορμός και πίσω σκέλος σε μία ευθεία) προκαλεί τεράστια ροπή περιστροφής στην πύελο, απαιτώντας ισχυρή σύσπαση του μέσου γλουτιαίου του ποδιού στήριξης.',
    odigies_ektelesis: {
      phase_1_single_leg_setup:
        'Μονοποδική στήριξη στο αριστερό πόδι, ελαφριά κάμψη γόνατος (15-20 μοίρες), δεξί χέρι κρατά τον αλτήρα στο πλάι.',
      phase_2_hinge_descent:
        'Έκκεντρο hip hinge: τα ισχία οδηγούνται προς τα πίσω, ενώ το δεξί πόδι εκτείνεται ευθεία πίσω ως αντίβαρο.',
      phase_3_isometric_t_position:
        'Επίτευξη οριζόντιας θέσης "T", παράλληλα με το έδαφος, πύελος απόλυτα τετραγωνισμένη χωρίς εξωτερική στροφή.',
      phase_4_concentric_row:
        'Από την οριζόντια θέση, εκτέλεση εκρηκτικής κωπηλασίας με τον αλτήρα προς το ισχίο, οδηγώντας τον αγκώνα ψηλά.',
      phase_5_row_eccentric_extension:
        'Ελεγχόμενη κάθοδος του αλτήρα πίσω στην πλήρη έκταση του βραχίονα χωρίς απώλεια της οριζόντιας στήριξης.',
      phase_6_return_upright:
        'Ισχυρή έκταση του αριστερού ισχίου μέσω των γλουτών, επιστρέφοντας στην αρχική μονοποδική όρθια θέση.',
    },
    simeia_prosoxis_lathi: [
      'Άνοιγμα/στροφή της πυέλου προς τα έξω (pelvic flair/rotation).',
      'Κύφωση της ράχης για να φτάσει ο αλτήρας χαμηλότερα.',
      'Υπερβολικό λύγισμα του γόνατος στήριξης (μετατροπή σε squat).',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Single-Leg RDL to Contralateral Dumbbell Row.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male standing balanced on left foot, holding a black dumbbell in right hand, slight bend in knee, focused gaze.',
        phase_2:
          'Athletic action photograph of athletic young Greek male hinging back at the hips, right leg extending straight behind him in clean horizontal trajectory.',
        phase_3:
          'Side profile view of athletic young Greek male locked in a horizontal T-position single-leg RDL, spine flat, hips square to floor, dumbbell hanging at arm length.',
        phase_4:
          'Powerful athletic photograph of athletic young Greek male holding the single-leg RDL horizontal stance while rowing the dumbbell firmly toward hip crease, elbow high, lat contracted.',
        phase_5:
          'Athletic young Greek male lowering the dumbbell with control back down while maintaining unwavering balance in the single-leg RDL position.',
        phase_6:
          'Athletic young Greek male extending his standing hip powerfully to return upright on one leg, dumbbell at side, pristine aesthetic gym studio.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-06-plyometric-lateral-skater-to-stick',
    onomasia_askisis:
      'Πλειομετρικό Πλάγιο Άλμα Skater με Απόσβεση και Σταθεροποίηση (Plyometric Lateral Skater Bound to Deceleration Stick)',
    english_name: 'Plyometric Lateral Skater Bound to Deceleration Stick',
    epipedo_dyskalias: 'Intermediate',
    stoxos:
      'Πλάγια ισχύς στο μετωπιαίο επίπεδο, ικανότητα έκκεντρης απόσβεσης δυνάμεων (eccentric deceleration) και προστασία πρόσθιου χιαστού συνδέσμου (ACL).',
    apaitoumenos_exoplismos: ['Ελεύθερος χώρος δαπέδου (Agility turf ή λάστιχο)'],
    myikes_omades: {
      kyries: [
        'Μείζων & Μέσος Γλουτιαίος (Abduction & Deceleration)',
        'Τετρακέφαλος (Έκκεντρη απορρόφηση)',
        'Γαστροκνήμιος & Πελματιαίοι',
      ],
      synergistes_statheropoiites: [
        'Πλάγιοι Κοιλιακοί & Τετράγωνος Οσφυϊκός',
        'Οπίσθιοι Μηριαίοι (Σταθεροποίηση γόνατος)',
      ],
    },
    mixaniki_analysi:
      'Η άσκηση αποτελείται από 5 διακριτές φάσεις: Loading, Lateral Push-Off, Flight Phase, Deceleration Catch, και Isometric Stick. Δεν υπάρχει 6η φάση.',
    odigies_ektelesis: {
      phase_1_athletic_load:
        'Μονοποδική αθλητική φόρτιση στο δεξί πόδι, κάμψη ισχίου και γόνατος, χέρια οπλισμένα για πλάγια ώθηση.',
      phase_2_lateral_drive:
        'Εκρηκτική ώθηση από την εσωτερική πλευρά του δεξιού πέλματος στο μετωπιαίο επίπεδο, επιταχύνοντας οριζόντια.',
      phase_3_airborne_flight:
        'Πλήρης αιώρηση στον αέρα, το σώμα ταξιδεύει πλευρικά με μέγιστη κάλυψη απόστασης.',
      phase_4_eccentric_absorption:
        'Επαφή του αριστερού πέλματος στο έδαφος με άμεση έκκεντρη απόσβεση σε γόνατο και ισχίο χωρίς βλαισότητα.',
      phase_5_isometric_stick:
        'Απόλυτη ακινητοποίηση (stick) για 2 δευτερόλεπτα σε μονοποδική ισορροπία, το ελεύθερο πόδι πίσω χωρίς επαφή.',
    },
    simeia_prosoxis_lathi: [
      'Κατάρρευση του γόνατος προς τα μέσα κατά την προσγείωση (knee valgus).',
      'Αναπήδηση ή απώλεια ισορροπίας (αποτυχία του stick).',
      'Προσγείωση με τεντωμένη άρθρωση.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '5 φάσεις (Πενταφασική άσκηση χωρίς 6η φάση): Setup Load, Lateral Drive, Airborne Flight, Deceleration Catch, Isometric Stick.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male coiled low on his right leg in athletic single-leg loaded stance, arms cocked for lateral propulsion, modern minimal gym.',
        phase_2:
          'Dynamic action capture of athletic young Greek male driving explosively off the floor to his left, lateral push-off, muscles rippling in legs and calves.',
        phase_3:
          'Crisp airborne action photograph of athletic young Greek male flying horizontally through the air in athletic skater posture, full flight clarity, studio lighting.',
        phase_4:
          'Full-body photo of athletic young Greek male absorbing landing impact on left foot, deep knee and hip flexion absorbing lateral ground forces smoothly, knee aligned over toes.',
        phase_5:
          'Clean athletic photograph of athletic young Greek male frozen in a rock-solid single-leg deceleration stick on left leg, right leg tucked gracefully behind, perfect balance.',
      },
    },
    totalPhases: 5,
  },
  {
    id: 'ex-07-half-kneeling-cable-chop-to-lift',
    onomasia_askisis:
      'Ημι-γονατιστό Διαγώνιο Chop σε Lift Τροχαλίας (Half-Kneeling Multi-Angle Cable Chop to Lift)',
    english_name: 'Half-Kneeling Multi-Angle Rotary Cable Chop to Diagonal Lift',
    epipedo_dyskalias: 'Intermediate',
    stoxos:
      'Διαγώνια ισχύς πυρήνα (serape effect), σταθεροποίηση λεκάνης σε ασύμμετρη γονατιστή στήριξη και έλεγχος περιστροφικής ροπής.',
    apaitoumenos_exoplismos: ['Ρυθμιζόμενη τροχαλία (Cable column)', 'Σχοινί ή λαβή D-handle'],
    myikes_omades: {
      kyries: [
        'Έσω & Έξω Λοξοί Κοιλιακοί (Rotational Core)',
        'Εγκάρσιος Κοιλιακός (Transverse Abdominis)',
        'Πρόσθιος Οδοντωτός (Serratus Anterior)',
        'Μείζων Θωρακικός & Πρόσθιος Δελτοειδής',
      ],
      synergistes_statheropoiites: [
        'Μείζων Γλουτιαίος (του γονατιστού σκέλους σε έκταση)',
        'Προσαγωγοί & Τετρακέφαλος (ποδιού στήριξης)',
      ],
    },
    mixaniki_analysi:
      'Η ημι-γονατιστή θέση "κλειδώνει" την κίνηση των ισχίων, αναγκάζοντας τη ροπή περιστροφής να παραχθεί αποκλειστικά από τη θωρακική μοίρα και τους λοξούς κοιλιακούς.',
    odigies_ektelesis: {
      phase_1_kneeling_setup:
        'Τοποθέτηση σε ημι-γονατιστή θέση (90-90): το εσωτερικό γόνατο στο πάτωμα, τα χέρια εκτείνονται προς την ψηλή τροχαλία.',
      phase_2_diagonal_chop_drive:
        'Έλξη του καλωδίου διαγώνια προς το στήθος με σύσπαση των λοξών κοιλιακών και διατήρηση ακίνητης πυέλου.',
      phase_3_transition_press_down:
        'Ώθηση του καλωδίου διαγώνια κάτω προς το εξωτερικό ισχίο με πλήρη έκταση αγκώνων.',
      phase_4_reverse_lift_pivot:
        'Αναστροφή της κίνησης: έναρξη διαγώνιου lift από το χαμηλό σημείο πίσω προς τα πάνω και έξω.',
      phase_5_high_diagonal_lockout:
        'Ολοκλήρωση του lift με πλήρη έκταση χεριών ψηλά διαγώνια σε γωνία 45 μοιρών με σταθερό σφιχτό κορμό.',
      phase_6_controlled_reset:
        'Ελεγχόμενη επαναφορά της λαβής στην αρχική ψηλή θέση της τροχαλίας και σταθεροποίηση.',
    },
    simeia_prosoxis_lathi: [
      'Κίνηση ή ταλάντωση της λεκάνης (απώλεια σταθεροποίησης γλουτού).',
      'Υπερβολική στροφή της οσφυϊκής αντί της θωρακικής μοίρας.',
      'Κάμψη κορμού κατά το chop.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Half-Kneeling Cable Chop to Diagonal Lift.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male in half-kneeling position (90-90 angle), arms reaching diagonally up toward high cable handle, glutes engaged, torso tall.',
        phase_2:
          'Action athletic photo of athletic young Greek male pulling the cable diagonally across torso toward his chest, obliques tight, pelvis immovably locked.',
        phase_3:
          'Athletic young Greek male finishing the diagonal chop down past the lead hip, arms extended, core rigid, dark minimal studio gym lighting.',
        phase_4:
          'Athletic young Greek male transitioning from low position into a reverse diagonal cable lift, rotating through thoracic spine with controlled precision.',
        phase_5:
          'Peak athletic photo of athletic young Greek male punching the cable handle high and diagonally across opposite shoulder in full lockout, tall posture, serene focus.',
        phase_6:
          'Athletic young Greek male guiding the cable handle smoothly back to the top anchor, balanced in 90-90 kneeling pose, luxury fitness studio.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-08-barbell-hang-clean-to-front-squat',
    onomasia_askisis:
      'Barbell Δυναμικό Hang Power Clean με Άμεση Μετάβαση σε Βαθύ Μπροστινό Κάθισμα (Hang Clean to Front Squat)',
    english_name: 'Barbell Dynamic Hang Power Clean to Deep Front Squat Catch',
    epipedo_dyskalias: 'Elite',
    stoxos:
      'Ολυμπιακή ταχύτητα μετατόπισης κάτω από τη μπάρα, εκρηκτική έκταση ισχίων, σταθερότητα rack και δύναμη κάτω άκρων.',
    apaitoumenos_exoplismos: ['Ολυμπιακή μπάρα 20kg', 'Bumper Plates', 'Κολάρα ασφαλείας'],
    myikes_omades: {
      kyries: [
        'Μείζων Γλουτιαίος & Οπίσθιοι Μηριαίοι',
        'Τετρακέφαλος (Βαθύ squat)',
        'Τραπεζοειδής & Δελτοειδείς',
      ],
      synergistes_statheropoiites: [
        'Εκτείνοντες Κορμό (Thoracic extension)',
        'Ορθός & Εγκάρσιος Κοιλιακός',
        'Καμπτήρες Καρπού & Πρόσθιος Οδοντωτός',
      ],
    },
    mixaniki_analysi:
      'Η κίνηση απαιτεί βίαιο άνοιγμα ισχίων και αστραπιαία περιστροφή των αγκώνων (elbow turnover) για υποδοχή στο front rack σε βαθύ κάθισμα.',
    odigies_ektelesis: {
      phase_1_hang_position:
        'Όρθια θέση, μπάρα στο μέσο των μηρών (hang position), ισχία ελαφρώς πίσω, ώμοι πάνω από τη μπάρα.',
      phase_2_explosive_second_pull:
        'Βίαιη τριπλή έκταση ισχίων, γονάτων και ποδοκνημικών με ταυτόχρονο ανασήκωμα ώμων.',
      phase_3_elbow_turnover:
        'Γρήγορο τράβηγμα του σώματος κάτω από τη μπάρα, αστραπιαία περιστροφή αγκώνων προς τα εμπρός.',
      phase_4_deep_front_squat_catch:
        'Υποδοχή της μπάρας στο πρόσθιο rack (πάνω στους δελτοειδείς) ταυτόχρονα με βαθύ μπροστινό κάθισμα κάτω από τις 90 μοίρες.',
      phase_5_front_squat_ascent:
        'Δυναμική ανάδυση από το κάθισμα με τους αγκώνες ψηλά και στήθος κάθετο προς το έδαφος.',
      phase_6_lockout_stand:
        'Πλήρης όρθια ολοκλήρωση με έλεγχο της μπάρας στο στήθος πριν την ελεγχόμενη κάθοδο.',
    },
    simeia_prosoxis_lathi: [
      'Χαμήλωμα αγκώνων κατά την υποδοχή (κίνδυνος τραυματισμού καρπών).',
      'Υπερβολικό άλμα των ποδιών προς τα έξω.',
      'Κύφωση θωρακικής μοίρας στο βαθύ κάθισμα.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Barbell Hang Clean to Front Squat.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male holding barbell at mid-thigh hang position, shoulders over bar, back locked flat, focused modern gym ambiance.',
        phase_2:
          'Explosive action photo of athletic young Greek male driving through triple extension in hang clean second pull, barbell brushing thighs, traps shrugging fiercely.',
        phase_3:
          'Action freeze of athletic young Greek male snapping elbows forward underneath the rising barbell, dropping hips rapidly into squat descent.',
        phase_4:
          'Full-body photo of athletic young Greek male catching the barbell in a deep, pristine front squat, elbows pointed high, torso upright, thighs below parallel.',
        phase_5:
          'Athletic young Greek male driving up forcefully out of the deep front squat hole, quadriceps flexed, posture vertical and rock-solid.',
        phase_6:
          'Athletic young Greek male standing tall in complete lockout with barbell resting securely on front deltoids, chest broad, clean luxury fitness backdrop.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-09-turkish-getup-complete-chain',
    onomasia_askisis:
      'Πλήρης Κινητική Αλυσίδα Τουρκικού Σηκώματος (Full Kinetic Chain Turkish Get-Up Sequence)',
    english_name: 'Full Kinetic Chain Turkish Get-Up (Roll to Stand Sequence)',
    epipedo_dyskalias: 'Advanced',
    stoxos:
      'Σφαιρική ωμική σταθερότητα, διασταυρούμενος συντονισμός κινητικής αλυσίδας, κινητικότητα ισχίων και ανύψωση σώματος από το έδαφος.',
    apaitoumenos_exoplismos: ['Kettlebell ή Dumbbell (16-24kg)', 'Αθλητικό υπόστρωμα/δάπεδο'],
    myikes_omades: {
      kyries: [
        'Στροφικό Πέταλο & Δελτοειδείς (Isometric stability)',
        'Πρόσθιος Οδοντωτός (Scapular upward rotation)',
        'Λοξοί & Εγκάρσιος Κοιλιακός (Rotational core)',
        'Γλουτιαίοι & Τετρακέφαλοι (Stand up transition)',
      ],
      synergistes_statheropoiites: [
        'Πλατύς Ραχιαίος',
        'Τρικέφαλος Βραχιόνιος',
        'Απαγωγοί & Προσαγωγοί Ισχίου',
      ],
    },
    mixaniki_analysi:
      'Το Kettlebell πρέπει να παραμένει διαρκώς κάθετο προς το έδαφος σε όλη τη διάρκεια των μεταβάσεων από ύπτια θέση σε όρθια στήριξη.',
    odigies_ektelesis: {
      phase_1_supine_press_start:
        'Ύπτια θέση στο δάπεδο, δεξί γόνατο λυγισμένο με πέλμα στο έδαφος, δεξί χέρι κρατά το Kettlebell σε πλήρη κατακόρυφη έκταση.',
      phase_2_roll_to_elbow:
        'Πίεση με το δεξί πέλμα και περιστροφή του κορμού προς τα αριστερά, ανεβαίνοντας στον αριστερό αγκώνα με το βλέμμα στο βάρος.',
      phase_3_tall_palm_bridge:
        'Έκταση του αριστερού βραχίονα για στήριξη στην παλάμη, ανύψωση των ισχίων ψηλά σε γέφυρα (high bridge).',
      phase_4_leg_sweep_to_kneel:
        'Πέρασμα (sweep) του αριστερού ποδιού κάτω από το σώμα και τοποθέτηση του γονάτου στο έδαφος σε ημι-γονατιστή θέση.',
      phase_5_half_kneeling_stand_prep:
        'Ανόρθωση του κορμού σε κατακόρυφη ημι-γονατιστή θέση, το βάρος σταθερά κλειδωμένο πάνω από τον ώμο.',
      phase_6_overhead_standing_lockout:
        'Πίεση με τα δύο πόδια και έγερση σε πλήρη όρθια στάση με το Kettlebell απόλυτα σταθερό πάνω από το κεφάλι.',
    },
    simeia_prosoxis_lathi: [
      'Απομάκρυνση του βλέμματος από το Kettlebell κατά τις αρχικές φάσεις.',
      'Λύγισμα του αγκώνα που κρατά το βάρος.',
      'Κατάρρευση του ώμου στήριξης προς το αυτί.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Turkish Get-Up: Roll to Elbow, Palm Bridge, Leg Sweep, Half-Kneeling Posture, Stand-up Drive, Full Stand.',
      prompts: {
        phase_1:
          'Athletic young Greek male lying on floor in minimal gym, right arm holding a kettlebell vertically in air, right knee bent with foot planted, gaze locked on bell.',
        phase_2:
          'Athletic action photo of athletic young Greek male rolling dynamically onto his left elbow, right arm holding kettlebell vertically upright, core deeply engaged.',
        phase_3:
          'Athletic young Greek male bridging hips high into high-palm bridge, straight line from left hand on floor through torso to right hand holding kettlebell aloft.',
        phase_4:
          'Athletic young Greek male sweeping left leg smoothly beneath hips into a kneeling tripod position, kettlebell poised overhead with unyielding stability.',
        phase_5:
          'Athletic young Greek male hinging torso upright into tall half-kneeling stance, kettlebell locked out overhead, eyes forward, athletic balance.',
        phase_6:
          'Full-body photo of athletic young Greek male standing upright in complete Turkish Get-Up lockout, kettlebell punched toward ceiling, perfect posture and alignment.',
      },
    },
    totalPhases: 6,
  },
  {
    id: 'ex-10-bulgarian-split-squat-isometric-to-hop',
    onomasia_askisis:
      'Βουλγαρικό Κάθισμα με Ισομετρική Φόρτιση και Εκρηκτικό Πλειομετρικό Άλμα (Bulgarian Split Squat Isometric to Hop)',
    english_name: 'Rear-Foot-Elevated Split Squat Isometric Load to Explosive Hop',
    epipedo_dyskalias: 'Intermediate',
    stoxos:
      'Ανάπτυξη μονοποδικής εκρηκτικής δύναμης, υπερνίκηση ισομετρικής υστέρησης και έκκεντρη ενδυνάμωση εκτεινόντων ισχίου και γόνατος.',
    apaitoumenos_exoplismos: ['Πάγκος γυμναστηρίου ή κουτί 40cm'],
    myikes_omades: {
      kyries: [
        'Τετρακέφαλος (Quadriceps)',
        'Μείζων Γλουτιαίος (Gluteus Maximus)',
        'Μέσος Γλουτιαίος (Μονοποδική σταθερότητα)',
      ],
      synergistes_statheropoiites: [
        'Γαστροκνήμιος & Πελματιαία απονεύρωση',
        'Εγκάρσιος & Ορθός Κοιλιακός',
      ],
    },
    mixaniki_analysi:
      'Η άσκηση αποτελείται από 5 διακριτές φάσεις: Setup, Deep Isometric Hold, Concentric Jump Impulse, Airborne Flight, και Deceleration Land. Δεν υπάρχει 6η φάση.',
    odigies_ektelesis: {
      phase_1_split_bench_setup:
        'Τοποθέτηση του δεξιού κουντεπιέ πάνω στον πάγκο πίσω, το αριστερό πόδι μπροστά σε σταθερή στήριξη, κορμός στητός.',
      phase_2_deep_isometric_hold:
        'Κάθοδος σε βαθύ βουλγαρικό κάθισμα (μηρός παράλληλος με έδαφος) και ισομετρική παύση για 3 δευτερόλεπτα.',
      phase_3_explosive_jump_drive:
        'Εκρηκτική ώθηση από την αριστερή φτέρνα και το μετατάρσιο κατευθείαν προς τα πάνω.',
      phase_4_airborne_apex:
        'Αποκόλληση του αριστερού πέλματος από το έδαφος στον αέρα, πλήρης τριπλή έκταση του μπροστινού σκέλους.',
      phase_5_landing_deceleration_reset:
        'Ομαλή προσγείωση στο μπροστινό πόδι με απορρόφηση των δυνάμεων πίσω στην αθλητική θέση ημικαθίσματος.',
    },
    simeia_prosoxis_lathi: [
      'Υπερβολική κλίση κορμού προς τα πίσω (υπερέκταση μέσης).',
      'Πρόσκρουση του πίσω γονάτου στο δάπεδο.',
      'Προσγείωση με τεντωμένη άρθρωση γόνατος.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '5 φάσεις (Πενταφασική άσκηση χωρίς 6η φάση): Split Stance Setup, Deep Isometric Hold, Jump Impulse, Airborne Flight, Deceleration Land.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male with rear right foot resting on a gym bench, front left leg positioned forward in Bulgarian split squat stance, tall athletic posture.',
        phase_2:
          'Athletic young Greek male holding a deep isometric Bulgarian split squat, left thigh parallel to floor, knee aligned over midfoot, torso slightly forward-hinged with neutral spine.',
        phase_3:
          'Action capture of athletic young Greek male driving with explosive intent through front foot, muscles firing in quad and glute as jump initiates.',
        phase_4:
          'Dynamic airborne photograph of athletic young Greek male leaping upward off the floor from the Bulgarian stance, front leg fully extended, arms driving upward, athletic power.',
        phase_5:
          'Clean athletic photo of athletic young Greek male landing softly on front forefoot and absorbing the descent into controlled split squat position, pristine gym lighting.',
      },
    },
    totalPhases: 5,
  },
  {
    id: 'ex-11-prone-incline-dumbbell-y-raise-to-retraction',
    onomasia_askisis:
      'Πρηνής Έκταση Ώμων σε Επικλινή Πάγκο 45 Μοιρών σε Σχήμα Y-T με Ωμοπλατιαία Σύσπαση (Prone Incline Y-T Scapular Raise)',
    english_name: 'Prone 45-Degree Incline Dumbbell Y-T-W Scapular Retraction & Press',
    epipedo_dyskalias: 'Intermediate',
    stoxos:
      'Απομόνωση κάτω και μέσου τραπεζοειδούς, εξωτερική στροφή βραχιονίου, διόρθωση πρόσθιας κλίσης ώμων και ενδυνάμωση στροφικού πετάλου.',
    apaitoumenos_exoplismos: ['Ρυθμιζόμενος πάγκος (γωνία 45 μοιρών)', 'Ελαφριοί αλτήρες (2-6kg)'],
    myikes_omades: {
      kyries: [
        'Κάτω & Μέσος Τραπεζοειδής (Lower & Middle Trapezius)',
        'Υπακάνθιος & Ελάσσων Στρογγύλος (External Rotators)',
        'Οπίσθια Μοίρα Δελτοειδούς (Rear Deltoid)',
      ],
      synergistes_statheropoiites: [
        'Ρομβοειδείς Μύες',
        'Εκτείνοντες Θωρακική Μοίρα (Spinal Erectors)',
      ],
    },
    mixaniki_analysi:
      'Η κλίση του πάγκου στις 45 μοίρες τοποθετεί τη γραμμή έλξης σε τέλεια ευθυγράμμιση με τις μυϊκές ίνες του κάτω τραπεζοειδούς, αποτρέποντας την υπερδραστηριότητα του άνω τραπεζοειδούς.',
    odigies_ektelesis: {
      phase_1_bench_setup:
        'Πρηνής τοποθέτηση του στήθους στον πάγκο 45 μοιρών, πέλματα καρφωμένα στο έδαφος, χέρια κρέμονται κάθετα κρατώντας ελαφρούς αλτήρες με αντίχειρες προς τα έξω.',
      phase_2_scapular_depression:
        'Πρώτη κίνηση: ενεργή κατάσπαση των ωμοπλατών μακριά από τα αυτιά (scapular depression) πριν την ανύψωση των βραχιόνων.',
      phase_3_y_raise_ascent:
        'Ανύψωση των χεριών σε διαγώνιο σχήμα "Y" (γωνία 30-45 μοιρών από τον κορμό) με τους αντίχειρες να κοιτούν προς το ταβάνι.',
      phase_4_peak_isometric_squeeze:
        'Μέγιστη σύσπαση στην κορυφή: πλήρης ευθυγράμμιση βραχιόνων με τον κορμό, συμπίεση κάτω τραπεζοειδούς για 2 δευτερόλεπτα.',
      phase_5_eccentric_lowering:
        'Ελεγχόμενη κάθοδος των αλτήρων σε διάρκεια 3 δευτερολέπτων διατηρώντας την έκταση της θωρακικής μοίρας.',
      phase_6_reset_hang:
        'Πλήρης επιστροφή στην αρχική κρεμάμενη θέση, απελευθέρωση έντασης και προετοιμασία για την επόμενη επανάληψη.',
    },
    simeia_prosoxis_lathi: [
      'Ανασήκωμα των ώμων προς τα αυτιά (υπερδραστηριότητα άνω τραπεζοειδούς).',
      'Υπερέκταση του αυχένα προς τα πάνω κατά την άρση.',
      'Χρήση υπερβολικού βάρους που οδηγεί σε ταλάντωση του σώματος.',
    ],
    optiki_apeikonisi_dalle_prompts: {
      domi_kinisis: '6 φάσεις Prone Incline Y-T Scapular Raise.',
      prompts: {
        phase_1:
          'Full-body photo of athletic young Greek male lying prone with chest supported on a 45-degree incline gym bench, holding light dumbbells hanging toward floor, thumbs outward, clean luxury studio.',
        phase_2:
          'Close-up athletic view of athletic young Greek male actively depressing and setting his shoulder blades back and down away from his neck before lifting.',
        phase_3:
          'Action capture of athletic young Greek male raising arms upward and diagonally in a pristine Y-shape trajectory, thumbs pointing toward ceiling, elbows straight.',
        phase_4:
          'Peak contraction view of athletic young Greek male holding the peak Y-raise, shoulder blades retracted and depressed, lower trapezius intensely defined, serene facial focus.',
        phase_5:
          'Athletic young Greek male lowering dumbbells with slow controlled eccentric rhythm back down, maintaining chest contact with bench.',
        phase_6:
          'Athletic young Greek male resting in the hang position on incline bench, relaxed neck, ready for next repetition, dark aesthetic gym atmosphere.',
      },
    },
    totalPhases: 6,
  },
];

// Helper to construct all 64 Phase records
export function generateInitialPhases(): PhaseRecord[] {
  const allPhases: PhaseRecord[] = [];

  for (const ex of RAW_EXERCISES_DATA) {
    for (let p = 1; p <= ex.totalPhases; p++) {
      const pKey = `phase_${p}`;
      const promptText =
        ex.optiki_apeikonisi_dalle_prompts.prompts[pKey] ||
        `High-resolution athletic photograph of ${ex.english_name}, phase ${p}. ${ATHLETE_PROFILE}`;

      const phaseName =
        p === 1
          ? 'Setup & Foundation'
          : p === ex.totalPhases
          ? 'Reset & Stabilization'
          : p === 2
          ? 'Primary Movement Descent'
          : p === 3
          ? 'Transition / Pivot'
          : p === 4
          ? 'Peak Execution / Extension'
          : 'Eccentric Control';

      // Check if this is Exercise 1 where seed fixtures exist in storage
      const isEx01 = ex.id === 'ex-01-rotational-cossack-squat-to-diagonal-landm';
      const phaseNumPadded = String(p).padStart(2, '0');
      const seedPath = isEx01
        ? `storage/ex-01-rotational-cossack-squat-to-diagonal-landm/phase-${phaseNumPadded}.png`
        : undefined;

      // Notice Phase 1 and Phase 6 in the legacy export had identical binaries!
      const isDuplicateDetected = isEx01 && (p === 1 || p === 6);
      const duplicateOf = isEx01 && p === 6 ? `${ex.id}_phase-01` : undefined;

      const phaseRecord: PhaseRecord = {
        id: `${ex.id}_phase-${phaseNumPadded}`,
        exerciseId: ex.id,
        exerciseName: ex.onomasia_askisis,
        phaseNumber: p,
        phaseName,
        phaseKey: pKey,
        fullPrompt: promptText,
        athleteProfile: ATHLETE_PROFILE,
        generationProvider: isEx01 ? 'manual' : 'none',
        jobStatus: isEx01 ? 'completed' : 'idle',
        outputPath: seedPath,
        imageChecksum: isEx01
          ? p === 1 || p === 6
            ? '1df118f593bb36cbe482c3f81e33c6751e3abf066b593eb4b1432f83ee07ff67'
            : p === 2
            ? 'd2504daa0c51a02d992f1b40266da5e4860b7be303530f9836ae058d8e5eeccb'
            : p === 3
            ? 'dddbf742d3262035ef24ec985fffa6b8f395fb61ae6d84a753ce35ff5e04ae87'
            : p === 4
            ? '382427fc14622eb287bbda8a7d25e0e0ab5b49ebbc9d7fb2e53303d7cf3832b8'
            : 'caf74b9fbd13d64dfcf05fca1c67623910c2c310c3b0eb688b5ea3c7e0bce783'
          : undefined,
        fileSizeBytes: isEx01
          ? p === 1 || p === 6
            ? 23624
            : p === 2
            ? 23868
            : p === 3
            ? 23005
            : p === 4
            ? 23381
            : 23328
          : undefined,
        provenance: {
          type: isEx01 ? 'PROGRAMMATIC_SEED' : 'PLACEHOLDER',
          provider: isEx01 ? 'programmatic' : 'none',
          model: isEx01 ? 'schematic-canvas-fixture-v1' : 'none',
          generationTimestamp: isEx01 ? '2026-10-21T09:42:36.492Z' : undefined,
          durationMs: isEx01 ? 0 : undefined,
          isSeeded: isEx01,
          device: isEx01 ? 'Canvas Vector Renderer (Fixture)' : undefined,
          seedSignature: isEx01 ? 'legacy-silhouettes-batch-001' : undefined,
        },
        qcReport: {
          overallStatus: isEx01 ? 'failed' : 'uninspected',
          anatomicalScore: isEx01 ? 38 : 0,
          biomechanicalScore: isEx01 ? 40 : 0,
          phaseAccuracy: isEx01 ? 'minor_deviation' : 'unverified',
          jointAlignment: isEx01
            ? 'Schematic graphic only. Real muscular definition and joint surface textures are absent.'
            : 'Uninspected',
          equipmentGrip: isEx01
            ? 'Schematic bar outline detected. Requires real photographic capture.'
            : 'Uninspected',
          isDuplicate: isDuplicateDetected,
          duplicateOfPhaseId: duplicateOf,
          isPlaceholderDetected: isEx01,
          detectedIssues: isEx01
            ? [
                'Programmatic vector/canvas silhouette detected, NOT genuine AI photograph.',
                ...(isDuplicateDetected && p === 6
                  ? ['CRITICAL: Binary hash identical to Phase 01 (duplicate frame reuse).']
                  : []),
                'Fails production photographic quality standards.',
              ]
            : [],
          suggestedPromptCorrections: isEx01
            ? 'Submit prompt to genuine photorealistic image generator (Gemini or ComfyUI SDXL/Flux).'
            : '',
          verdictSummary: isEx01
            ? 'REJECTED FOR PRODUCTION: Development fixture asset only.'
            : 'Pending evaluation upon image generation.',
          evaluatedAt: isEx01 ? new Date().toISOString() : '',
          modelUsed: isEx01 ? 'kinesioforge-integrity-auditor' : '',
        },
        humanReview: {
          status: isEx01 ? 'needs_regeneration' : 'pending',
          notes: isEx01
            ? 'Labeled as programmatic seed fixture. Do not export as production photography.'
            : undefined,
        },
      };

      allPhases.push(phaseRecord);
    }
  }

  return allPhases;
}

export function buildCompleteExercises(): ExerciseRecord[] {
  const initialPhases = generateInitialPhases();

  return RAW_EXERCISES_DATA.map((ex) => {
    const phases = initialPhases.filter((p) => p.exerciseId === ex.id);
    return {
      ...ex,
      phases,
    };
  });
}
