import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import {
  ExerciseRecord,
  PhaseRecord,
  IntegrityDashboardStats,
  DuplicateDetection,
  ReadinessCategory,
} from '../types/pipeline';
import { buildCompleteExercises } from '../data/exercisesDatabase';

const STORAGE_DIR = path.resolve(process.cwd(), 'public/storage');
const STATE_FILE = path.join(STORAGE_DIR, 'pipeline_state.json');

export class PipelineManager {
  private exercises: ExerciseRecord[] = [];
  private isInitialized = false;

  constructor() {
    this.ensureStorageStructure();
  }

  private ensureStorageStructure() {
    if (!fs.existsSync(STORAGE_DIR)) {
      fs.mkdirSync(STORAGE_DIR, { recursive: true });
    }
  }

  public initialize(): void {
    if (this.isInitialized) return;

    // Check if saved state exists
    if (fs.existsSync(STATE_FILE)) {
      try {
        const raw = fs.readFileSync(STATE_FILE, 'utf8');
        this.exercises = JSON.parse(raw);
        // Ensure all canonical baseline exercises exist, merging them without erasing imported exercises
        const base = buildCompleteExercises();
        let changed = false;
        for (const baseEx of base) {
          if (!this.exercises.some((e) => e.id === baseEx.id)) {
            this.exercises.push(baseEx);
            changed = true;
          }
        }
        if (changed) {
          this.saveState();
        }
      } catch (err) {
        console.error('Error loading pipeline state, re-initializing database:', err);
        this.rebuildAndMergeWithDisk();
      }
    } else {
      this.rebuildAndMergeWithDisk();
    }

    // Always run disk audit on init
    this.auditDiskAssets();
    this.isInitialized = true;
  }

  private rebuildAndMergeWithDisk() {
    this.exercises = buildCompleteExercises();
    this.saveState();
  }

  public saveState(): void {
    try {
      this.ensureStorageStructure();
      fs.writeFileSync(STATE_FILE, JSON.stringify(this.exercises, null, 2), 'utf8');
    } catch (e) {
      console.error('Error writing pipeline_state.json:', e);
    }
  }

  public getAllExercises(): ExerciseRecord[] {
    return this.exercises;
  }

  public getExerciseById(id: string): ExerciseRecord | undefined {
    return this.exercises.find((e) => e.id.toLowerCase() === id.toLowerCase());
  }

  public getPhase(exerciseId: string, phaseNumber: number): PhaseRecord | undefined {
    const ex = this.getExerciseById(exerciseId);
    return ex?.phases.find((p) => p.phaseNumber === phaseNumber);
  }

  /**
   * Scans disk assets, validates SHA-256 hashes, checks for duplicate frame reuse,
   * flags simplistic programmatic canvas silhouettes, and ensures truth in provenance.
   */
  public auditDiskAssets(): void {
    // Collect all existing files and their hashes
    const hashMap = new Map<string, Array<{ exerciseId: string; phaseNumber: number; path: string; phaseId: string }>>();

    for (const ex of this.exercises) {
      for (const phase of ex.phases) {
        const relativePath = phase.outputPath;
        if (!relativePath) continue;

        const fullPath = path.resolve(process.cwd(), 'public', relativePath);
        if (fs.existsSync(fullPath)) {
          const buffer = fs.readFileSync(fullPath);
          const hash = crypto.createHash('sha256').update(buffer).digest('hex');
          const size = buffer.length;

          phase.imageChecksum = hash;
          phase.fileSizeBytes = size;

          // Check if this is the known programmatic silhouette fixture
          const isSmallSchematic = size < 35000; // 23KB files
          if (isSmallSchematic && phase.provenance.type !== 'GENERATED_AI_VERIFIED') {
            phase.provenance.type = 'PROGRAMMATIC_SEED';
            phase.provenance.isSeeded = true;
            phase.provenance.model = 'schematic-canvas-fixture-v1';
            phase.provenance.provider = 'programmatic';
            phase.qcReport.isPlaceholderDetected = true;
          }

          // Track for duplicate detection
          const list = hashMap.get(hash) || [];
          list.push({
            exerciseId: ex.id,
            phaseNumber: phase.phaseNumber,
            path: relativePath,
            phaseId: phase.id,
          });
          hashMap.set(hash, list);
        } else {
          // File does not actually exist on disk!
          phase.outputPath = undefined;
          phase.imageChecksum = undefined;
          phase.fileSizeBytes = undefined;
          phase.provenance.type = 'PLACEHOLDER';
          phase.jobStatus = 'idle';
        }
      }
    }

    // Mark duplicates
    for (const [hash, occurrences] of hashMap.entries()) {
      if (occurrences.length > 1) {
        for (const occ of occurrences) {
          const ph = this.getPhase(occ.exerciseId, occ.phaseNumber);
          if (ph) {
            ph.qcReport.isDuplicate = true;
            ph.qcReport.duplicateOfPhaseId = occurrences.find((o) => o.phaseId !== ph.id)?.phaseId;
            if (!ph.qcReport.detectedIssues.some((i) => i.includes('duplicate') || i.includes('Duplicate'))) {
              ph.qcReport.detectedIssues.push(
                `Duplicate binary detected: Identical SHA-256 hash (${hash.slice(0, 12)}...) matches ${ph.qcReport.duplicateOfPhaseId}`
              );
            }
            ph.qcReport.overallStatus = 'failed';
          }
        }
      }
    }

    this.saveState();
  }

  /**
   * Computes complete, truthful system metrics and readiness indicators
   */
  public getIntegrityStats(comfyUiStatus: { online: boolean; url: string; message: string; vramOptimized: boolean }, geminiStatus: { available: boolean; model: string; message?: string }): IntegrityDashboardStats {
    let completedPhotographs = 0;
    let genuineAIGenerated = 0;
    let verifiedProductionReady = 0;
    let programmaticSeeds = 0;
    let missingPhases = 0;
    let failedQC = 0;
    let awaitingHumanReview = 0;

    const duplicateMap = new Map<string, Array<{ exerciseId: string; phaseNumber: number; path: string; phaseId: string }>>();

    let totalPhasesCount = 0;

    for (const ex of this.exercises) {
      for (const ph of ex.phases) {
        totalPhasesCount++;

        if (ph.provenance.type === 'GENERATED_AI_VERIFIED') {
          genuineAIGenerated++;
          if (ph.humanReview.status === 'approved' && ph.qcReport.overallStatus === 'passed' && !ph.qcReport.isDuplicate) {
            verifiedProductionReady++;
            completedPhotographs++;
          }
        } else if (ph.provenance.type === 'PROGRAMMATIC_SEED') {
          programmaticSeeds++;
        } else if (ph.provenance.type === 'PLACEHOLDER' || !ph.outputPath) {
          missingPhases++;
        }

        if (ph.qcReport.overallStatus === 'failed') {
          failedQC++;
        }

        if (ph.outputPath && ph.humanReview.status === 'pending') {
          awaitingHumanReview++;
        }

        if (ph.imageChecksum) {
          const list = duplicateMap.get(ph.imageChecksum) || [];
          list.push({
            exerciseId: ph.exerciseId,
            phaseNumber: ph.phaseNumber,
            path: ph.outputPath || '',
            phaseId: ph.id,
          });
          duplicateMap.set(ph.imageChecksum, list);
        }
      }
    }

    const duplicateDetections: DuplicateDetection[] = [];
    let duplicateCount = 0;
    for (const [hash, items] of duplicateMap.entries()) {
      if (items.length > 1) {
        duplicateDetections.push({ hash, phases: items });
        duplicateCount += items.length;
      }
    }

    // Determine readiness categories
    const readinessCategories: ReadinessCategory[] = ['APPLICATION_BUILD_READY'];

    if (geminiStatus.available || comfyUiStatus.online) {
      readinessCategories.push('PROVIDER_INTEGRATION_READY');
    }

    if (missingPhases > 0 || programmaticSeeds > 0) {
      readinessCategories.push('IMAGE_LIBRARY_INCOMPLETE');
    }

    if (awaitingHumanReview > 0 || failedQC > 0) {
      readinessCategories.push('IMAGE_LIBRARY_REVIEW_PENDING');
    }

    // Strict Production Content Readiness rule:
    // ALL PHASES GENUINELY GENERATED AND VERIFIED, NO PLACEHOLDERS, NO SEEDS, NO DUPLICATES
    const isProductionReady =
      totalPhasesCount >= 64 &&
      genuineAIGenerated === totalPhasesCount &&
      verifiedProductionReady === totalPhasesCount &&
      missingPhases === 0 &&
      programmaticSeeds === 0 &&
      duplicateDetections.length === 0;

    if (isProductionReady) {
      readinessCategories.push('PRODUCTION_CONTENT_READY');
    }

    return {
      totalExercises: this.exercises.length,
      totalPhases: totalPhasesCount,
      completedPhotographs,
      genuineAIGenerated,
      verifiedProductionReady,
      programmaticSeeds,
      missingPhases,
      duplicateCount,
      duplicateDetections,
      failedQC,
      awaitingHumanReview,
      isProductionReady,
      readinessCategories,
      comfyUiStatus,
      geminiStatus,
    };
  }

  public updatePhaseReview(
    exerciseId: string,
    phaseNumber: number,
    status: 'pending' | 'approved' | 'rejected' | 'needs_regeneration',
    notes?: string,
    reviewer: string = 'Human Quality Inspector'
  ): PhaseRecord | null {
    const phase = this.getPhase(exerciseId, phaseNumber);
    if (!phase) return null;

    phase.humanReview = {
      status,
      reviewer,
      reviewedAt: new Date().toISOString(),
      notes,
    };

    this.saveState();
    return phase;
  }

  public registerGeneratedImage(
    exerciseId: string,
    phaseNumber: number,
    imageBuffer: Buffer,
    provider: 'gemini' | 'comfyui',
    model: string,
    requestId?: string
  ): PhaseRecord {
    const ex = this.getExerciseById(exerciseId);
    if (!ex) throw new Error(`Exercise ${exerciseId} not found`);

    const phase = ex.phases.find((p) => p.phaseNumber === phaseNumber);
    if (!phase) throw new Error(`Phase ${phaseNumber} not found for ${exerciseId}`);

    const exDir = path.join(STORAGE_DIR, exerciseId);
    if (!fs.existsSync(exDir)) {
      fs.mkdirSync(exDir, { recursive: true });
    }

    const phasePadded = String(phaseNumber).padStart(2, '0');
    const filename = `phase-${phasePadded}.png`;
    const fullPath = path.join(exDir, filename);

    // Save binary
    fs.writeFileSync(fullPath, imageBuffer);

    const hash = crypto.createHash('sha256').update(imageBuffer).digest('hex');
    const relativePath = `storage/${exerciseId}/${filename}`;

    phase.outputPath = relativePath;
    phase.imageChecksum = hash;
    phase.fileSizeBytes = imageBuffer.length;
    phase.jobStatus = 'completed';
    phase.errorMessage = undefined;

    phase.provenance = {
      type: 'GENERATED_AI_UNVERIFIED',
      provider,
      model,
      generationTimestamp: new Date().toISOString(),
      isSeeded: false,
      requestId,
      device: provider === 'comfyui' ? 'Local RTX 3060 12GB' : 'Cloud Vertex GPU',
    };

    phase.qcReport = {
      overallStatus: 'uninspected',
      anatomicalScore: 0,
      biomechanicalScore: 0,
      phaseAccuracy: 'unverified',
      jointAlignment: 'Awaiting vision inspection',
      equipmentGrip: 'Awaiting vision inspection',
      isDuplicate: false,
      isPlaceholderDetected: false,
      detectedIssues: [],
      suggestedPromptCorrections: '',
      verdictSummary: 'Fresh generation completed. Awaiting automated biomechanical QC.',
      evaluatedAt: '',
      modelUsed: '',
    };

    phase.humanReview = {
      status: 'pending',
      notes: 'New generation awaiting review.',
    };

    this.auditDiskAssets();
    this.saveState();
    return phase;
  }

  public createDefaultPhaseRecord(
    exerciseId: string,
    exerciseName: string,
    phaseNumber: number,
    totalPhases: number
  ): PhaseRecord {
    const phaseNamesByTotal: Record<number, Record<number, { name: string; key: string; action: string }>> = {
      4: {
        1: { name: 'Starting Setup & Core Bracing', key: 'phase_01_setup', action: 'standing with braced core and neutral spinal curvature, establishing baseline joint alignment' },
        2: { name: 'Eccentric Loading & Controlled Descent', key: 'phase_02_eccentric', action: 'controlled lowering into deep joint angles under strict eccentric tension' },
        3: { name: 'Concentric Acceleration & Force Drive', key: 'phase_03_concentric', action: 'forceful kinetic drive through prime movers reaching apex velocity' },
        4: { name: 'Terminal Stabilization & Lockout', key: 'phase_04_finish', action: 'solid completion at top/lockout with full postural control and balance' },
      },
      5: {
        1: { name: 'Starting Stance & Load Setup', key: 'phase_01_setup', action: 'initial grounded athletic stance, active neuromuscular engagement' },
        2: { name: 'Eccentric Load & Kinematic Descent', key: 'phase_02_eccentric', action: 'decelerating mass into hip and knee hinge with strict neutral spine' },
        3: { name: 'Amortization & Directional Transition', key: 'phase_03_amortization', action: 'zero-velocity transition inflection point storing elastic muscular energy' },
        4: { name: 'Dynamic Propulsion & Kinetic Transfer', key: 'phase_04_propulsion', action: 'explosive concentric kinetic chain release and propulsion' },
        5: { name: 'Deceleration Catch & Solid Grounding', key: 'phase_05_catch', action: 'firm landing or catch with knees tracking toes and active core' },
      },
      6: {
        1: { name: 'Initial Kinetic Setup & Balance', key: 'phase_01_setup', action: 'starting biomechanical setup with neutral pelvis and grounded feet' },
        2: { name: 'Eccentric Descent & Energy Loading', key: 'phase_02_eccentric', action: 'controlled eccentric lowering loading anterior and posterior chains' },
        3: { name: 'Isometric Bottom Turnaround Point', key: 'phase_03_isometric_turn', action: 'inflection point between descent and ascent under peak mechanical tension' },
        4: { name: 'Concentric Drive & Force Transmission', key: 'phase_04_concentric_drive', action: 'forceful kinetic drive accelerating against resistance' },
        5: { name: 'Secondary Movement or Dynamic Catch', key: 'phase_05_secondary_catch', action: 'rotational or overhead lockup kinetic transition' },
        6: { name: 'Controlled Recovery & Lockout Stance', key: 'phase_06_recovery_lockout', action: 'controlled deceleration back to upright balanced neutral stance' },
      },
    };

    const phaseConfig = phaseNamesByTotal[totalPhases]?.[phaseNumber] || {
      name: `Movement Phase ${phaseNumber}`,
      key: `phase_0${phaseNumber}`,
      action: `executing biomechanical phase ${phaseNumber} of ${exerciseName}`,
    };

    const phasePadded = String(phaseNumber).padStart(2, '0');
    const fullPrompt = `Ultra-photorealistic commercial fitness photography of a fit athletic Greek model with defined Mediterranean features in an exclusive private gym studio. The athlete is executing ${exerciseName}, Phase ${phaseNumber} of ${totalPhases}: ${phaseConfig.name}. Specifically captured ${phaseConfig.action}. Wearing matte black fitted athletic attire. Professional warm studio rim lighting highlighting biomechanical posture and muscular contraction, dark polished concrete floor, matte dark wall panels, high shutter speed capturing crisp muscle definition, 8k resolution, authentic sports science documentary style, no text, no watermarks.`;

    return {
      id: `${exerciseId}_phase-${phasePadded}`,
      exerciseId,
      exerciseName,
      phaseNumber,
      phaseName: phaseConfig.name,
      phaseKey: phaseConfig.key,
      fullPrompt,
      athleteProfile: 'Greek Athletic Prototype (Mediterranean, black athletic attire, luxury studio)',
      generationProvider: 'none',
      jobStatus: 'idle',
      provenance: {
        type: 'PLACEHOLDER',
        provider: 'none',
        model: 'none',
        isSeeded: false,
      },
      qcReport: {
        overallStatus: 'uninspected',
        anatomicalScore: 0,
        biomechanicalScore: 0,
        phaseAccuracy: 'unverified',
        jointAlignment: 'Pending generation and inspection',
        equipmentGrip: 'Pending generation and inspection',
        isDuplicate: false,
        isPlaceholderDetected: true,
        detectedIssues: ['Awaiting genuine photorealistic generation'],
        suggestedPromptCorrections: '',
        verdictSummary: 'Awaiting generation in production queue.',
        evaluatedAt: '',
        modelUsed: '',
      },
      humanReview: {
        status: 'pending',
        notes: 'Initial imported phase awaiting photography generation.',
      },
    };
  }

  public addOrMergeExercise(exerciseData: {
    id: string;
    english_name: string;
    onomasia_askisis?: string;
    epipedo_dyskalias?: string;
    stoxos?: string;
    apaitoumenos_exoplismos?: string[];
    myikes_omades?: {
      kyries: string[];
      synergistes_statheropoiites: string[];
    };
    mixaniki_analysi?: string;
    odigies_ektelesis?: Record<string, string>;
    simeia_prosoxis_lathi?: string[];
    optiki_apeikonisi_dalle_prompts?: {
      domi_kinisis: string;
      prompts: Record<string, string>;
    };
    totalPhases: number;
    phases?: PhaseRecord[];
  }): { exercise: ExerciseRecord; isNew: boolean } {
    const existingIndex = this.exercises.findIndex(
      (e) => e.id.toLowerCase() === exerciseData.id.toLowerCase()
    );

    if (existingIndex >= 0) {
      const existing = this.exercises[existingIndex];
      if (existing.phases.some((p) => p.phaseNumber > exerciseData.totalPhases && (p.outputPath || p.humanReview.status === 'approved'))) {
        throw new Error('Cannot remove an existing image or approved phase during catalog merge');
      }
      existing.totalPhases = exerciseData.totalPhases;
      if (exerciseData.onomasia_askisis) existing.onomasia_askisis = exerciseData.onomasia_askisis;
      if (exerciseData.english_name) existing.english_name = exerciseData.english_name;

      for (let pNum = 1; pNum <= exerciseData.totalPhases; pNum++) {
        const found = existing.phases.find((p) => p.phaseNumber === pNum);
        if (!found) {
          existing.phases.push(
            this.createDefaultPhaseRecord(existing.id, existing.english_name, pNum, exerciseData.totalPhases)
          );
        }
      }

      // Ensure no phantom phases beyond totalPhases (e.g. 5-phase exercise must not have phase 6)
      existing.phases = existing.phases.filter((p) => p.phaseNumber <= exerciseData.totalPhases);
      existing.phases.sort((a, b) => a.phaseNumber - b.phaseNumber);

      this.saveState();
      return { exercise: existing, isNew: false };
    } else {
      const newEx: ExerciseRecord = {
        id: exerciseData.id,
        onomasia_askisis: exerciseData.onomasia_askisis || exerciseData.english_name,
        english_name: exerciseData.english_name,
        epipedo_dyskalias: exerciseData.epipedo_dyskalias || 'Intermediate / Advanced',
        stoxos: exerciseData.stoxos || 'Biomechanical stability, kinetic chain transfer & strength',
        apaitoumenos_exoplismos: exerciseData.apaitoumenos_exoplismos || ['Bodyweight / Free Weights'],
        myikes_omades: exerciseData.myikes_omades || {
          kyries: ['Kinetic Chain Drivers'],
          synergistes_statheropoiites: ['Core Stabilizers', 'Joint Rotators'],
        },
        mixaniki_analysi: exerciseData.mixaniki_analysi || 'Multi-planar biomechanical exercise with precise joint tracking.',
        odigies_ektelesis: exerciseData.odigies_ektelesis || {},
        simeia_prosoxis_lathi: exerciseData.simeia_prosoxis_lathi || ['Maintain spinal neutrality and controlled deceleration.'],
        optiki_apeikonisi_dalle_prompts: exerciseData.optiki_apeikonisi_dalle_prompts || {
          domi_kinisis: `${exerciseData.totalPhases}-phase functional movement pattern`,
          prompts: {},
        },
        totalPhases: exerciseData.totalPhases,
        phases: [],
      };

      for (let pNum = 1; pNum <= exerciseData.totalPhases; pNum++) {
        newEx.phases.push(
          this.createDefaultPhaseRecord(newEx.id, newEx.english_name, pNum, exerciseData.totalPhases)
        );
      }

      this.exercises.push(newEx);
      this.saveState();
      return { exercise: newEx, isNew: true };
    }
  }
}

export const pipelineManager = new PipelineManager();
pipelineManager.initialize();
