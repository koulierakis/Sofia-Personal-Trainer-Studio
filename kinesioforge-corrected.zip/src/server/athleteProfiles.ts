import fs from 'fs';
import path from 'path';
import type { AthleteProfile } from '../types/pipeline';
import { DEFAULT_GREEK_ATHLETE, DEFAULT_GREEK_FEMALE_ATHLETE } from '../types/pipeline';
export type { AthleteProfile };
export { DEFAULT_GREEK_ATHLETE, DEFAULT_GREEK_FEMALE_ATHLETE };

const STORAGE_DIR = path.resolve(process.cwd(), 'public/storage');
const ATHLETES_FILE = path.join(STORAGE_DIR, 'athlete_profiles.json');

export class AthleteProfileManager {
  private profiles: AthleteProfile[] = [];

  constructor() {
    this.loadProfiles();
  }

  private loadProfiles() {
    if (!fs.existsSync(STORAGE_DIR)) {
      fs.mkdirSync(STORAGE_DIR, { recursive: true });
    }

    if (fs.existsSync(ATHLETES_FILE)) {
      try {
        const raw = fs.readFileSync(ATHLETES_FILE, 'utf8');
        this.profiles = JSON.parse(raw);
        // Ensure both standard male and female profiles are present
        if (!this.profiles.some((p) => p.id === DEFAULT_GREEK_ATHLETE.id)) {
          this.profiles.unshift(DEFAULT_GREEK_ATHLETE);
        }
        if (!this.profiles.some((p) => p.id === DEFAULT_GREEK_FEMALE_ATHLETE.id)) {
          this.profiles.push(DEFAULT_GREEK_FEMALE_ATHLETE);
        }
      } catch (err) {
        console.error('Error reading athlete profiles:', err);
        this.profiles = [DEFAULT_GREEK_ATHLETE, DEFAULT_GREEK_FEMALE_ATHLETE];
        this.saveProfiles();
      }
    } else {
      this.profiles = [DEFAULT_GREEK_ATHLETE, DEFAULT_GREEK_FEMALE_ATHLETE];
      this.saveProfiles();
    }
  }

  public saveProfiles(): void {
    try {
      if (!fs.existsSync(STORAGE_DIR)) {
        fs.mkdirSync(STORAGE_DIR, { recursive: true });
      }
      fs.writeFileSync(ATHLETES_FILE, JSON.stringify(this.profiles, null, 2), 'utf8');
    } catch (err) {
      console.error('Failed to save athlete profiles:', err);
    }
  }

  public getProfiles(): AthleteProfile[] {
    return this.profiles;
  }

  public getProfileById(id: string): AthleteProfile | undefined {
    return this.profiles.find((p) => p.id === id);
  }

  public getDefaultProfile(): AthleteProfile {
    return this.profiles.find((p) => p.isDefault) || DEFAULT_GREEK_ATHLETE;
  }

  public addProfile(profile: Omit<AthleteProfile, 'id'>): AthleteProfile {
    const id = `ath-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const newProfile: AthleteProfile = { ...profile, id };
    if (newProfile.isDefault) {
      this.profiles.forEach((p) => (p.isDefault = false));
    }
    this.profiles.push(newProfile);
    this.saveProfiles();
    return newProfile;
  }

  public updateProfile(id: string, updates: Partial<AthleteProfile>): AthleteProfile | null {
    const profile = this.getProfileById(id);
    if (!profile) return null;
    if (updates.isDefault) {
      this.profiles.forEach((p) => (p.isDefault = false));
    }
    Object.assign(profile, updates);
    this.saveProfiles();
    return profile;
  }
}

export const athleteManager = new AthleteProfileManager();
