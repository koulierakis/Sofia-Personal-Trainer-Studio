export interface WorkflowTemplate {
  id: string;
  name: string;
  category: 'SDXL' | 'FLUX' | 'ControlNet' | 'Refinement' | 'Sequence';
  description: string;
  targetGpu: string;
  recommendedVramGb: number;
  requiredNodes: string[];
  requiredCheckpoints: string[];
  workflowJson: Record<string, any>;
}

export const WORKFLOW_TEMPLATES: WorkflowTemplate[] = [
  {
    id: 'wf-01-sdxl-txt2img-rtx3060',
    name: '1. SDXL Text-to-Image (RTX 3060 12GB Baseline)',
    category: 'SDXL',
    description:
      'Standard high-fidelity SDXL prompt-to-image workflow optimized for 1024x1024 generation within 12GB VRAM constraints via --medvram.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'EmptyLatentImage', 'CLIPTextEncode', 'VAEDecode', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors'],
    workflowJson: {
      '3': {
        inputs: {
          seed: 42,
          steps: 28,
          cfg: 7.0,
          sampler_name: 'euler_ancestral',
          scheduler: 'karras',
          denoise: 1,
          model: ['4', 0],
          positive: ['6', 0],
          negative: ['7', 0],
          latent_image: ['5', 0],
        },
        class_type: 'KSampler',
      },
      '4': {
        inputs: { ckpt_name: 'sd_xl_base_1.0.safetensors' },
        class_type: 'CheckpointLoaderSimple',
      },
      '5': {
        inputs: { width: 1024, height: 1024, batch_size: 1 },
        class_type: 'EmptyLatentImage',
      },
      '6': {
        inputs: {
          text: 'Athletic Greek male under 30 in black gym clothes, modern minimal dark luxury gym, cinematic rim lighting, 8k photo',
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '7': {
        inputs: {
          text: 'blurry, deformed, cartoon, vector, 3d render, extra limbs, bad anatomy, text, watermark',
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '8': {
        inputs: { samples: ['3', 0], vae: ['4', 2] },
        class_type: 'VAEDecode',
      },
      '9': {
        inputs: { filename_prefix: 'KinesioForge_SDXL', images: ['8', 0] },
        class_type: 'SaveImage',
      },
    },
  },
  {
    id: 'wf-02-sdxl-img2img-refinement',
    name: '2. SDXL Image-to-Image Refinement',
    category: 'Refinement',
    description:
      'Refines an existing draft frame or anatomical position at denoise 0.35-0.55 while keeping underlying joint kinematics intact.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'LoadImage', 'VAEEncode', 'CLIPTextEncode', 'VAEDecode', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors'],
    workflowJson: {
      '3': {
        inputs: {
          seed: 12345,
          steps: 25,
          cfg: 6.5,
          sampler_name: 'dpmpp_2m_sde_gpu',
          scheduler: 'karras',
          denoise: 0.45,
          model: ['4', 0],
          positive: ['6', 0],
          negative: ['7', 0],
          latent_image: ['10', 0],
        },
        class_type: 'KSampler',
      },
      '4': {
        inputs: { ckpt_name: 'sd_xl_base_1.0.safetensors' },
        class_type: 'CheckpointLoaderSimple',
      },
      '10': {
        inputs: { pixels: ['11', 0], vae: ['4', 2] },
        class_type: 'VAEEncode',
      },
      '11': {
        inputs: { image: 'input_reference.png', upload: 'image' },
        class_type: 'LoadImage',
      },
      '6': {
        inputs: {
          text: 'Athletic Greek male executing exercise movement, photorealistic 8k, crisp muscular definition',
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '7': {
        inputs: { text: 'blurry, cartoon, deformed, lowres', clip: ['4', 1] },
        class_type: 'CLIPTextEncode',
      },
      '8': {
        inputs: { samples: ['3', 0], vae: ['4', 2] },
        class_type: 'VAEDecode',
      },
      '9': {
        inputs: { filename_prefix: 'KinesioForge_Img2Img', images: ['8', 0] },
        class_type: 'SaveImage',
      },
    },
  },
  {
    id: 'wf-03-reference-image-conditioning',
    name: '3. Reference-Image Assisted Generation',
    category: 'Sequence',
    description:
      'Uses Phase 01 as an visual anchor reference so subsequent movement phases retain matching athlete identity and gym lighting.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'LoadImage', 'ApplyControlNet', 'CLIPTextEncode', 'VAEDecode', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors'],
    workflowJson: {
      '3': {
        inputs: {
          seed: 777,
          steps: 30,
          cfg: 7.0,
          sampler_name: 'euler_ancestral',
          scheduler: 'karras',
          denoise: 0.8,
          model: ['4', 0],
          positive: ['6', 0],
          negative: ['7', 0],
          latent_image: ['5', 0],
        },
        class_type: 'KSampler',
      },
      '4': {
        inputs: { ckpt_name: 'sd_xl_base_1.0.safetensors' },
        class_type: 'CheckpointLoaderSimple',
      },
      '5': {
        inputs: { width: 1024, height: 1024, batch_size: 1 },
        class_type: 'EmptyLatentImage',
      },
      '6': {
        inputs: {
          text: 'Identical Greek athlete from phase 1 transitioning into eccentric descent, identical studio lighting and black gym wear',
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '7': {
        inputs: { text: 'different person, face distortion, blurry, cartoon', clip: ['4', 1] },
        class_type: 'CLIPTextEncode',
      },
      '8': {
        inputs: { samples: ['3', 0], vae: ['4', 2] },
        class_type: 'VAEDecode',
      },
      '9': {
        inputs: { filename_prefix: 'KinesioForge_Reference', images: ['8', 0] },
        class_type: 'SaveImage',
      },
    },
  },
  {
    id: 'wf-04-controlnet-openpose',
    name: '4. Pose-Conditioned Generation (ControlNet OpenPose)',
    category: 'ControlNet',
    description:
      'Extracts biomechanical joint skeleton from reference frame to guide exact knee angles, hip hinge, and barbell alignment.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'ControlNetLoader', 'ControlNetApplyAdvanced', 'OpenposePreprocessor', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors', 'control-lora-openposeXL2-rank256.safetensors'],
    workflowJson: {
      '1': {
        inputs: { control_net_name: 'control-lora-openposeXL2-rank256.safetensors' },
        class_type: 'ControlNetLoader',
      },
      '2': {
        inputs: { ckpt_name: 'sd_xl_base_1.0.safetensors' },
        class_type: 'CheckpointLoaderSimple',
      },
      '3': {
        inputs: {
          seed: 8888,
          steps: 28,
          cfg: 7.0,
          sampler_name: 'euler_ancestral',
          scheduler: 'karras',
          denoise: 1.0,
          model: ['2', 0],
          positive: ['6', 0],
          negative: ['7', 0],
          latent_image: ['5', 0],
        },
        class_type: 'KSampler',
      },
      '5': {
        inputs: { width: 1024, height: 1024, batch_size: 1 },
        class_type: 'EmptyLatentImage',
      },
      '6': {
        inputs: { text: 'Athletic Greek male in deep Cossack squat pose, photorealistic', clip: ['2', 1] },
        class_type: 'CLIPTextEncode',
      },
      '7': {
        inputs: { text: 'bad anatomy, missing limbs, distorted joints', clip: ['2', 1] },
        class_type: 'CLIPTextEncode',
      },
      '8': {
        inputs: { samples: ['3', 0], vae: ['2', 2] },
        class_type: 'VAEDecode',
      },
      '9': {
        inputs: { filename_prefix: 'KinesioForge_Pose', images: ['8', 0] },
        class_type: 'SaveImage',
      },
    },
  },
  {
    id: 'wf-05-multi-phase-sequence-generator',
    name: '5. Multi-Phase Exercise Sequence Batch',
    category: 'Sequence',
    description:
      'Iterative batch pipeline executing phases 1 through 6 sequentially with consistent seed lineage and shared CLIP prompt anchors.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'EmptyLatentImage', 'CLIPTextEncode', 'VAEDecode', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors'],
    workflowJson: {
      'note': 'Sequencer managed via KinesioForge Queue with per-phase prompt injection',
    },
  },
  {
    id: 'wf-06-selective-single-phase-regen',
    name: '6. Selective Single-Phase Regeneration',
    category: 'Refinement',
    description:
      'Regenerates only an individual failed or flagged phase (e.g. Phase 06) without touching approved preceding frames.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'EmptyLatentImage', 'CLIPTextEncode', 'VAEDecode', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors'],
    workflowJson: {
      'note': 'Targeted single-phase runner connected to /api/exercises/:id/phases/:phase/generate',
    },
  },
  {
    id: 'wf-07-flux-schnell-4step-medvram',
    name: '7. FLUX.1 Schnell (4-Step / fp8 / medvram)',
    category: 'FLUX',
    description:
      'Ultra-fast 4-step distilled generation utilizing fp8 weights and lowvram/medvram for RTX 3060 compatibility.',
    targetGpu: 'NVIDIA RTX 3060 12GB (Requires FP8 checkpoint & ComfyUI FLUX nodes)',
    recommendedVramGb: 12,
    requiredNodes: ['UNETLoader', 'DualCLIPLoader', 'VAELoader', 'KSamplerSelect', 'BasicScheduler', 'SamplerCustomAdvanced'],
    requiredCheckpoints: ['flux1-schnell-fp8.safetensors', 't5xxl_fp8_e4m3fn.safetensors', 'clip_l.safetensors', 'ae.safetensors'],
    workflowJson: {
      'note': 'Requires FLUX.1 fp8 weights in ComfyUI/models/unet/ and dual CLIP encoders',
    },
  },
  {
    id: 'wf-08-photorealistic-rendering-engine',
    name: '8. Photorealistic Exercise Rendering Engine',
    category: 'SDXL',
    description:
      'Uses RealVisXL / JuggernautXL for extreme skin texture fidelity, realistic gym floor reflections, and sweat sheen.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'EmptyLatentImage', 'CLIPTextEncode', 'VAEDecode', 'SaveImage'],
    requiredCheckpoints: ['realvisxl_v40.safetensors'],
    workflowJson: {
      '3': {
        inputs: {
          seed: 99999,
          steps: 32,
          cfg: 6.0,
          sampler_name: 'dpmpp_2m_sde_gpu',
          scheduler: 'karras',
          denoise: 1,
          model: ['4', 0],
          positive: ['6', 0],
          negative: ['7', 0],
          latent_image: ['5', 0],
        },
        class_type: 'KSampler',
      },
      '4': {
        inputs: { ckpt_name: 'realvisxl_v40.safetensors' },
        class_type: 'CheckpointLoaderSimple',
      },
      '5': {
        inputs: { width: 1024, height: 1024, batch_size: 1 },
        class_type: 'EmptyLatentImage',
      },
      '6': {
        inputs: {
          text: 'Hyper-photorealistic commercial gym photograph of athletic Greek male, defined serratus anterior, natural skin pores, luxury minimalist gym, 8k raw',
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '7': {
        inputs: { text: 'deformed, cartoon, airbrushed, low detail, fake skin', clip: ['4', 1] },
        class_type: 'CLIPTextEncode',
      },
      '8': {
        inputs: { samples: ['3', 0], vae: ['4', 2] },
        class_type: 'VAEDecode',
      },
      '9': {
        inputs: { filename_prefix: 'KinesioForge_RealVis', images: ['8', 0] },
        class_type: 'SaveImage',
      },
    },
  },
  {
    id: 'wf-09-anatomical-inpaint-correction',
    name: '9. Anatomical Inpaint & Hand/Grip Correction',
    category: 'Refinement',
    description:
      'Masks hand grip or barbell collar to fix thumb placement or finger count while leaving the rest of the athlete intact.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['KSampler', 'CheckpointLoaderSimple', 'LoadImageMask', 'VAEEncodeForInpaint', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors'],
    workflowJson: {
      'note': 'Inpaint workflow requiring masked image input',
    },
  },
  {
    id: 'wf-10-consistent-athlete-identity',
    name: '10. Consistent Athlete Identity Workflow',
    category: 'Sequence',
    description:
      'IP-Adapter / FaceID workflow locking facial structure and body hair across all 64 movement frames.',
    targetGpu: 'NVIDIA RTX 3060 12GB',
    recommendedVramGb: 12,
    requiredNodes: ['IPAdapterModelLoader', 'IPAdapterApply', 'CheckpointLoaderSimple', 'SaveImage'],
    requiredCheckpoints: ['sd_xl_base_1.0.safetensors', 'ip-adapter-plus_sdxl_vit-h.safetensors'],
    workflowJson: {
      'note': 'Requires ComfyUI_IPAdapter_plus custom node and IP-Adapter weights',
    },
  },
];

export function getWorkflowById(id: string): WorkflowTemplate | undefined {
  return WORKFLOW_TEMPLATES.find((w) => w.id === id);
}

export function checkWorkflowCompatibility(
  workflow: WorkflowTemplate,
  installedCheckpoints: string[]
): { isCompatible: boolean; missingCheckpoints: string[]; missingNodes: string[] } {
  const missingCheckpoints = workflow.requiredCheckpoints.filter(
    (c) => !installedCheckpoints.some((ic) => ic.toLowerCase().includes(c.toLowerCase().split('.')[0]))
  );

  return {
    isCompatible: missingCheckpoints.length === 0,
    missingCheckpoints,
    missingNodes: [],
  };
}
