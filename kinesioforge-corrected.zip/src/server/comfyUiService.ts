export interface ComfySystemStats {
  online: boolean;
  serverUrl: string;
  error?: string;
  device?: string;
  vramTotalGb?: number;
  vramFreeGb?: number;
  vramOptimized: boolean;
  availableCheckpoints: string[];
}

export class ComfyUiService {
  private serverUrl: string;
  private clientId: string;

  constructor(serverUrl: string = 'http://127.0.0.1:8188') {
    this.serverUrl = serverUrl.replace(/\/$/, '');
    this.clientId = 'kinesioforge-pipeline-' + Math.random().toString(36).substring(2, 9);
  }

  public setServerUrl(url: string) {
    this.serverUrl = url.replace(/\/$/, '');
  }

  public getServerUrl(): string {
    return this.serverUrl;
  }

  /**
   * Safe non-blocking connection check. Never throws, reports offline gracefully.
   */
  public async checkConnectivity(): Promise<ComfySystemStats> {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2500);

      const resp = await fetch(`${this.serverUrl}/system_stats`, {
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (!resp.ok) {
        return {
          online: false,
          serverUrl: this.serverUrl,
          error: `HTTP ${resp.status} ${resp.statusText}`,
          vramOptimized: false,
          availableCheckpoints: [],
        };
      }

      const data = (await resp.json()) as any;
      const device = data?.devices?.[0]?.name || 'Unknown device';
      const vramTotal = data?.devices?.[0]?.vram_total
        ? Math.round((data.devices[0].vram_total / (1024 * 1024 * 1024)) * 10) / 10
        : undefined;
      const vramFree = data?.devices?.[0]?.vram_free
        ? Math.round((data.devices[0].vram_free / (1024 * 1024 * 1024)) * 10) / 10
        : undefined;

      const checkpoints = await this.getAvailableCheckpoints();

      return {
        online: true,
        serverUrl: this.serverUrl,
        device,
        vramTotalGb: vramTotal,
        vramFreeGb: vramFree,
        vramOptimized: Array.isArray(data?.system?.argv) && data.system.argv.some((arg: string) => ['--lowvram', '--novram', '--reserve-vram'].includes(arg)),
        availableCheckpoints: checkpoints,
      };
    } catch (err: any) {
      return {
        online: false,
        serverUrl: this.serverUrl,
        error: err.name === 'AbortError' ? 'Connection timed out (ComfyUI server offline)' : (err.message || 'Offline'),
        vramOptimized: false,
        availableCheckpoints: [],
      };
    }
  }

  public async getAvailableCheckpoints(): Promise<string[]> {
    try {
      const resp = await fetch(`${this.serverUrl}/object_info/CheckpointLoaderSimple`, {
        signal: AbortSignal.timeout(2000),
      });
      if (!resp.ok) return [];
      const info = (await resp.json()) as any;
      const list = info?.CheckpointLoaderSimple?.input?.required?.ckpt_name?.[0];
      return Array.isArray(list) ? list : [];
    } catch {
      return [];
    }
  }

  /**
   * Generates RTX 3060 12GB compliant workflow payload
   */
  public generateWorkflow(
    prompt: string,
    checkpoint: string = 'v1-5-pruned-emaonly.safetensors',
    seed: number = Math.floor(Math.random() * 1000000000),
    steps: number = 28,
    cfg: number = 7.0
  ) {
    const negativePrompt =
      'blurry, schematic, cartoon, 3d render, vector illustration, low resolution, anatomical distortion, missing limbs, bad hands, fake, extra fingers, text, watermark';

    return {
      '3': {
        inputs: {
          seed,
          steps,
          cfg,
          sampler_name: 'euler_ancestral',
          scheduler: 'karras',
          denoise: 1,
          model: ['4', 0],
          positive: ['6', 0],
          negative: ['7', 0],
          latent_image: ['5', 0],
        },
        class_type: 'KSampler',
      },
      '4': {
        inputs: {
          ckpt_name: checkpoint,
        },
        class_type: 'CheckpointLoaderSimple',
      },
      '5': {
        inputs: {
          width: 1024,
          height: 1024,
          batch_size: 1,
        },
        class_type: 'EmptyLatentImage',
      },
      '6': {
        inputs: {
          text: prompt,
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '7': {
        inputs: {
          text: negativePrompt,
          clip: ['4', 1],
        },
        class_type: 'CLIPTextEncode',
      },
      '8': {
        inputs: {
          samples: ['3', 0],
          vae: ['4', 2],
        },
        class_type: 'VAEDecode',
      },
      '9': {
        inputs: {
          filename_prefix: 'KinesioForge',
          images: ['8', 0],
        },
        class_type: 'SaveImage',
      },
    };
  }

  /**
   * Submits prompt to ComfyUI, waits for real generation, and retrieves binary.
   */
  public async executeGeneration(prompt: string, checkpoint?: string): Promise<{ buffer: Buffer; promptId: string }> {
    const workflow = this.generateWorkflow(prompt, checkpoint);

    const postResp = await fetch(`${this.serverUrl}/prompt`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        client_id: this.clientId,
        prompt: workflow,
      }),
    });

    if (!postResp.ok) {
      const errText = await postResp.text();
      throw new Error(`ComfyUI queue failed (${postResp.status}): ${errText}`);
    }

    const data = (await postResp.json()) as any;
    const promptId = data.prompt_id;
    if (!promptId) {
      throw new Error('ComfyUI returned no prompt_id');
    }

    // Poll history for outputs (up to 120 seconds)
    const startTime = Date.now();
    let imageFilename = '';
    let imageSubfolder = '';
    let imageType = 'output';

    while (Date.now() - startTime < 120000) {
      await new Promise((r) => setTimeout(r, 1500));
      const histResp = await fetch(`${this.serverUrl}/history/${promptId}`);
      if (!histResp.ok) continue;

      const histData = (await histResp.json()) as any;
      const historyItem = histData[promptId];
      if (historyItem && historyItem.outputs) {
        const nodeOutputs = Object.values(historyItem.outputs) as any[];
        for (const out of nodeOutputs) {
          if (out.images && out.images.length > 0) {
            imageFilename = out.images[0].filename;
            imageSubfolder = out.images[0].subfolder || '';
            imageType = out.images[0].type || 'output';
            break;
          }
        }
        if (imageFilename) break;
      }
    }

    if (!imageFilename) {
      throw new Error('ComfyUI execution timed out waiting for image output.');
    }

    // Fetch actual image binary
    const viewUrl = `${this.serverUrl}/view?filename=${encodeURIComponent(imageFilename)}&subfolder=${encodeURIComponent(imageSubfolder)}&type=${encodeURIComponent(imageType)}`;
    const imgResp = await fetch(viewUrl);
    if (!imgResp.ok) {
      throw new Error(`Failed to retrieve generated image from ${viewUrl}: HTTP ${imgResp.status}`);
    }

    const arrayBuffer = await imgResp.arrayBuffer();
    const buffer = Buffer.from(arrayBuffer);

    // Validate PNG header
    if (buffer.length < 8 || buffer[0] !== 0x89 || buffer[1] !== 0x50 || buffer[2] !== 0x4e || buffer[3] !== 0x47) {
      throw new Error('Retrieved file is not a valid PNG binary image.');
    }

    return { buffer, promptId };
  }
}

export const comfyUiService = new ComfyUiService();
