import fs from 'fs';
import path from 'path';
import { pipelineManager } from './pipelineManager';
import { productionQueue } from './productionQueue';

export interface SofiaExerciseImport {
  id: string;
  name: string;
  greekName?: string;
  category?: string;
  phasesCount?: number;
  phases?: Array<{
    phaseNumber: number;
    title: string;
    description?: string;
    promptText?: string;
  }>;
}

export interface SofiaDryRunReport {
  timestamp: string;
  totalSofiaExercises: number;
  totalCalculatedTasks: number;
  existingMatchedExercises: number;
  newExercisesDiscovered: number;
  missingPhotographyTasks: number;
  alreadyApprovedCount: number;
  exercises: Array<{
    id: string;
    name: string;
    phasesRequired: number;
    matchedInKinesioForge: boolean;
    missingPhases: number[];
  }>;
}

const STORAGE_DIR = path.resolve(process.cwd(), 'public/storage');
const SOFIA_CATALOG_FILE = path.join(STORAGE_DIR, 'sofia_imported_catalog.json');

export class SofiaCatalogService {
  private importedCatalog: SofiaExerciseImport[] = [];

  constructor() {
    this.loadCatalog();
  }

  private loadCatalog() {
    if (fs.existsSync(SOFIA_CATALOG_FILE)) {
      try {
        const raw = fs.readFileSync(SOFIA_CATALOG_FILE, 'utf8');
        this.importedCatalog = JSON.parse(raw);
      } catch (e) {
        this.importedCatalog = [];
      }
    }
  }

  public getImportedCatalog(): SofiaExerciseImport[] {
    return this.importedCatalog;
  }

  /**
   * Performs a dry-run analysis on an uploaded Sofia catalog JSON
   * without modifying live state.
   */
  public analyzeSofiaCatalogDryRun(rawInput: any): SofiaDryRunReport {
    let catalogJson: any[];
    if (typeof rawInput === 'string') {
      try {
        rawInput = JSON.parse(rawInput);
      } catch (e: any) {
        throw new Error('Invalid JSON string provided for catalog: ' + e.message);
      }
    }

    if (Array.isArray(rawInput)) {
      catalogJson = rawInput;
    } else if (rawInput && Array.isArray(rawInput.exercises)) {
      catalogJson = rawInput.exercises;
    } else if (rawInput && Array.isArray(rawInput.catalog)) {
      catalogJson = rawInput.catalog;
    } else if (rawInput && Array.isArray(rawInput.items)) {
      catalogJson = rawInput.items;
    } else {
      throw new Error('Invalid catalog format: Root must be a JSON array of exercises or an object with an exercises/catalog array.');
    }

    const currentExercises = pipelineManager.getAllExercises();
    let totalCalculatedTasks = 0;
    let existingMatched = 0;
    let newExercises = 0;
    let missingPhasesCount = 0;

    const exerciseReports = catalogJson.map((item, idx) => {
      const id = item.id || `sofia-ex-${idx + 1}`;
      const name = item.name || item.title || item.greekName || id;
      // Resolve exact biomechanical phases (4, 5, or 6; never hallucinate 6 on 5-phase exercises)
      let phasesRequired = 6;
      if (Array.isArray(item.phases) && item.phases.length > 0) {
        phasesRequired = Math.max(4, Math.min(item.phases.length, 6));
      } else if (typeof item.phasesCount === 'number') {
        phasesRequired = Math.max(4, Math.min(item.phasesCount, 6));
      } else if (item.totalPhases) {
        phasesRequired = Math.max(4, Math.min(item.totalPhases, 6));
      }
      totalCalculatedTasks += phasesRequired;

      const matched = currentExercises.find(
        (ce) => ce.id.toLowerCase() === id.toLowerCase() || ce.english_name.toLowerCase() === name.toLowerCase()
      );

      const missing: number[] = [];
      for (let p = 1; p <= phasesRequired; p++) {
        const ph = matched?.phases.find((phase) => phase.phaseNumber === p);
        if (!ph || ph.provenance.type !== 'GENERATED_AI_VERIFIED') {
          missing.push(p);
        }
      }

      if (matched) {
        existingMatched++;
      } else {
        newExercises++;
      }

      missingPhasesCount += missing.length;

      return {
        id,
        name,
        phasesRequired,
        matchedInKinesioForge: !!matched,
        missingPhases: missing,
      };
    });

    return {
      timestamp: new Date().toISOString(),
      totalSofiaExercises: catalogJson.length,
      totalCalculatedTasks,
      existingMatchedExercises: existingMatched,
      newExercisesDiscovered: newExercises,
      missingPhotographyTasks: missingPhasesCount,
      alreadyApprovedCount: totalCalculatedTasks - missingPhasesCount,
      exercises: exerciseReports,
    };
  }

  /**
   * Commits the Sofia Catalog into live KinesioForge pipeline:
   * 1. Adds or updates ExerciseRecords with verified unique IDs.
   * 2. Recognizes 4, 5, or 6 movement phases without hallucinating phantom phases.
   * 3. Retains any existing verified images and approvals.
   * 4. Enqueues production jobs in productionQueue idempotently.
   * 5. Persists state to disk.
   */
  public commitSofiaCatalog(rawInput: any): {
    addedCount: number;
    updatedCount: number;
    scheduledTasks: number;
    totalExercises: number;
    totalPhases: number;
  } {
    let catalogJson: any[];
    if (typeof rawInput === 'string') {
      try {
        rawInput = JSON.parse(rawInput);
      } catch (e: any) {
        throw new Error('Invalid JSON string: ' + e.message);
      }
    }
    if (Array.isArray(rawInput)) {
      catalogJson = rawInput;
    } else if (rawInput && Array.isArray(rawInput.exercises)) {
      catalogJson = rawInput.exercises;
    } else if (rawInput && Array.isArray(rawInput.catalog)) {
      catalogJson = rawInput.catalog;
    } else if (rawInput && Array.isArray(rawInput.items)) {
      catalogJson = rawInput.items;
    } else {
      catalogJson = [rawInput];
    }

    let addedCount = 0;
    let updatedCount = 0;
    const modifiedExercises: any[] = [];

    for (let idx = 0; idx < catalogJson.length; idx++) {
      const item = catalogJson[idx];
      const rawId = item.id || item.slug || `sofia-ex-${idx + 1}`;
      const sanitizedId = String(rawId).toLowerCase().replace(/[^a-z0-9-_]/g, '-');
      const englishName = item.name || item.englishName || item.title || `Exercise ${idx + 1}`;
      const greekName = item.greekName || item.onomasia_askisis || item.name || englishName;

      // Determine true biomechanical phases count (4, 5, or 6)
      let totalPhases = 6;
      if (Array.isArray(item.phases) && item.phases.length > 0) {
        totalPhases = Math.max(4, Math.min(item.phases.length, 6));
      } else if (typeof item.phasesCount === 'number') {
        totalPhases = Math.max(4, Math.min(item.phasesCount, 6));
      } else if (item.totalPhases) {
        totalPhases = Math.max(4, Math.min(item.totalPhases, 6));
      }

      const { exercise, isNew } = pipelineManager.addOrMergeExercise({
        id: sanitizedId,
        english_name: englishName,
        onomasia_askisis: greekName,
        epipedo_dyskalias: item.difficulty || item.epipedo_dyskalias || 'Intermediate / Advanced',
        stoxos: item.targetObjective || item.stoxos || 'Biomechanical stability, kinetic chain transfer & strength',
        apaitoumenos_exoplismos: Array.isArray(item.equipment) ? item.equipment : ['Bodyweight / Free Weights'],
        totalPhases,
      });

      // Preserve authoritative Sofia phase wording for ungenerated work only.
      for (const source of Array.isArray(item.phases) ? item.phases : []) {
        const phase = exercise.phases.find((p) => p.phaseNumber === source.phaseNumber);
        if (!phase || phase.outputPath || phase.humanReview.status === 'approved') continue;
        if (typeof source.title === 'string') phase.phaseName = source.title;
        if (typeof source.promptText === 'string' && source.promptText.trim()) phase.fullPrompt = source.promptText;
      }
      pipelineManager.saveState();

      if (isNew) {
        addedCount++;
      } else {
        updatedCount++;
      }
      modifiedExercises.push(exercise);
    }

    // Idempotently enqueue missing photography production jobs
    const scheduledTasks = productionQueue.addOrSyncJobsForExercises(modifiedExercises);

    // Save committed catalog for reference
    try {
      if (!fs.existsSync(STORAGE_DIR)) {
        fs.mkdirSync(STORAGE_DIR, { recursive: true });
      }
      fs.writeFileSync(SOFIA_CATALOG_FILE, JSON.stringify(catalogJson, null, 2), 'utf8');
      this.importedCatalog = catalogJson;
    } catch (e) {
      console.error('Error saving sofia_imported_catalog.json:', e);
    }

    const allExercises = pipelineManager.getAllExercises();
    let totalPhasesCount = 0;
    allExercises.forEach((e) => (totalPhasesCount += e.phases.length));

    return {
      addedCount,
      updatedCount,
      scheduledTasks,
      totalExercises: allExercises.length,
      totalPhases: totalPhasesCount,
    };
  }
}

export const sofiaCatalogService = new SofiaCatalogService();
