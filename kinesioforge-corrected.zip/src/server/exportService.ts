import JSZip from 'jszip';
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { pipelineManager } from './pipelineManager';
import { comfyUiService } from './comfyUiService';
import { geminiService } from './geminiService';

import sharp from 'sharp';

export class ExportService {
  /**
   * Generates a truthful KinesioForge Studio batch ZIP archive
   */
  public async createKinesioForgeBatch(includeFixtures: boolean = true): Promise<Buffer> {
    const zip = new JSZip();
    const exercises = pipelineManager.getAllExercises();
    const comfyStatus = await comfyUiService.checkConnectivity();
    const geminiStatus = await geminiService.checkStatus();
    const stats = pipelineManager.getIntegrityStats(
      {
        online: comfyStatus.online,
        url: comfyStatus.serverUrl,
        message: comfyStatus.error || 'Connected',
        vramOptimized: comfyStatus.vramOptimized,
      },
      geminiStatus
    );

    const manifestImages: any[] = [];
    let exportedImageCount = 0;

    for (const ex of exercises) {
      for (const ph of ex.phases) {
        if (!ph.outputPath) continue;

        // Skip fixtures if user only wants production-verified
        if (!includeFixtures && ph.provenance.type === 'PROGRAMMATIC_SEED') {
          continue;
        }

        const fullPath = path.resolve(process.cwd(), 'public', ph.outputPath);
        if (fs.existsSync(fullPath)) {
          const buffer = fs.readFileSync(fullPath);
          const hash = crypto.createHash('sha256').update(buffer).digest('hex');

          const zipPath = `${ex.id}/phase-${String(ph.phaseNumber).padStart(2, '0')}.png`;
          zip.file(zipPath, buffer);
          exportedImageCount++;

          manifestImages.push({
            id: ph.id,
            exerciseId: ph.exerciseId,
            exerciseName: ph.exerciseName,
            phaseNumber: ph.phaseNumber,
            phaseKey: ph.phaseKey,
            path: zipPath,
            status: ph.humanReview.status,
            prompt: ph.fullPrompt,
            modelUsed: ph.provenance.model,
            provenance: {
              type: ph.provenance.type,
              provider: ph.provenance.provider,
              model: ph.provenance.model,
              generationTimestamp: ph.provenance.generationTimestamp,
              isSeeded: ph.provenance.isSeeded,
              device: ph.provenance.device,
              sha256: hash,
              sizeBytes: buffer.length,
            },
            qcReport: ph.qcReport,
            humanReview: ph.humanReview,
          });
        }
      }
    }

    const manifest = {
      project: 'KinesioForge AI Image Engine',
      exportedAt: new Date().toISOString(),
      exportType: 'KinesioForge Batch Archive',
      totalExercises: exercises.length,
      totalRequiredPhases: stats.totalPhases,
      totalExportedImages: exportedImageCount,
      genuineAIGenerated: stats.genuineAIGenerated,
      verifiedProductionReady: stats.verifiedProductionReady,
      programmaticSeedFixtures: stats.programmaticSeeds,
      missingPhases: stats.missingPhases,
      duplicateBinariesDetected: stats.duplicateDetections,
      isProductionReady: stats.isProductionReady,
      readinessCategories: stats.readinessCategories,
      images: manifestImages,
    };

    const auditReport = {
      auditTimestamp: new Date().toISOString(),
      integritySummary: {
        totalExercises: exercises.length,
        totalRequiredPhases: stats.totalPhases,
        imagesExported: exportedImageCount,
        missingPhasesCount: stats.missingPhases,
        programmaticSilhouetteCount: stats.programmaticSeeds,
        genuineProductionPhotographCount: stats.verifiedProductionReady,
        isProductionReady: stats.isProductionReady,
      },
      duplicateAnalysis: stats.duplicateDetections.map((d) => ({
        sha256: d.hash,
        impactedPhases: d.phases.map((p) => `${p.exerciseId} (Phase ${p.phaseNumber})`),
        evaluation: 'CRITICAL: Identical binary data reused across distinct movement phases.',
      })),
      missingPhasesInventory: exercises.flatMap((ex) =>
        ex.phases
          .filter((p) => !p.outputPath || p.provenance.type === 'PLACEHOLDER')
          .map((p) => ({
            exerciseId: ex.id,
            exerciseName: ex.english_name,
            phaseNumber: p.phaseNumber,
            phaseName: p.phaseName,
            prompt: p.fullPrompt,
          }))
      ),
      readinessVerdict: stats.isProductionReady
        ? 'PRODUCTION_CONTENT_READY: All movement phases completed with genuine verified photography.'
        : `PRODUCTION_CONTENT_INCOMPLETE: Cannot be deployed to commercial client. ${stats.missingPhases} phases missing; ${stats.programmaticSeeds} existing images are development vector fixtures.`,
    };

    zip.file('manifest.json', JSON.stringify(manifest, null, 2));
    zip.file('audit_report.json', JSON.stringify(auditReport, null, 2));
    zip.file('exercises_metadata.json', JSON.stringify(exercises, null, 2));

    return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  }

  /**
   * Generates a truthful Sofia Personal Trainer Studio bundle
   * with real WebP images matching public/images/exercises/{exercise-id}/{phaseNumber}.webp
   * and complete exercise-images.json, catalog.json, manifest.json, and audit_report.json.
   */
  public async createSofiaBundle(includeFixtures: boolean = false): Promise<Buffer> {
    const zip = new JSZip();
    const exercises = pipelineManager.getAllExercises();
    const comfyStatus = await comfyUiService.checkConnectivity();
    const geminiStatus = await geminiService.checkStatus();
    const stats = pipelineManager.getIntegrityStats(
      {
        online: comfyStatus.online,
        url: comfyStatus.serverUrl,
        message: comfyStatus.error || 'Connected',
        vramOptimized: comfyStatus.vramOptimized,
      },
      geminiStatus
    );

    let exportedImageCount = 0;
    const catalogExercises: any[] = [];
    const exerciseImagesMap: Record<string, any> = {};

    for (const ex of exercises) {
      const phaseEntries: any[] = [];
      const exercisePhasesMap: Record<number, any> = {};

      for (const ph of ex.phases) {
        let relativeWebpPath: string | null = null;
        let imageChecksum: string | null = ph.imageChecksum || null;

        if (ph.outputPath) {
          if (!includeFixtures && ph.provenance.type === 'PROGRAMMATIC_SEED') {
            // Skip fixture
          } else {
            const fullPath = path.resolve(process.cwd(), 'public', ph.outputPath);
            if (fs.existsSync(fullPath)) {
              const buffer = fs.readFileSync(fullPath);
              imageChecksum = crypto.createHash('sha256').update(buffer).digest('hex');

              // Real WebP conversion using sharp
              const webpBuffer = await sharp(buffer).webp({ quality: 90 }).toBuffer();
              if ((await sharp(webpBuffer).metadata()).format !== 'webp') {
                throw new Error('Sofia export conversion did not produce WebP');
              }
              imageChecksum = crypto.createHash('sha256').update(webpBuffer).digest('hex');

              // Canonical Sofia Studio path structure
              const webpTargetPath = `public/images/exercises/${ex.id}/${ph.phaseNumber}.webp`;
              zip.file(webpTargetPath, webpBuffer);

              // Secondary mirror path for backward compatibility
              zip.file(`images/exercises/${ex.id}/${ph.phaseNumber}.webp`, webpBuffer);

              relativeWebpPath = webpTargetPath;
              exportedImageCount++;
            }
          }
        }

        const isApproved =
          ph.humanReview.status === 'approved' && ph.provenance.type === 'GENERATED_AI_VERIFIED';
        const approvalStatus = isApproved ? 'approved' : 'pending_visual_review';

        exercisePhasesMap[ph.phaseNumber] = {
          phaseNumber: ph.phaseNumber,
          phaseName: ph.phaseName,
          imagePath: relativeWebpPath,
          checksum: imageChecksum,
          approvalStatus,
          provenance: ph.provenance.type,
          generation: { provider: ph.provenance.provider, model: ph.provenance.model, generationTimestamp: ph.provenance.generationTimestamp },
          isPhotorealistic: ph.provenance.type === 'GENERATED_AI_VERIFIED',
          isDevelopmentFixture: ph.provenance.type === 'PROGRAMMATIC_SEED',
        };

        phaseEntries.push({
          phaseNumber: ph.phaseNumber,
          phaseName: ph.phaseName,
          key: ph.phaseKey,
          imagePath: relativeWebpPath,
          hasGenuinePhoto: ph.provenance.type === 'GENERATED_AI_VERIFIED',
          isDevelopmentFixture: ph.provenance.type === 'PROGRAMMATIC_SEED',
          status: approvalStatus,
          qcScore: ph.qcReport.overallStatus === 'passed' ? ph.qcReport.biomechanicalScore : 0,
          sha256: imageChecksum,
        });
      }

      exerciseImagesMap[ex.id] = {
        exerciseId: ex.id,
        exerciseName: ex.english_name,
        greekName: ex.onomasia_askisis,
        phases: exercisePhasesMap,
      };

      catalogExercises.push({
        id: ex.id,
        greekName: ex.onomasia_askisis,
        englishName: ex.english_name,
        difficulty: ex.epipedo_dyskalias,
        targetObjective: ex.stoxos,
        equipment: ex.apaitoumenos_exoplismos,
        primaryMuscles: ex.myikes_omades.kyries,
        stabilizerMuscles: ex.myikes_omades.synergistes_statheropoiites,
        biomechanicalAnalysis: ex.mixaniki_analysi,
        executionInstructions: ex.odigies_ektelesis,
        criticalFaults: ex.simeia_prosoxis_lathi,
        totalPhases: ex.totalPhases,
        phases: phaseEntries,
      });
    }

    const sofiaCatalog = {
      sofiaStudioVersion: '2.4.0',
      catalogName: 'KinesioForge Athletic Kinematics & Resistance Curriculum',
      generatedAt: new Date().toISOString(),
      athleteProfile: 'Athletic Greek male / female, black sportswear, minimal luxury studio',
      isProductionReady: stats.isProductionReady,
      readinessStatus: stats.readinessCategories,
      contentSummary: {
        totalExercises: exercises.length,
        totalRequiredPhases: stats.totalPhases,
        packagedImages: exportedImageCount,
        genuinePhotographs: stats.verifiedProductionReady,
        seedFixtures: stats.programmaticSeeds,
        missingPhases: stats.missingPhases,
      },
      exercises: catalogExercises,
    };

    const auditReport = {
      sofiaIntegrationAudit: {
        passed: stats.isProductionReady,
        timestamp: new Date().toISOString(),
        criticalFindings: [
          `Total required phases: ${stats.totalPhases}`,
          `Genuine AI photographs: ${stats.genuineAIGenerated} / ${stats.totalPhases}`,
          `Verified production-ready images: ${stats.verifiedProductionReady} / ${stats.totalPhases}`,
          `Development vector fixtures: ${stats.programmaticSeeds}`,
          `Missing phases: ${stats.missingPhases}`,
          `Duplicate frames detected: ${stats.duplicateCount}`,
        ],
        warning: stats.isProductionReady
          ? 'ALL IMAGES VERIFIED PRODUCTION READY.'
          : 'DO NOT PUBLISH AS COMPLETED PRODUCTION CONTENT UNTIL ALL PHASES ARE GENUINE VERIFIED PHOTOGRAPHS.',
      },
    };

    zip.file('exercise-images.json', JSON.stringify(exerciseImagesMap, null, 2));
    zip.file('catalog.json', JSON.stringify(sofiaCatalog, null, 2));
    zip.file('manifest.json', JSON.stringify(sofiaCatalog, null, 2));
    zip.file('audit_report.json', JSON.stringify(auditReport, null, 2));

    return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  }
}

export const exportService = new ExportService();

