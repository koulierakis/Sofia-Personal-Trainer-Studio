import fs from 'fs';
import path from 'path';
import { pipelineManager } from './pipelineManager';
import { comfyUiService } from './comfyUiService';
import { geminiService } from './geminiService';

export type JobStatus =
  | 'idle'
  | 'queued'
  | 'generating'
  | 'completed'
  | 'failed'
  | 'paused'
  | 'cancelled';

export interface ProductionJob {
  jobId: string;
  exerciseId: string;
  exerciseName: string;
  phaseNumber: number;
  phaseName: string;
  status: JobStatus;
  provider: 'gemini' | 'comfyui';
  modelTarget: string;
  prompt: string;
  priority: number;
  attempts: number;
  maxAttempts: number;
  errorMessage?: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  durationMs?: number;
  outputPath?: string;
  imageChecksum?: string;
}

export interface QueueProgress {
  isRunning: boolean;
  isPaused: boolean;
  totalJobs: number;
  completedJobs: number;
  failedJobs: number;
  activeJobs: number;
  queuedJobs: number;
  percentComplete: number;
  concurrencyLimit: number;
  activeProvider: string;
}

const STORAGE_DIR = path.resolve(process.cwd(), 'public/storage');
const QUEUE_FILE = path.join(STORAGE_DIR, 'production_queue.json');

export class ProductionQueueService {
  private jobs: ProductionJob[] = [];
  private isRunning: boolean = false;
  private isPaused: boolean = false;
  private concurrencyLimit: number = 1; // Conservative for RTX 3060 12GB
  private activeProvider: 'comfyui' | 'gemini' = 'comfyui';
  private processingInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.loadQueue();
  }

  private loadQueue() {
    if (!fs.existsSync(STORAGE_DIR)) {
      fs.mkdirSync(STORAGE_DIR, { recursive: true });
    }

    if (fs.existsSync(QUEUE_FILE)) {
      try {
        const raw = fs.readFileSync(QUEUE_FILE, 'utf8');
        this.jobs = JSON.parse(raw);
      } catch (err) {
        console.error('Error loading production queue:', err);
        this.populateDefaultJobs();
      }
    } else {
      this.populateDefaultJobs();
    }
  }

  public reloadQueueFromDisk(): void {
    if (fs.existsSync(QUEUE_FILE)) {
      try {
        const raw = fs.readFileSync(QUEUE_FILE, 'utf8');
        this.jobs = JSON.parse(raw);
      } catch (err) {
        console.error('Error reloading production queue:', err);
      }
    }
  }

  public populateDefaultJobs(): void {
    const exercises = pipelineManager.getAllExercises();
    this.jobs = [];

    for (const ex of exercises) {
      for (const ph of ex.phases) {
        const isAlreadyApproved =
          ph.provenance.type === 'GENERATED_AI_VERIFIED' && ph.humanReview.status === 'approved';

        const job: ProductionJob = {
          jobId: `job_${ph.id}`,
          exerciseId: ex.id,
          exerciseName: ex.english_name,
          phaseNumber: ph.phaseNumber,
          phaseName: ph.phaseName,
          status: isAlreadyApproved ? 'completed' : 'idle',
          provider: this.activeProvider,
          modelTarget: this.activeProvider === 'comfyui' ? 'sdxl-base-1.0' : 'gemini-3.1-flash-lite-image',
          prompt: ph.fullPrompt,
          priority: 5,
          attempts: 0,
          maxAttempts: 3,
          createdAt: new Date().toISOString(),
          outputPath: ph.outputPath,
          imageChecksum: ph.imageChecksum,
        };

        this.jobs.push(job);
      }
    }

    this.saveQueue();
  }

  public addOrSyncJobsForExercises(exercises: Array<any>): number {
    let newJobsCount = 0;
    for (const ex of exercises) {
      for (const ph of ex.phases) {
        const existingJob = this.jobs.find(
          (j) => j.exerciseId === ex.id && j.phaseNumber === ph.phaseNumber
        );

        if (!existingJob) {
          const isAlreadyApproved =
            ph.provenance?.type === 'GENERATED_AI_VERIFIED' && ph.humanReview?.status === 'approved';

          const job: ProductionJob = {
            jobId: `job_${ph.id}`,
            exerciseId: ex.id,
            exerciseName: ex.english_name,
            phaseNumber: ph.phaseNumber,
            phaseName: ph.phaseName,
            status: isAlreadyApproved ? 'completed' : 'queued',
            provider: this.activeProvider,
            modelTarget: this.activeProvider === 'comfyui' ? 'sdxl-base-1.0' : 'gemini-3.1-flash-lite-image',
            prompt: ph.fullPrompt,
            priority: 5,
            attempts: 0,
            maxAttempts: 3,
            createdAt: new Date().toISOString(),
            outputPath: ph.outputPath,
            imageChecksum: ph.imageChecksum,
          };

          this.jobs.push(job);
          newJobsCount++;
        } else {
          // Sync metadata without creating duplicate or resetting completed tasks
          existingJob.exerciseName = ex.english_name;
          existingJob.phaseName = ph.phaseName;
          existingJob.prompt = ph.fullPrompt;
        }
      }
    }

    this.saveQueue();
    return newJobsCount;
  }

  public saveQueue(): void {
    try {
      if (!fs.existsSync(STORAGE_DIR)) {
        fs.mkdirSync(STORAGE_DIR, { recursive: true });
      }
      fs.writeFileSync(QUEUE_FILE, JSON.stringify(this.jobs, null, 2), 'utf8');
    } catch (err) {
      console.error('Error saving production queue:', err);
    }
  }

  public getJobs(): ProductionJob[] {
    return this.jobs;
  }

  public getProgress(): QueueProgress {
    const total = this.jobs.length;
    const completed = this.jobs.filter((j) => j.status === 'completed').length;
    const failed = this.jobs.filter((j) => j.status === 'failed').length;
    const active = this.jobs.filter((j) => j.status === 'generating').length;
    const queued = this.jobs.filter((j) => j.status === 'queued').length;
    const percent = total > 0 ? Math.round((completed / total) * 100) : 0;

    return {
      isRunning: this.isRunning,
      isPaused: this.isPaused,
      totalJobs: total,
      completedJobs: completed,
      failedJobs: failed,
      activeJobs: active,
      queuedJobs: queued,
      percentComplete: percent,
      concurrencyLimit: this.concurrencyLimit,
      activeProvider: this.activeProvider,
    };
  }

  public setConcurrency(limit: number): void {
    this.concurrencyLimit = Math.max(1, Math.min(limit, 4));
  }

  public setCheckpoint(checkpoint: string): void {
    for (const job of this.jobs) {
      if (['idle', 'queued', 'failed', 'paused'].includes(job.status)) job.modelTarget = checkpoint;
    }
    this.saveQueue();
  }

  public setProvider(provider: 'comfyui' | 'gemini'): void {
    this.activeProvider = provider;
  }

  public enqueuePhase(exerciseId: string, phaseNumber: number): ProductionJob | null {
    const job = this.jobs.find(
      (j) => j.exerciseId === exerciseId && j.phaseNumber === phaseNumber
    );
    if (!job) return null;
    job.status = 'queued';
    job.errorMessage = undefined;
    this.saveQueue();
    return job;
  }

  public enqueueAllMissing(): number {
    let count = 0;
    for (const job of this.jobs) {
      const phase = pipelineManager.getPhase(job.exerciseId, job.phaseNumber);
      const isMissing = !phase?.outputPath || phase.provenance.type === 'PROGRAMMATIC_SEED';
      if (isMissing && job.status !== 'generating') {
        job.status = 'queued';
        job.errorMessage = undefined;
        count++;
      }
    }
    this.saveQueue();
    return count;
  }

  public retryFailed(): number {
    let count = 0;
    for (const job of this.jobs) {
      if (job.status === 'failed') {
        job.status = 'queued';
        job.errorMessage = undefined;
        count++;
      }
    }
    this.saveQueue();
    return count;
  }

  public pauseQueue(): void {
    this.isPaused = true;
  }

  public resumeQueue(): void {
    this.isPaused = false;
    if (!this.isRunning) {
      this.startRunner();
    }
  }

  public cancelPending(): void {
    for (const job of this.jobs) {
      if (job.status === 'queued') {
        job.status = 'cancelled';
      }
    }
    this.saveQueue();
  }

  public startRunner(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.isPaused = false;

    this.processingInterval = setInterval(async () => {
      if (this.isPaused) return;

      const activeJobs = this.jobs.filter((j) => j.status === 'generating');
      if (activeJobs.length >= this.concurrencyLimit) return;

      const nextJob = this.jobs.find((j) => j.status === 'queued');
      if (!nextJob) {
        if (activeJobs.length === 0) {
          this.stopRunner();
        }
        return;
      }

      await this.processJob(nextJob);
    }, 2000);
  }

  public stopRunner(): void {
    this.isRunning = false;
    if (this.processingInterval) {
      clearInterval(this.processingInterval);
      this.processingInterval = null;
    }
  }

  private async processJob(job: ProductionJob): Promise<void> {
    job.status = 'generating';
    job.startedAt = new Date().toISOString();
    job.attempts++;
    this.saveQueue();

    const startTime = Date.now();

    try {
      if (this.activeProvider === 'comfyui') {
        const comfyStatus = await comfyUiService.checkConnectivity();
        if (!comfyStatus.online) {
          throw new Error('ComfyUI server is offline at ' + comfyUiService.getServerUrl());
        }

        const result = await comfyUiService.executeGeneration(job.prompt, job.modelTarget);
        const updated = pipelineManager.registerGeneratedImage(
          job.exerciseId,
          job.phaseNumber,
          result.buffer,
          'comfyui',
          job.modelTarget,
          result.promptId
        );

        job.status = 'completed';
        job.completedAt = new Date().toISOString();
        job.durationMs = Date.now() - startTime;
        job.outputPath = updated.outputPath;
        job.imageChecksum = updated.imageChecksum;
      } else {
        // Gemini provider
        const geminiStatus = await geminiService.checkStatus();
        if (!geminiStatus.available) {
          throw new Error(geminiStatus.message || 'Gemini image API unavailable');
        }

        const result = await geminiService.generateImage(job.prompt);
        const updated = pipelineManager.registerGeneratedImage(
          job.exerciseId,
          job.phaseNumber,
          result.buffer,
          'gemini',
          result.modelUsed
        );

        job.status = 'completed';
        job.completedAt = new Date().toISOString();
        job.durationMs = Date.now() - startTime;
        job.outputPath = updated.outputPath;
        job.imageChecksum = updated.imageChecksum;
      }
    } catch (err: any) {
      job.status = 'failed';
      job.errorMessage = err.message || 'Execution failed';
      job.durationMs = Date.now() - startTime;
    }

    this.saveQueue();
  }
}

export const productionQueue = new ProductionQueueService();
