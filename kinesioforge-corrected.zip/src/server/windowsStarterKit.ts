import JSZip from 'jszip';

export class WindowsStarterKitService {
  /**
   * Generates the comprehensive, autonomous KinesioForge Windows 10/11 Starter Kit ZIP package
   */
  public async generateStarterKitZip(): Promise<Buffer> {
    const zip = new JSZip();
    const folder = zip.folder('kinesioforge-windows-starter-kit')!;

    // 1. Interactive Main Menu BAT (Greek + English, UTF-8 encoded)
    folder.file(
      'menu.bat',
      `@echo off
chcp 65001 >nul
TITLE KinesioForge AI Image Engine - Control Center (Windows 10/11)
color 0B

:MENU
cls
echo ===============================================================================
echo      KINESIOFORGE AI IMAGE ENGINE ^& SOFIA STUDIO - WINDOWS CONTROL CENTER
echo ===============================================================================
echo.
echo   [1] Εκκίνηση ΟΛΩΝ (One-Click: ComfyUI + KinesioForge Studio + Browser)
echo   [2] Εκκίνηση ΜΟΝΟ του KinesioForge Studio (Web UI http://localhost:3000)
echo   [3] Εκκίνηση ΜΟΝΟ του ComfyUI (Προφίλ RTX 3060 12GB VRAM)
echo   [4] Πλήρης Διαγνωστικός Έλεγχος Συστήματος (GPU, VRAM, CUDA, Python, Node)
echo   [5] Σύνδεση με Cloud GPU (RunPod / Vast.ai για μαζική παραγωγή 2.000+ φωτό)
echo   [6] Έλεγχος Εγκατεστημένων SDXL Checkpoints στο ComfyUI
echo   [7] Λήψη Αντιγράφου Ασφαλείας (Backup Δεδομένων ^& Ασκήσεων)
echo   [8] Άνοιγμα Ελληνικού Οδηγού Εγκατάστασης (ODIGOS_EGKATASTASIS_WINDOWS.md)
echo   [0] Έξοδος
echo.
echo ===============================================================================
set /p choice="Επιλέξτε ενέργεια [0-8] και πατήστε ENTER: "

if "%choice%"=="1" goto START_ALL
if "%choice%"=="2" goto START_STUDIO
if "%choice%"=="3" goto START_COMFY
if "%choice%"=="4" goto DIAGNOSTICS
if "%choice%"=="5" goto CLOUD_GPU
if "%choice%"=="6" goto CHECK_MODELS
if "%choice%"=="7" goto BACKUP
if "%choice%"=="8" goto OPEN_GUIDE
if "%choice%"=="0" exit
goto MENU

:START_ALL
cls
echo [1/3] Εκκίνηση ComfyUI στο παρασκήνιο...
start "ComfyUI RTX 3060" cmd /k "start-comfyui-rtx3060.bat"
timeout /t 3 >nul
echo [2/3] Εκκίνηση KinesioForge Studio Server...
start "KinesioForge Studio" cmd /k "start-kinesioforge.bat"
timeout /t 2 >nul
echo [3/3] Άνοιγμα Studio στον περιηγητή...
start http://localhost:3000
echo.
echo Και οι δύο υπηρεσίες εκτελούνται επιτυχώς!
pause
goto MENU

:START_STUDIO
cls
start "KinesioForge Studio" cmd /k "start-kinesioforge.bat"
start http://localhost:3000
goto MENU

:START_COMFY
cls
start "ComfyUI RTX 3060" cmd /k "start-comfyui-rtx3060.bat"
goto MENU

:DIAGNOSTICS
cls
powershell -ExecutionPolicy Bypass -File .\\diagnose-environment.ps1
echo.
pause
goto MENU

:CLOUD_GPU
cls
powershell -ExecutionPolicy Bypass -File .\\connect-cloud-runpod.ps1
echo.
pause
goto MENU

:CHECK_MODELS
cls
powershell -ExecutionPolicy Bypass -File .\\validate-workflows.ps1
echo.
pause
goto MENU

:BACKUP
cls
powershell -ExecutionPolicy Bypass -File .\\backup-config.ps1
echo.
pause
goto MENU

:OPEN_GUIDE
cls
if exist "ODIGOS_EGKATASTASIS_WINDOWS.md" (
    notepad ODIGOS_EGKATASTASIS_WINDOWS.md
) else (
    echo Δεν βρέθηκε το αρχείο οδηγιών.
)
goto MENU
`
    );

    // 2. One-Click Dual Launcher BAT
    folder.file(
      'start-all.bat',
      `@echo off
chcp 65001 >nul
TITLE KinesioForge Dual Launcher
echo ==========================================================
echo  KinesioForge AI Image Engine - One-Click Dual Launcher
echo ==========================================================
echo.
echo 1. Εκκίνηση ComfyUI (Port 8188 - RTX 3060 Optimized)...
start "ComfyUI Server" cmd /c "start-comfyui-rtx3060.bat"
timeout /t 4 >nul

echo 2. Εκκίνηση KinesioForge Node Server (Port 3000)...
start "KinesioForge Studio" cmd /c "start-kinesioforge.bat"
timeout /t 2 >nul

echo 3. Άνοιγμα Περιηγητή στο http://localhost:3000...
start http://localhost:3000

echo.
echo Όλες οι υπηρεσίες τέθηκαν σε λειτουργία!
echo Μπορείτε να ελαχιστοποιήσετε αυτό το παράθυρο.
timeout /t 5
`
    );

    // 3. ComfyUI Safe RTX 3060 Launcher BAT
    folder.file(
      'start-comfyui-rtx3060.bat',
      `@echo off
chcp 65001 >nul
TITLE ComfyUI RTX 3060 12GB - KinesioForge Hardware Bridge
echo ===============================================================================
echo  ComfyUI Server - Βελτιστοποιημένο για NVIDIA RTX 3060 12GB VRAM
echo  Θύρα: 8188 ^| Flags: --lowvram --listen 127.0.0.1
echo ===============================================================================
echo.

REM 1. Αναζήτηση ComfyUI Portable Python
if exist "..\\python_embeded\\python.exe" (
    echo [OK] Εντοπίστηκε Portable Python του ComfyUI.
    ..\\python_embeded\\python.exe -s main.py --listen 127.0.0.1 --port 8188  --lowvram --preview-method auto
    goto DONE
)

REM 2. Αναζήτηση σε τοπικό φάκελο ComfyUI
if exist ".\\python_embeded\\python.exe" (
    echo [OK] Εντοπίστηκε Portable Python στον τρέχοντα φάκελο.
    .\\python_embeded\\python.exe -s main.py --listen 127.0.0.1 --port 8188  --lowvram --preview-method auto
    goto DONE
)

REM 3. Χρήση Python από το System PATH
echo [NOTICE] Χρήση Python από το PATH συστήματος.
python main.py --listen 127.0.0.1 --port 8188  --lowvram --preview-method auto

:DONE
echo.
echo Το ComfyUI τερματίστηκε.
pause
`
    );

    // 4. KinesioForge Studio Server Launcher BAT
    folder.file(
      'start-kinesioforge.bat',
      `@echo off
chcp 65001 >nul
TITLE KinesioForge Studio Full-Stack Server
echo ==========================================================
echo  KinesioForge Studio Full-Stack Server
echo  Listening on: http://localhost:3000
echo ==========================================================
echo.

REM Έλεγχος Node.js
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo [ΣΦΑΛΜΑ] Το Node.js/npm δεν βρέθηκε στο PATH.
    echo Παρακαλώ εγκαταστήστε το Node.js v18+ από: https://nodejs.org
    pause
    exit /b 1
)

REM Έλεγχος node_modules
if not exist "node_modules\\" (
    echo [INFO] Πρώτη εκτέλεση: Εγκατάσταση εξαρτήσεων (npm install)...
    call npm install
)

echo [OK] Εκκίνηση Development Server...
call npm run dev
pause
`
    );

    // 5. Exhaustive System Diagnostic PowerShell Script
    folder.file(
      'diagnose-environment.ps1',
      `# KinesioForge AI Image Engine - Exhaustive Windows Diagnostic Suite
chcp 65001 >$null
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " KinesioForge AI Image Engine - Πλήρης Διαγνωστικός Έλεγχος Συστήματος" -ForegroundColor Yellow
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host ""

# 1. OS & Architecture
$os = Get-CimInstance Win32_OperatingSystem
Write-Host "[1/7] Λειτουργικό Σύστημα: $($os.Caption) ($($os.OSArchitecture))" -ForegroundColor White

# 2. Processor & RAM
$cpu = Get-CimInstance Win32_Processor
$ramGb = [Math]::Round($os.TotalVisibleMemorySize / 1MB, 2)
Write-Host "[2/7] Επεξεργαστής: $($cpu.Name)" -ForegroundColor White
Write-Host "      Μνήμη RAM: $ramGb GB" -ForegroundColor White
if ($ramGb -ge 15.5) {
    Write-Host "      Έλεγχος RAM: [ΕΠΙΤΥΧΙΑ] (Πληροί τη συνιστώμενη βάση 16GB)" -ForegroundColor Green
} else {
    Write-Host "      Έλεγχος RAM: [ΠΡΟΕΙΔΟΠΟΙΗΣΗ] (Συνιστάται ελάχιστο 16GB για SDXL)" -ForegroundColor Yellow
}

# 3. GPU Hardware & VRAM
Write-Host ""
Write-Host "[3/7] Κάρτα Γραφικών ^& VRAM:" -ForegroundColor Cyan
$nvidiaGpu = Get-CimInstance Win32_VideoController | Where-Object { $_.Name -like "*NVIDIA*" }
if ($nvidiaGpu) {
    Write-Host "      Εντοπίστηκε NVIDIA GPU: $($nvidiaGpu.Name)" -ForegroundColor Green
    $smi = Get-Command "nvidia-smi" -ErrorAction SilentlyContinue
    if ($smi) {
        Write-Host "      nvidia-smi διαθέσιμο. Ανάγνωση VRAM ^& Driver..." -ForegroundColor White
        & nvidia-smi --query-gpu=name,memory.total,memory.free,driver_version --format=csv,noheader
    } else {
        Write-Host "      [ΣΗΜΕΙΩΣΗ] Το nvidia-smi δεν είναι στο PATH. Ελέγξτε την εγκατάσταση των drivers." -ForegroundColor Yellow
    }
} else {
    Write-Host "      [ΣΦΑΛΜΑ] Δεν εντοπίστηκε κάρτα γραφικών NVIDIA." -ForegroundColor Red
}

# 4. Python Environment
Write-Host ""
Write-Host "[4/7] Περιβάλλον Python:" -ForegroundColor Cyan
$py = Get-Command "python" -ErrorAction SilentlyContinue
if ($py) {
    $pyVer = & python --version 2>&1
    Write-Host "      Python στο PATH: $pyVer" -ForegroundColor Green
    if ($pyVer -like "*3.10*" -or $pyVer -like "*3.11*") {
        Write-Host "      Έκδοση Python: [ΕΠΙΤΥΧΙΑ] (3.10 / 3.11 είναι ιδανική για PyTorch ^& ComfyUI)" -ForegroundColor Green
    } else {
        Write-Host "      Έκδοση Python: [ΠΡΟΕΙΔΟΠΟΙΗΣΗ] (Συνιστάται Python 3.10.x ή 3.11.x)" -ForegroundColor Yellow
    }
} else {
    Write-Host "      [ΣΗΜΕΙΩΣΗ] Python δεν βρέθηκε στο system PATH. Εάν χρησιμοποιείτε ComfyUI Portable, περιλαμβάνει ενσωματωμένη Python." -ForegroundColor Yellow
}

# 5. Node.js Environment
Write-Host ""
Write-Host "[5/7] Περιβάλλον Node.js ^& npm:" -ForegroundColor Cyan
$node = Get-Command "node" -ErrorAction SilentlyContinue
if ($node) {
    $nodeVer = & node -v 2>&1
    Write-Host "      Node.js στο PATH: $nodeVer" -ForegroundColor Green
} else {
    Write-Host "      [ΠΡΟΕΙΔΟΠΟΙΗΣΗ] Το Node.js δεν βρέθηκε. Απαιτείται για την τοπική εκτέλεση του KinesioForge Studio." -ForegroundColor Yellow
}

# 6. Port Check (3000 & 8188)
Write-Host ""
Write-Host "[6/7] Έλεγχος Δικτυακών Θυρών (Ports):" -ForegroundColor Cyan
function Test-PortUsage ($port) {
    $conns = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
    if ($conns) {
        Write-Host "      Θύρα $port: [ΔΕΣΜΕΥΜΕΝΗ / ΕΝΕΡΓΗ] (Κάποια υπηρεσία εκτελείται ήδη)" -ForegroundColor Green
    } else {
        Write-Host "      Θύρα $port: [ΕΛΕΥΘΕΡΗ] (Έτοιμη για εκκίνηση)" -ForegroundColor White
    }
}
Test-PortUsage 3000
Test-PortUsage 8188

# 7. ComfyUI Server Ping
Write-Host ""
Write-Host "[7/7] Έλεγχος Συνδεσιμότητας με Τοπικό ComfyUI (http://127.0.0.1:8188):" -ForegroundColor Cyan
try {
    $resp = Invoke-RestMethod -Uri "http://127.0.0.1:8188/system_stats" -Method Get -TimeoutSec 2 -ErrorAction Stop
    Write-Host "      ComfyUI Server: [ONLINE ^& ΕΤΟΙΜΟ ΓΙΑ ΠΑΡΑΓΩΓΗ!]" -ForegroundColor Green
    Write-Host "      Συσκευή: $($resp.devices[0].name)" -ForegroundColor White
} catch {
    Write-Host "      ComfyUI Server: [OFFLINE] (Εκκινήστε το με το start-comfyui-rtx3060.bat)" -ForegroundColor Yellow
}

Write-Host ""
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " Ολοκληρώθηκε ο έλεγχος. Πατήστε ENTER για επιστροφή." -ForegroundColor Yellow
Write-Host "===============================================================================" -ForegroundColor Cyan
`
    );

    // 6. Cloud RunPod Connectivity Helper & Script
    folder.file(
      'connect-cloud-runpod.ps1',
      `# KinesioForge - RunPod Cloud GPU Connector
chcp 65001 >$null
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " KinesioForge - Σύνδεση με Cloud GPU (RunPod / Vast.ai)" -ForegroundColor Yellow
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Για μαζική παραγωγή 1.000 - 2.000 φωτογραφιών σε 1 ώρα (κόστος ~1.50€):" -ForegroundColor White
Write-Host "1. Δημιουργήστε ένα Pod στο RunPod με GPU RTX 4090 ή A4000." -ForegroundColor White
Write-Host "2. Επιλέξτε το επίσημο ComfyUI template." -ForegroundColor White
Write-Host "3. Αντιγράψτε το HTTP Proxy URL (π.χ. https://xxxx-8188.proxy.runpod.net)." -ForegroundColor White
Write-Host ""

$runpodUrl = Read-Host "Εισάγετε το RunPod ComfyUI URL σας (ή πατήστε ENTER για ακύρωση)"
if (-not [string]::IsNullOrWhiteSpace($runpodUrl)) {
    $cleanUrl = $runpodUrl.Trim().TrimEnd('/')
    Write-Host "Δοκιμή σύνδεσης με: $cleanUrl ..." -ForegroundColor Cyan
    try {
        $stats = Invoke-RestMethod -Uri "$cleanUrl/system_stats" -TimeoutSec 5 -ErrorAction Stop
        Write-Host "ΕΠΙΤΥΧΙΑ! Το Cloud GPU ComfyUI είναι ONLINE." -ForegroundColor Green
        Write-Host "Κάρτα Γραφικών Cloud: $($stats.devices[0].name)" -ForegroundColor White
        Write-Host ""
        Write-Host "ΒΗΜΑ ΣΥΝΔΕΣΗΣ ΣΤΟ KINESIOFORGE:" -ForegroundColor Yellow
        Write-Host "Ανοίξτε το KinesioForge Studio (http://localhost:3000), μεταβείτε στην καρτέλα" -ForegroundColor White
        Write-Host "'⚡ ComfyUI RTX Studio' ή 'Settings' και επικολλήστε το παραπάνω URL." -ForegroundColor White
    } catch {
        Write-Host "Αποτυχία σύνδεσης με το URL. Βεβαιωθείτε ότι το Pod εκτελείται και η θύρα 8188 είναι ανοιχτή." -ForegroundColor Red
    }
}
`
    );

    // 7. Workflow & Checkpoints Validator
    folder.file(
      'validate-workflows.ps1',
      `# KinesioForge - Έλεγχος Μοντέλων SDXL στο ComfyUI
chcp 65001 >$null
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " Έλεγχος Εγκατεστημένων Μοντέλων SDXL / Checkpoints" -ForegroundColor Yellow
Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host ""

$commonPaths = @(
    "C:\\ComfyUI_windows_portable\\ComfyUI\\models\\checkpoints",
    "C:\\ComfyUI\\models\\checkpoints",
    "D:\\ComfyUI_windows_portable\\ComfyUI\\models\\checkpoints",
    "$env:USERPROFILE\\ComfyUI\\models\\checkpoints"
)

$foundAny = $false
foreach ($p in $commonPaths) {
    if (Test-Path $p) {
        Write-Host "Φάκελος Checkpoints εντοπίστηκε: $p" -ForegroundColor Green
        $files = Get-ChildItem -Path $p -Filter "*.safetensors"
        if ($files.Count -gt 0) {
            $foundAny = $true
            Write-Host "Βρέθηκαν $($files.Count) μοντέλα .safetensors:" -ForegroundColor Cyan
            foreach ($f in $files) {
                $gb = [Math]::Round($f.Length / 1GB, 2)
                Write-Host "  - $($f.Name) ($gb GB)" -ForegroundColor White
            }
        } else {
            Write-Host "  [ΠΡΟΣΟΧΗ] Ο φάκελος υπάρχει αλλά δεν περιέχει αρχεία .safetensors." -ForegroundColor Yellow
        }
        Write-Host ""
    }
}

if (-not $foundAny) {
    Write-Host "ΣΥΣΤΑΣΗ:" -ForegroundColor Yellow
    Write-Host "Τοποθετήστε το μοντέλο 'sd_xl_base_1.0.safetensors' (6.9 GB) στον φάκελο:" -ForegroundColor White
    Write-Host "ComfyUI\\models\\checkpoints\\" -ForegroundColor White
    Write-Host "Link λήψης: https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0" -ForegroundColor Cyan
}
`
    );

    // 8. State Backup Utility
    folder.file(
      'backup-config.ps1',
      `# KinesioForge - One-Click Backup Utility
chcp 65001 >$null
Write-Host "Δημιουργία Αντιγράφου Ασφαλείας..." -ForegroundColor Cyan
$dateStr = Get-Date -Format "yyyyMMdd_HHmmss"
$targetDir = ".\\backups\\backup_$dateStr"
New-Item -ItemType Directory -Path $targetDir -Force | Out-Null

if (Test-Path ".\\public\\storage") {
    Copy-Item -Path ".\\public\\storage\\*.json" -Destination $targetDir -Force
    Write-Host "[ΕΠΙΤΥΧΙΑ] Τα JSON αρχεία κατάστασης και ουράς αποθηκεύτηκαν στο:" -ForegroundColor Green
    Write-Host "  $targetDir" -ForegroundColor White
} else {
    Write-Host "[ΣΗΜΕΙΩΣΗ] Δεν βρέθηκε ο φάκελος public\\storage." -ForegroundColor Yellow
}
`
    );

    // 9. ULTRA-DETAILED GREEK STEP-BY-STEP MASTER GUIDE
    folder.file(
      'ODIGOS_EGKATASTASIS_WINDOWS.md',
      `# ΟΛΟΚΛΗΡΩΜΕΝΟΣ ΟΔΗΓΟΣ ΕΓΚΑΤΑΣΤΑΣΗΣ & ΜΑΖΙΚΗΣ ΠΑΡΑΓΩΓΗΣ ΦΩΤΟΓΡΑΦΙΩΝ
## KinesioForge AI Image Engine & Sofia Studio Pipeline
### Πλήρως προσαρμοσμένο για Windows 10/11 & NVIDIA RTX 3060 12GB VRAM

---

## 1. ΕΙΣΑΓΩΓΗ & ΑΡΧΙΤΕΚΤΟΝΙΚΗ

Το **KinesioForge** είναι το σύστημα παραγωγής και πιστοποίησης κινησιολογικών φωτογραφιών για την πλατφόρμα **Sofia Personal Trainer Studio** (\`koulierakis/Sofia-Personal-Trainer-Studio\`).

Η μηχανή εκτελεί:
1. **Ανάλυση & Commit Καταλόγου Sofia**: Αναγνωρίζει μοναδικά IDs και τον ακριβή αριθμό φάσεων (4, 5 ή 6 φάσεις) χωρίς διπλότυπες εργασίες.
2. **Διαχείριση Ουράς Παραγωγής (Production Queue)**: Μαζική αποστολή prompts στο ComfyUI ή Gemini με αυτόματη επανάληψη σε σφάλματα και αποθήκευση στο δίσκο (\`production_queue.json\`).
3. **Αυστηρή Ταυτότητα Αθλητών**:
   - **Νίκος** (Άντρας, 20-29, Μεσογειακά χαρακτηριστικά, κοντά σκούρα μαλλιά, μαύρη μπλούζα, μαύρο παντελόνι).
   - **Έλενα** (Γυναίκα, 20-29, Μεσογειακά χαρακτηριστικά, σκούρα μαλλιά αλογοουρά, μαύρο μπουστάκι, μαύρο κολάν).
   - **Studio**: Μοντέρνο πολυτελές personal training studio με σκούρο πάτωμα και καθαρό φωτισμό.
4. **Εξαγωγή Πακέτου Sofia WebP**: Δομή φακέλων \`public/images/exercises/{exercise-id}/{phaseNumber}.webp\`, \`exercise-images.json\`, \`catalog.json\`, \`manifest.json\` και \`audit_report.json\`.

---

## 2. ΠΡΟΑΠΑΙΤΟΥΜΕΝΑ ΣΥΣΤΗΜΑΤΟΣ (WINDOWS 10/11)

| Στοιχείο | Ελάχιστη Απαίτηση | Συνιστώμενο για SDXL |
| :--- | :--- | :--- |
| **Λειτουργικό** | Windows 10 (64-bit) Build 19044+ | Windows 11 (64-bit) |
| **Κάρτα Γραφικών** | NVIDIA GPU 8GB VRAM | **NVIDIA GeForce RTX 3060 12GB VRAM** |
| **Μνήμη RAM** | 16 GB DDR4 | 32 GB DDR4/DDR5 |
| **Αποθήκευση** | 20 GB ελεύθερα | SSD NVMe (50 GB ελεύθερα) |
| **NVIDIA Drivers** | Έκδοση 535.xx+ | Τελευταίοι **NVIDIA Studio Drivers** |
| **Node.js** | Node.js v18.x LTS | Node.js v20.x ή v22.x LTS |

---

## 3. ΒΗΜΑ ΠΡΟΣ ΒΗΜΑ ΕΓΚΑΤΑΣΤΑΣΗ ΤΟΥ COMFYUI

### Βήμα 3.1: Λήψη του ComfyUI Portable
1. Επισκεφθείτε τη σελίδα κυκλοφοριών του ComfyUI στο GitHub:
   👉 **[ComfyUI Windows Portable Releases](https://github.com/comfyanonymous/ComfyUI/releases)**
2. Κατεβάστε το αρχείο: **\`ComfyUI_windows_portable_nvidia_cu121_or_cpu.7z\`** (περίπου 1.4 GB).
3. Χρησιμοποιήστε το [7-Zip](https://www.7-zip.org) για να το αποσυμπιέσετε.
4. Τοποθετήστε το στον κεντρικό σας δίσκο, για παράδειγμα:
   \`C:\\ComfyUI_windows_portable\\\`

---

### Βήμα 3.2: Τοποθέτηση των Μοντέλων SDXL (Checkpoints)
Για φωτορεαλιστική απόδοση ανθρώπινης ανατομίας χωρίς παραμορφώσεις, κατεβάστε ένα από τα παρακάτω μοντέλα:

1. **SDXL Base 1.0 (Επίσημο Stability AI)**:
   - Link: [HuggingFace - SDXL Base 1.0](https://huggingface.co/stabilityai/stable-diffusion-xl-base-1.0/resolve/main/sd_xl_base_1.0.safetensors)
   - Μέγεθος: ~6.94 GB
2. **RealVisXL V4.0 (Εξαιρετικό για ρεαλισμό δέρματος & αθλητών)**:
   - Link: [CivitAI / HuggingFace - RealVisXL](https://huggingface.co/SG161222/RealVisXL_V4.0/resolve/main/RealVisXL_V4.0.safetensors)

📁 **ΠΟΥ ΤΟΠΟΘΕΤΕΙΤΕ ΤΟ ΑΡΧΕΙΟ:**
Αντιγράψτε το αρχείο \`.safetensors\` στον παρακάτω φάκελο:
\`C:\\ComfyUI_windows_portable\\ComfyUI\\models\\checkpoints\\sd_xl_base_1.0.safetensors\`

---

### Βήμα 3.3: Ρύθμιση του Batch Launcher (RTX 3060 12GB Hardening)
1. Αντιγράψτε το αρχείο **\`start-comfyui-rtx3060.bat\`** από αυτό το starter kit.
2. Επικολλήστε το μέσα στον φάκελο:
   \`C:\\ComfyUI_windows_portable\\ComfyUI\\\`
3. Το script αυτό ενεργοποιεί αυτόματα τις απαραίτητες σημαίες:
   - \`--lowvram\`: Αποτρέπει σφάλματα Out-Of-Memory (OOM) στη μνήμη 12GB VRAM.
   - \`--listen 127.0.0.1\`: Επιτρέπει την επικοινωνία με το KinesioForge Studio.
   - \`--port 8188\`: Η προκαθορισμένη θύρα REST API του ComfyUI.

---

## 4. ΕΚΚΙΝΗΣΗ & ΣΥΝΔΕΣΗ ΜΕ ΤΟ KINESIOFORGE

### Επιλογή 1: Αυτόματη Εκκίνηση (Συνιστάται)
Κάντε διπλό κλικ στο αρχείο **\`start-all.bat\`** ή στο **\`menu.bat\`** (Επιλογή 1).
- Ανοίγει το ComfyUI στη θύρα 8188.
- Ανοίγει το KinesioForge Studio στη θύρα 3000.
- Ανοίγει αυτόματα τον περιηγητή σας στο: **\`http://localhost:3000\`**.

### Επιλογή 2: Χειροκίνητη Εκκίνηση
1. Ανοίξτε το ComfyUI εκτελώντας το \`start-comfyui-rtx3060.bat\`.
   Περιμένετε μέχρι να δείτε: \`To see the GUI go to: http://127.0.0.1:8188\`.
2. Σε δεύτερο παράθυρο τερματικού, εκτελέστε \`npm run dev\` στον φάκελο του KinesioForge.
3. Ανοίξτε το **\`http://localhost:3000\`**.
4. Μεταβείτε στην καρτέλα **⚡ ComfyUI RTX Studio** και πατήστε **Test Connection**. Θα εμφανιστεί πράσινη ένδειξη **ONLINE**.

---

## 5. ΜΑΖΙΚΗ ΠΑΡΑΓΩΓΗ ΕΙΚΟΝΩΝ (BATCH WORKFLOW)

1. **Εισαγωγή Καταλόγου Sofia**:
   - Μεταβείτε στην καρτέλα **📦 Sofia Export Hub**.
   - Στο πεδίο "Εισαγωγή / Ενημέρωση Καταλόγου Sofia Studio", επικολλήστε το JSON των ασκήσεων σας ή πατήστε **"Φόρτωση Δείγματος Sofia Καταλόγου"**.
   - Πατήστε **"1. Εκτέλεση Dry-Run Ανάλυσης"** για να δείτε τον αριθμό φάσεων και τις ελλείψεις χωρίς να αλλάξει η βάση.
   - Πατήστε **"2. Οριστικό Commit & Προγραμματισμός Ουράς"**. Όλες οι ασκήσεις και οι φάσεις τους μπαίνουν άμεσα στην ουρά παραγωγής!
2. **Εκκίνηση Ουράς Παραγωγής**:
   - Μεταβείτε στην καρτέλα **⏳ Production Queue**.
   - Επιλέξτε Provider: **ComfyUI**.
   - Ρυθμίστε Concurrency: **1** (για ασφαλή λειτουργία στην RTX 3060 χωρίς να κολλήσει το PC).
   - Πατήστε **"Start Queue Runner"**.
   - Η ουρά θα αρχίσει να στέλνει σειριακά τις εντολές, να παράγει τις εικόνες και να τις αποθηκεύει στο \`public/storage/{exercise-id}/\`.

---

## 6. ΕΞΑΓΩΓΗ ΠΑΚΕΤΟΥ ΓΙΑ ΤΗ SOFIA

Μόλις ολοκληρωθεί η παραγωγή:
1. Μεταβείτε στην καρτέλα **📦 Sofia Export Hub**.
2. Πατήστε **"Λήψη Πλήρους Πακέτου Sofia (WebP Archive)"**.
3. Το σύστημα παράγει αυτόματα ένα αρχείο \`.zip\` που περιέχει:
   - \`public/images/exercises/{exercise-id}/{phaseNumber}.webp\` (πραγματικά αρχεία WebP υψηλής συμπίεσης και ποιότητας).
   - \`exercise-images.json\` (πλήρης χάρτης αντιστοίχισης για τη Sofia).
   - \`catalog.json\` (ο κατάλογος των ασκήσεων με κινησιολογία και οδηγίες).
   - \`manifest.json\` & \`audit_report.json\` (πλήρης έλεγχος ακεραιότητας).
4. Αποσυμπιέζετε το zip απευθείας μέσα στο project **\`Sofia-Personal-Trainer-Studio\`**!

---

## 7. ΕΠΙΛΥΣΗ ΠΡΟΒΛΗΜΑΤΩΝ (TROUBLESHOOTING)

### Πρόβλημα 1: "ComfyUI Server Offline"
- **Αιτία**: Το ComfyUI δεν εκτελείται ή μπλοκάρεται από το Windows Firewall.
- **Λύση**: Βεβαιωθείτε ότι το παράθυρο του ComfyUI είναι ανοιχτό και γράφει \`Starting server on port 8188\`. Ελέγξτε ότι στο KinesioForge το Server URL είναι \`http://127.0.0.1:8188\`.

### Πρόβλημα 2: "CUDA Out of Memory (OOM)"
- **Αιτία**: Υπερφόρτωση της VRAM κατά το inference σε υψηλή ανάλυση.
- **Λύση**: Βεβαιωθείτε ότι εκκινήσατε το ComfyUI με το \`start-comfyui-rtx3060.bat\` (περιέχει τη σημαία \`--lowvram\`). Στην ουρά παραγωγής κρατήστε Concurrency = 1.

### Πρόβλημα 3: "Port 3000 already in use"
- **Αιτία**: Κάποια άλλη εφαρμογή χρησιμοποιεί τη θύρα 3000.
- **Λύση**: Εκτελέστε \`netstat -ano | findstr :3000\` στο CMD για να βρείτε το PID και τερματίστε το με \`taskkill /PID <PID> /F\`.
`
    );

    // 10. CLOUD GPU RUNPOD PRODUCTION GUIDE (Greek)
    folder.file(
      'ODIGOS_MAZIKIS_PARAGOGIS_RUNPOD.md',
      `# ΟΔΗΓΟΣ ΜΑΖΙΚΗΣ ΠΑΡΑΓΩΓΗΣ ΣΕ CLOUD GPU (RUNPOD / VAST.AI)
### Πώς να παραγάγετε 2.000 φωτογραφίες σε 1 ώρα με κόστος ~1.50€ – 2.00€

---

## Γιατί να επιλέξετε Cloud GPU για μαζική παραγωγή;
- **Ταχύτητα**: Μια cloud κάρτα **NVIDIA RTX 4090 (24GB VRAM)** παράγει κάθε φωτογραφία SDXL σε **2-3 δευτερόλεπτα** (έναντι 25 δευτερολέπτων σε τοπική κάρτα).
- **Κόστος**: Η ενοικίαση μιας RTX 4090 κοστίζει περίπου **0.35€ ανά ώρα**.
- **Συνολικό Κόστος**: Για 2.000 εικόνες χρειάζονται περίπου 1.5 έως 2 ώρες = **~1.50€ έως 2.00€**.
- **Μηδενική Επιβάρυνση**: Το δικό σας PC παραμένει ελεύθερο, χωρίς θόρυβο ανεμιστήρων και κατανάλωση ρεύματος.

---

## ΒΗΜΑΤΑ ΣΕ 5 ΛΕΠΤΑ

### 1. Εγγραφή & Πίστωση στο RunPod
1. Μεταβείτε στο [RunPod.io](https://www.runpod.io) και δημιουργήστε λογαριασμό.
2. Προσθέστε ένα ελάχιστο υπόλοιπο (π.χ. $5 ή $10).

### 2. Δημιουργία ComfyUI Pod
1. Στο μενού επιλέξτε **Pods** -> **Deploy**.
2. Επιλέξτε GPU: **NVIDIA RTX 4090** (ή RTX A4000).
3. Στο πεδίο Template, επιλέξτε το έτοιμο template: **\`RunPod ComfyUI\`**.
4. Πατήστε **Deploy On-Demand**.

### 3. Αντιγραφή του Public HTTP Proxy URL
Μόλις το Pod γίνει πράσινο (Running):
1. Πατήστε στο κουμπί **Connect**.
2. Θα δείτε μια σύνδεση HTTP για τη θύρα 8188:
   Π.χ.: \`https://abc123xyz-8188.proxy.runpod.net\`
3. Αντιγράψτε αυτό το URL.

### 4. Σύνδεση με το KinesioForge Studio
1. Ανοίξτε το KinesioForge Studio (\`http://localhost:3000\`).
2. Μεταβείτε στην καρτέλα **⚡ ComfyUI RTX Studio** ή **Settings**.
3. Στο πεδίο **Server URL**, αντικαταστήστε το \`http://127.0.0.1:8188\` με το URL του RunPod (π.χ. \`https://abc123xyz-8188.proxy.runpod.net\`).
4. Πατήστε **Test Connection**. Μόλις συνδεθεί, η ένδειξη γίνεται **ONLINE (Cloud GPU: NVIDIA RTX 4090 24GB)**!

### 5. Έναρξη Μαζικής Παραγωγής
1. Μεταβείτε στην καρτέλα **⏳ Production Queue**.
2. Μπορείτε να αυξήσετε το Concurrency σε **2** ή **3** (λόγω των 24GB VRAM της 4090).
3. Πατήστε **Start Queue Runner**.
4. Οι 2.000 φωτογραφίες θα παραχθούν αυτόματα και θα αποθηκευτούν απευθείας στο KinesioForge!
5. Μόλις τελειώσετε, πατήστε **Terminate** στο Pod στο RunPod ώστε να σταματήσει η χρέωση.
`
    );

    // 11. Troubleshooting & Diagnostics Reference
    folder.file(
      'TROUBLESHOOTING.md',
      `# KinesioForge Comprehensive Troubleshooting & Diagnostic Matrix

| Σύμπτωμα / Σφάλμα | Πιθανή Αιτία | Οριστική Λύση |
| :--- | :--- | :--- |
| **ComfyUI: Connection Refused / Offline** | Το ComfyUI δεν εκτελείται ή δεν έχει τη σημαία --listen 127.0.0.1 | Εκκινήστε το ComfyUI μέσω του \`start-comfyui-rtx3060.bat\`. |
| **CUDA out of memory (OOM)** | Η ανάλυση είναι πολύ μεγάλη ή λείπει το --lowvram | Χρησιμοποιήστε το \`--lowvram\`. Μην υπερβαίνετε τα 1024x1024 ανά καρέ. |
| **Checkpoint not found in dropdown** | Το αρχείο .safetensors λείπει από τον φάκελο models/checkpoints | Τοποθετήστε το μοντέλο στο \`ComfyUI/models/checkpoints/\` και πατήστε Refresh. |
| **Browser API connection error** | Ελέγξτε το backend του KinesioForge | Χρησιμοποιήστε την τοπική server-to-server σύνδεση. Δεν απαιτείται wildcard CORS. |
| **Port 3000 in use** | Προηγούμενη διεργασία του Node.js παραμένει ενεργή | Εκτελέστε \`taskkill /F /IM node.exe\` σε γραμμή εντολών Windows. |
| **Python not recognized** | Η Python δεν βρίσκεται στο PATH συστήματος | Χρησιμοποιήστε το ComfyUI Portable που έχει ενσωματωμένο python_embeded. |
`
    );

    return await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
  }
}

export const windowsStarterKitService = new WindowsStarterKitService();
