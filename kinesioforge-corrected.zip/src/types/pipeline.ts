export type ProvenanceType =
  | 'PROGRAMMATIC_SEED'
  | 'PLACEHOLDER'
  | 'MOCK_OUTPUT'
  | 'GENERATED_AI_UNVERIFIED'
  | 'GENERATED_AI_VERIFIED'
  | 'IMPORTED_USER_IMAGE'
  | 'REJECTED';

export type ReadinessCategory =
  | 'APPLICATION_BUILD_READY'
  | 'PROVIDER_INTEGRATION_READY'
  | 'IMAGE_LIBRARY_INCOMPLETE'
  | 'IMAGE_LIBRARY_REVIEW_PENDING'
  | 'PRODUCTION_CONTENT_READY';

export interface ProvenanceMetadata {
  type: ProvenanceType;
  provider: 'gemini' | 'comfyui' | 'manual' | 'programmatic' | 'none';
  model: string;
  generationTimestamp?: string;
  durationMs?: number;
  isSeeded: boolean;
  device?: string;
  requestId?: string;
  seedSignature?: string;
}

export interface BiomechanicalQC {
  overallStatus: 'passed' | 'warning' | 'failed' | 'uninspected';
  anatomicalScore: number;
  biomechanicalScore: number;
  phaseAccuracy: 'accurate' | 'minor_deviation' | 'inaccurate' | 'unverified';
  jointAlignment: string;
  equipmentGrip: string;
  isDuplicate: boolean;
  duplicateOfPhaseId?: string;
  isPlaceholderDetected: boolean;
  detectedIssues: string[];
  suggestedPromptCorrections: string;
  verdictSummary: string;
  evaluatedAt: string;
  modelUsed: string;
  rawInspectionEvidence?: string;
}

export interface HumanReview {
  status: 'pending' | 'approved' | 'rejected' | 'needs_regeneration';
  reviewer?: string;
  reviewedAt?: string;
  notes?: string;
}

export interface PhaseRecord {
  id: string; // exerciseId_phase-XX
  exerciseId: string;
  exerciseName: string;
  phaseNumber: number;
  phaseName: string;
  phaseKey: string;
  fullPrompt: string;
  athleteProfile: string;
  generationProvider: 'gemini' | 'comfyui' | 'manual' | 'none';
  jobStatus: 'idle' | 'pending' | 'generating' | 'completed' | 'failed';
  errorMessage?: string;
  outputPath?: string; // relative to storage
  imageChecksum?: string; // sha256
  fileSizeBytes?: number;
  dimensions?: { width: number; height: number };
  provenance: ProvenanceMetadata;
  qcReport: BiomechanicalQC;
  humanReview: HumanReview;
}

export interface ExerciseRecord {
  id: string;
  onomasia_askisis: string;
  english_name: string;
  epipedo_dyskalias: string;
  stoxos: string;
  apaitoumenos_exoplismos: string[];
  myikes_omades: {
    kyries: string[];
    synergistes_statheropoiites: string[];
  };
  mixaniki_analysi: string;
  odigies_ektelesis: Record<string, string>;
  simeia_prosoxis_lathi: string[];
  optiki_apeikonisi_dalle_prompts: {
    domi_kinisis: string;
    prompts: Record<string, string>;
  };
  totalPhases: number;
  phases: PhaseRecord[];
}

export interface DuplicateDetection {
  hash: string;
  phases: Array<{
    exerciseId: string;
    phaseNumber: number;
    phaseId: string;
    path: string;
  }>;
}

export interface IntegrityDashboardStats {
  totalExercises: number;
  totalPhases: number;
  completedPhotographs: number;
  genuineAIGenerated: number;
  verifiedProductionReady: number;
  programmaticSeeds: number;
  missingPhases: number;
  duplicateCount: number;
  duplicateDetections: DuplicateDetection[];
  failedQC: number;
  awaitingHumanReview: number;
  isProductionReady: boolean;
  readinessCategories: ReadinessCategory[];
  comfyUiStatus: {
    online: boolean;
    url: string;
    message: string;
    vramOptimized: boolean;
  };
  geminiStatus: {
    available: boolean;
    model: string;
    message?: string;
  };
}

export interface ComfyUIConfig {
  serverUrl: string;
  clientId: string;
  checkpoint: string;
  vramProfile: 'lowvram' | 'medvram' | 'normal';
  steps: number;
  cfg: number;
  sampler: string;
  scheduler: string;
}

export interface AthleteProfile {
  id: string;
  name: string;
  age: string;
  ethnicity: string;
  build: string;
  hair: string;
  attire: string;
  environment: string;
  lighting: string;
  referenceNotes: string;
  isDefault: boolean;
}

export const DEFAULT_GREEK_ATHLETE: AthleteProfile = {
  id: 'ath-01-greek-male-chiseled',
  name: 'Νίκος (Greek Athletic Male Prototype)',
  age: 'Young adult 20-29 (26-28 years old)',
  ethnicity: 'Mediterranean / Greek features, defined facial structure',
  build: 'Chiseled, low body fat, defined athletic musculature with aesthetic vascularity',
  hair: 'Short, clean dark textured hair, light neat stubble',
  attire: 'Fitted black athletic training t-shirt, matte black high-compression training pants/leggings, minimalist black training shoes',
  environment: 'High-end minimalist private gym studio, clean polished dark concrete floor, matte charcoal wall paneling, zero text or wall decals',
  lighting: 'Cinematic directional soft warm studio lighting, subtle rim lighting emphasizing muscular definition and joint mechanics',
  referenceNotes: 'Anchor male profile for the Sofia Personal Trainer Studio kinematics sequence. High inter-frame visual consistency.',
  isDefault: true,
};

export const DEFAULT_GREEK_FEMALE_ATHLETE: AthleteProfile = {
  id: 'ath-02-greek-female-athletic',
  name: 'Έλενα (Greek Athletic Female Prototype)',
  age: 'Young adult 20-29 (24-27 years old)',
  ethnicity: 'Mediterranean / Greek features, elegant defined facial bone structure',
  build: 'Lean athletic physique, toned musculature, healthy posture and kinetic alignment',
  hair: 'Dark shoulder-length hair tied in a neat athletic ponytail',
  attire: 'Matte black athletic sports bra / cropped top, matching high-waisted black athletic leggings, minimalist black training shoes',
  environment: 'High-end minimalist private gym studio, clean polished dark floor, matte charcoal wall paneling, zero logos or text decals',
  lighting: 'Cinematic directional soft studio lighting, subtle rim lighting emphasizing biomechanical alignment and form',
  referenceNotes: 'Anchor female profile for Sofia Personal Trainer Studio. High inter-frame visual consistency.',
  isDefault: false,
};


export type JobStatus =
  | 'idle'
  | 'queued'
  | 'generating'
  | 'completed'
  | 'failed'
  | 'paused'
  | 'cancelled';

export interface ProductionJob {
  jobId: string;
  exerciseId: string;
  exerciseName: string;
  phaseNumber: number;
  phaseName: string;
  status: JobStatus;
  provider: 'gemini' | 'comfyui';
  modelTarget: string;
  prompt: string;
  priority: number;
  attempts: number;
  maxAttempts: number;
  errorMessage?: string;
  createdAt: string;
  startedAt?: string;
  completedAt?: string;
  durationMs?: number;
  outputPath?: string;
  imageChecksum?: string;
}

export interface QueueProgress {
  isRunning: boolean;
  isPaused: boolean;
  totalJobs: number;
  completedJobs: number;
  failedJobs: number;
  activeJobs: number;
  queuedJobs: number;
  percentComplete: number;
  concurrencyLimit: number;
  activeProvider: string;
}

export interface TestCaseResult {
  id: string;
  name: string;
  category: 'REAL' | 'MOCKED' | 'STATIC';
  passed: boolean;
  expected: string;
  actual: string;
  details: string;
}

export interface TestSuiteReport {
  timestamp: string;
  allPassed: boolean;
  totalTests: number;
  passedTests: number;
  failedTests: number;
  tests: TestCaseResult[];
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  category: 'SDXL' | 'FLUX' | 'ControlNet' | 'Refinement' | 'Sequence';
  description: string;
  targetGpu: string;
  recommendedVramGb: number;
  requiredNodes: string[];
  requiredCheckpoints: string[];
  workflowJson: Record<string, any>;
  compatibility?: {
    isCompatible: boolean;
    missingCheckpoints: string[];
    missingNodes: string[];
  };
}
