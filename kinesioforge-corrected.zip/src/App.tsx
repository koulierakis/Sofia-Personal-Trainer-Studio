import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { IntegrityDashboard } from './components/IntegrityDashboard';
import { ExerciseStudio } from './components/ExerciseStudio';
import { ComfyUiStudio } from './components/ComfyUiStudio';
import { SofiaExportPanel } from './components/SofiaExportPanel';
import { AutomatedTestsView } from './components/AutomatedTestsView';
import { ExerciseDatabaseView } from './components/ExerciseDatabaseView';
import { ProductionQueueView } from './components/ProductionQueueView';
import { QualityControlHub } from './components/QualityControlHub';
import { ImageLibraryView } from './components/ImageLibraryView';
import { AthleteProfilesView } from './components/AthleteProfilesView';
import { SettingsView } from './components/SettingsView';
import {
  ExerciseRecord,
  IntegrityDashboardStats,
  TestSuiteReport,
} from './types/pipeline';

export default function App() {
  const [stats, setStats] = useState<IntegrityDashboardStats | null>(null);
  const [exercises, setExercises] = useState<ExerciseRecord[]>([]);
  const [selectedExerciseId, setSelectedExerciseId] = useState<string>(
    'ex-01-rotational-cossack-squat-to-diagonal-landm'
  );
  const [selectedPhaseNumber, setSelectedPhaseNumber] = useState<number>(1);
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [testReport, setTestReport] = useState<TestSuiteReport | null>(null);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const fetchAppData = async () => {
    try {
      const [statusRes, exRes] = await Promise.all([
        fetch('/api/status'),
        fetch('/api/exercises'),
      ]);

      if (statusRes.ok) {
        const data = await statusRes.json();
        setStats(data.stats);
      }

      if (exRes.ok) {
        const exData = await exRes.json();
        setExercises(exData.exercises);
      }
    } catch (err) {
      console.error('Error fetching application state:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRunTests = async () => {
    setIsRunningTests(true);
    try {
      const resp = await fetch('/api/tests/run');
      if (resp.ok) {
        const data = await resp.json();
        setTestReport(data.report);
      }
    } catch (err) {
      console.error('Error running automated test suite:', err);
    } finally {
      setIsRunningTests(false);
    }
  };

  const handleReAudit = async () => {
    try {
      await fetch('/api/audit', { method: 'POST' });
      await fetchAppData();
    } catch (err) {
      console.error('Error auditing assets:', err);
    }
  };

  const handleSelectExercise = (exerciseId: string, phaseNum: number = 1) => {
    setSelectedExerciseId(exerciseId);
    setSelectedPhaseNumber(phaseNum);
    setActiveTab('studio');
  };

  useEffect(() => {
    fetchAppData();
    handleRunTests();
  }, []);

  if (isLoading && exercises.length === 0) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-100 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-12 h-12 rounded-xl bg-amber-500 flex items-center justify-center mx-auto text-zinc-950 font-black text-2xl animate-pulse">
            KF
          </div>
          <p className="text-sm font-mono text-zinc-400">
            Initializing KinesioForge Biomechanical Pipeline...
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 font-sans selection:bg-amber-500 selection:text-zinc-950">
      <Header
        stats={stats}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onRunTests={() => {
          setActiveTab('tests');
          handleRunTests();
        }}
        onReAudit={handleReAudit}
        isRunningTests={isRunningTests}
      />

      <main className="pb-16">
        {activeTab === 'dashboard' && (
          <IntegrityDashboard
            stats={stats}
            exercises={exercises}
            onSelectExercise={handleSelectExercise}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'exercises' && (
          <ExerciseDatabaseView
            exercises={exercises}
            onOpenStudio={handleSelectExercise}
          />
        )}

        {activeTab === 'studio' && (
          <ExerciseStudio
            exercises={exercises}
            selectedExerciseId={selectedExerciseId}
            selectedPhaseNumber={selectedPhaseNumber}
            onSelectExercise={(id, pNum) => {
              setSelectedExerciseId(id);
              if (pNum) setSelectedPhaseNumber(pNum);
            }}
            onRefreshData={fetchAppData}
          />
        )}

        {activeTab === 'queue' && <ProductionQueueView />}

        {activeTab === 'qc' && (
          <QualityControlHub
            exercises={exercises}
            onOpenPhase={handleSelectExercise}
            onRefresh={fetchAppData}
          />
        )}

        {activeTab === 'library' && (
          <ImageLibraryView
            exercises={exercises}
            onOpenPhase={handleSelectExercise}
          />
        )}

        {activeTab === 'athletes' && <AthleteProfilesView />}

        {activeTab === 'comfyui' && (
          <ComfyUiStudio
            comfyStatus={stats?.comfyUiStatus || null}
            onRefresh={fetchAppData}
          />
        )}

        {activeTab === 'sofia' && <SofiaExportPanel stats={stats} />}

        {activeTab === 'tests' && (
          <AutomatedTestsView
            report={testReport}
            isRunning={isRunningTests}
            onRunTests={handleRunTests}
          />
        )}

        {activeTab === 'settings' && <SettingsView />}
      </main>
    </div>
  );
}
