import React, { useState, useEffect } from 'react';
import {
  Settings,
  Download,
  Database,
  Cpu,
  Layers,
  Sparkles,
  ShieldCheck,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { WorkflowTemplate } from '../types/pipeline';

export const SettingsView: React.FC = () => {
  const [workflows, setWorkflows] = useState<WorkflowTemplate[]>([]);
  const [backupStatus, setBackupStatus] = useState<string | null>(null);
  const [backupError, setBackupError] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/workflows')
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setWorkflows(d.workflows);
      })
      .catch((err) => console.error(err));
  }, []);

  const handleCreateBackup = async () => {
    setBackupError(null);
    setBackupStatus(null);
    try {
      const resp = await fetch('/api/backup/create', { method: 'POST' });
      const data = await resp.json();
      if (data.success) {
        setBackupStatus(`Αντίγραφο ασφαλείας δημιουργήθηκε επιτυχώς: ${data.backupFile}`);
        setTimeout(() => setBackupStatus(null), 4000);
      } else {
        throw new Error(data.error || 'Σφάλμα δημιουργίας backup');
      }
    } catch (err: any) {
      setBackupError(`Σφάλμα δημιουργίας backup: ${err.message}`);
    }
  };

  const handleDownloadWindowsKit = () => {
    window.location.href = '/api/download/windows-starter-kit';
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Overview Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Settings className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Ρυθμίσεις Συστήματος & Τοπικού Υλικού (Settings & Hardware Profiles)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Διαμόρφωση προφίλ υλικού NVIDIA RTX 3060 12GB, διαχείριση αντιγράφων ασφαλείας (state backup) και λήψη του πακέτου Windows 10/11 Starter Kit.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleDownloadWindowsKit}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Λήψη Windows Starter Kit ZIP</span>
            </button>
            <button
              onClick={handleCreateBackup}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium text-xs border border-zinc-700 transition cursor-pointer"
            >
              <Database className="w-4 h-4" />
              <span>Δημιουργία Backup</span>
            </button>
          </div>
        </div>

        {backupStatus && (
          <div className="mt-4 p-3 rounded-lg bg-emerald-950/40 border border-emerald-800 text-xs text-emerald-300 font-medium">
            {backupStatus}
          </div>
        )}

        {backupError && (
          <div className="mt-4 p-3 rounded-lg bg-rose-950/40 border border-rose-800 text-xs text-rose-300 font-medium">
            {backupError}
          </div>
        )}
      </div>

      {/* Grid: Hardware Profile & Provider Status */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hardware Baseline */}
        <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-4">
          <h3 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
            <Cpu className="w-4 h-4 text-amber-400" />
            <span>Τοπικό Προφίλ Υλικού (Baseline Profile)</span>
          </h3>

          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Κάρτα Γραφικών:</span>
              <span className="font-mono text-zinc-200 font-bold">NVIDIA GeForce RTX 3060</span>
            </div>
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Μνήμη VRAM:</span>
              <span className="font-mono text-zinc-200 font-bold">12 GB GDDR6</span>
            </div>
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Βελτιστοποίηση ComfyUI:</span>
              <span className="font-mono text-amber-400 font-bold">--medvram (1024x1024 SDXL)</span>
            </div>
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Σύστημα RAM Baseline:</span>
              <span className="font-mono text-zinc-200">16 GB DDR4/DDR5</span>
            </div>
          </div>
        </div>

        {/* Gemini Provider Status */}
        <div className="p-5 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-4">
          <h3 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>Google Gemini Provider Configuration</span>
          </h3>

          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Μοντέλο Εικόνας:</span>
              <span className="font-mono text-zinc-200">gemini-3.1-flash-lite-image</span>
            </div>
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Μοντέλο Vision QC:</span>
              <span className="font-mono text-zinc-200">gemini-3.8-flash</span>
            </div>
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Ασφάλεια Quota:</span>
              <span className="text-emerald-400 font-medium">Διαφανής χειρισμός 429 (Μηδέν πλασματικά αρχεία)</span>
            </div>
            <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 flex justify-between">
              <span className="text-zinc-400">Κλειδί API:</span>
              <span className="text-zinc-400 font-mono">Διαχειρίζεται από το AI Studio Secrets</span>
            </div>
          </div>
        </div>
      </div>

      {/* ComfyUI 10-Workflow Template Library */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-6 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-zinc-100 flex items-center gap-2">
            <Layers className="w-4 h-4 text-amber-400" />
            <span>Βιβλιοθήκη 10 Επίσημων ComfyUI Workflows (RTX 3060 12GB)</span>
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            Πλήρως παραμετροποιημένα API workflows έτοιμα για αποστολή στο ComfyUI REST endpoint.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {workflows.map((wf) => (
            <div
              key={wf.id}
              className="p-4 rounded-lg bg-zinc-950 border border-zinc-800 space-y-2 text-xs"
            >
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-zinc-200">{wf.name}</h4>
                <span className="px-2 py-0.5 rounded bg-zinc-900 font-mono text-[10px] text-amber-400 border border-zinc-800">
                  {wf.category}
                </span>
              </div>
              <p className="text-zinc-400 leading-relaxed text-[11px]">{wf.description}</p>
              <div className="pt-2 border-t border-zinc-800/80 flex flex-wrap gap-2 text-[10px] font-mono text-zinc-500">
                <span>VRAM: {wf.recommendedVramGb}GB</span>
                <span>•</span>
                <span>Checkpoints: {wf.requiredCheckpoints.join(', ')}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
