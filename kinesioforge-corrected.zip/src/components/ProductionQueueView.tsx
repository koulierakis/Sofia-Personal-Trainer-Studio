import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  RotateCw,
  XCircle,
  Cpu,
  Sparkles,
  Layers,
  CheckCircle2,
  AlertCircle,
  ListPlus,
} from 'lucide-react';
import { ProductionJob, QueueProgress } from '../types/pipeline';

export const ProductionQueueView: React.FC = () => {
  const [jobs, setJobs] = useState<ProductionJob[]>([]);
  const [progress, setProgress] = useState<QueueProgress | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const fetchQueue = async () => {
    try {
      const resp = await fetch('/api/queue');
      if (resp.ok) {
        const data = await resp.json();
        setJobs(data.jobs || []);
        setProgress(data.progress || null);
      }
    } catch (err) {
      console.error('Error fetching production queue:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchQueue();
    const interval = setInterval(fetchQueue, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleStart = async () => {
    await fetch('/api/queue/start', { method: 'POST' });
    fetchQueue();
  };

  const handlePause = async () => {
    await fetch('/api/queue/pause', { method: 'POST' });
    fetchQueue();
  };

  const handleResume = async () => {
    await fetch('/api/queue/resume', { method: 'POST' });
    fetchQueue();
  };

  const handleCancel = async () => {
    await fetch('/api/queue/cancel', { method: 'POST' });
    fetchQueue();
  };

  const handleRetryFailed = async () => {
    await fetch('/api/queue/retry-failed', { method: 'POST' });
    fetchQueue();
  };

  const handleEnqueueMissing = async () => {
    await fetch('/api/queue/enqueue-all', { method: 'POST' });
    fetchQueue();
  };

  const handleUpdateSettings = async (concurrency?: number, provider?: string) => {
    await fetch('/api/queue/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ concurrency, provider }),
    });
    fetchQueue();
  };

  const filteredJobs = jobs.filter((j) => {
    if (statusFilter === 'all') return true;
    return j.status === statusFilter;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Layers className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Ουρά Μαζικής Παραγωγής Φωτογραφιών (Durable Production Queue)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Διαχειρίζεται όλες τις 64 φάσεις της παραγωγής, με έλεγχο ταυτοχρονισμού (concurrency limiter) για αποφυγή υπερχείλισης VRAM στην RTX 3060 12GB και δυνατότητα άμεσης επανάληψης.
            </p>
          </div>

          {/* Master Control Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {!progress?.isRunning || progress?.isPaused ? (
              <button
                onClick={progress?.isPaused ? handleResume : handleStart}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-lg transition cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>{progress?.isPaused ? 'Συνέχιση Ουράς' : 'Εκκίνηση Ουράς'}</span>
              </button>
            ) : (
              <button
                onClick={handlePause}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-zinc-950 font-bold text-xs rounded-lg transition cursor-pointer"
              >
                <Pause className="w-4 h-4 fill-current" />
                <span>Παύση Ουράς</span>
              </button>
            )}

            <button
              onClick={handleEnqueueMissing}
              className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-amber-300 font-medium text-xs rounded-lg border border-zinc-700 transition cursor-pointer"
              title="Εισαγωγή όλων των ελλειπουσών φάσεων στην ουρά"
            >
              <ListPlus className="w-4 h-4" />
              <span>Προσθήκη Ελλειπουσών</span>
            </button>

            <button
              onClick={handleRetryFailed}
              className="flex items-center gap-1.5 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 font-medium text-xs rounded-lg border border-zinc-700 transition cursor-pointer"
            >
              <RotateCw className="w-4 h-4" />
              <span>Επανάληψη Αποτυχιών</span>
            </button>

            <button
              onClick={handleCancel}
              className="flex items-center gap-1.5 px-3 py-2 bg-rose-950/40 hover:bg-rose-950 text-rose-300 font-medium text-xs rounded-lg border border-rose-900 transition cursor-pointer"
            >
              <XCircle className="w-4 h-4" />
              <span>Ακύρωση</span>
            </button>
          </div>
        </div>

        {/* Progress Bar & Stats */}
        {progress && (
          <div className="mt-6 pt-5 border-t border-zinc-800 space-y-3">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between text-xs gap-2">
              <div className="flex items-center gap-2">
                <span className="text-zinc-400">Συνολική Πρόοδος Παραγωγής:</span>
                <span className="font-mono font-bold text-zinc-100 text-sm">
                  {progress.completedJobs} / {progress.totalJobs} ({progress.percentComplete}%)
                </span>
                <span className="text-zinc-600">•</span>
                <span className="text-zinc-400">
                  Ενεργές: <strong className="text-amber-400 font-mono">{progress.activeJobs}</strong>
                </span>
                <span className="text-zinc-600">•</span>
                <span className="text-zinc-400">
                  Σε Αναμονή: <strong className="text-zinc-300 font-mono">{progress.queuedJobs}</strong>
                </span>
                <span className="text-zinc-600">•</span>
                <span className="text-zinc-400">
                  Αποτυχίες: <strong className="text-rose-400 font-mono">{progress.failedJobs}</strong>
                </span>
              </div>

              {/* Hardware Concurrency & Provider Switcher */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                  <span>Πάροχος:</span>
                  <select
                    value={progress.activeProvider}
                    onChange={(e) => handleUpdateSettings(undefined, e.target.value)}
                    className="bg-zinc-950 text-amber-400 font-mono text-xs px-2 py-1 rounded border border-zinc-700 cursor-pointer"
                  >
                    <option value="comfyui">ComfyUI (Local RTX 3060)</option>
                    <option value="gemini">Gemini Image API</option>
                  </select>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-zinc-400">
                  <span>Concurrency:</span>
                  <select
                    value={progress.concurrencyLimit}
                    onChange={(e) => handleUpdateSettings(parseInt(e.target.value, 10))}
                    className="bg-zinc-950 text-zinc-300 font-mono text-xs px-2 py-1 rounded border border-zinc-700 cursor-pointer"
                  >
                    <option value="1">1 (Safe 12GB VRAM)</option>
                    <option value="2">2 (High VRAM)</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Visual Bar */}
            <div className="w-full h-2 rounded-full bg-zinc-950 overflow-hidden border border-zinc-800">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-emerald-500 transition-all duration-500"
                style={{ width: `${progress.percentComplete}%` }}
              ></div>
            </div>
          </div>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 text-xs overflow-x-auto pb-1">
        {['all', 'queued', 'generating', 'completed', 'failed', 'idle'].map((st) => (
          <button
            key={st}
            onClick={() => setStatusFilter(st)}
            className={`px-3 py-1.5 rounded-lg border font-mono transition cursor-pointer capitalize ${
              statusFilter === st
                ? 'bg-zinc-800 text-amber-400 border-zinc-700'
                : 'bg-zinc-900/50 text-zinc-500 border-zinc-800/80 hover:text-zinc-300'
            }`}
          >
            {st === 'all' ? 'Όλες οι Εργασίες' : st} (
            {st === 'all' ? jobs.length : jobs.filter((j) => j.status === st).length})
          </button>
        ))}
      </div>

      {/* Jobs Table */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 uppercase font-mono text-[11px] border-b border-zinc-800">
              <tr>
                <th className="p-3.5">ID Εργασίας</th>
                <th className="p-3.5">Άσκηση & Φάση</th>
                <th className="p-3.5">Κατάσταση</th>
                <th className="p-3.5">Πάροχος</th>
                <th className="p-3.5">Δοκιμές</th>
                <th className="p-3.5">Διάρκεια</th>
                <th className="p-3.5">Prompt</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/70">
              {filteredJobs.slice(0, 50).map((job) => {
                let badgeColor = 'bg-zinc-800 text-zinc-400 border-zinc-700';
                if (job.status === 'completed') {
                  badgeColor = 'bg-emerald-950 text-emerald-300 border-emerald-800';
                } else if (job.status === 'generating') {
                  badgeColor = 'bg-amber-950 text-amber-300 border-amber-800 animate-pulse';
                } else if (job.status === 'failed') {
                  badgeColor = 'bg-rose-950 text-rose-300 border-rose-800';
                } else if (job.status === 'queued') {
                  badgeColor = 'bg-blue-950 text-blue-300 border-blue-800';
                }

                return (
                  <tr key={job.jobId} className="hover:bg-zinc-800/40 transition">
                    <td className="p-3.5 font-mono text-[11px] text-zinc-400">
                      {job.jobId.slice(0, 16)}...
                    </td>
                    <td className="p-3.5">
                      <div className="font-semibold text-zinc-100">{job.exerciseName}</div>
                      <div className="text-[11px] text-amber-400 font-mono">
                        Φάση {job.phaseNumber}: {job.phaseName}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${badgeColor}`}>
                        {job.status.toUpperCase()}
                      </span>
                      {job.errorMessage && (
                        <div className="text-[10px] text-rose-400 mt-1 max-w-xs truncate" title={job.errorMessage}>
                          {job.errorMessage}
                        </div>
                      )}
                    </td>
                    <td className="p-3.5 font-mono text-[11px] text-zinc-300 uppercase">
                      {job.provider}
                    </td>
                    <td className="p-3.5 font-mono text-zinc-400">
                      {job.attempts} / {job.maxAttempts}
                    </td>
                    <td className="p-3.5 font-mono text-zinc-400">
                      {job.durationMs ? `${(job.durationMs / 1000).toFixed(1)}s` : '-'}
                    </td>
                    <td className="p-3.5 max-w-xs truncate text-[11px] text-zinc-400" title={job.prompt}>
                      {job.prompt}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
