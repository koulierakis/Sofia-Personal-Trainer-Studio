import React, { useState } from 'react';
import {
  Image,
  AlertTriangle,
  Copy,
  Check,
  CheckCircle2,
  XCircle,
  Eye,
  Filter,
} from 'lucide-react';
import { ExerciseRecord, PhaseRecord } from '../types/pipeline';

interface ImageLibraryViewProps {
  exercises: ExerciseRecord[];
  onOpenPhase: (exerciseId: string, phaseNumber: number) => void;
}

export const ImageLibraryView: React.FC<ImageLibraryViewProps> = ({
  exercises,
  onOpenPhase,
}) => {
  const [provenanceFilter, setProvenanceFilter] = useState<string>('all');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  const allPhases: Array<{ exercise: ExerciseRecord; phase: PhaseRecord }> = [];
  exercises.forEach((ex) => {
    ex.phases.forEach((ph) => {
      allPhases.push({ exercise: ex, phase: ph });
    });
  });

  const filtered = allPhases.filter(({ phase }) => {
    if (provenanceFilter === 'all') return true;
    if (provenanceFilter === 'has_image') return !!phase.outputPath;
    if (provenanceFilter === 'missing') return !phase.outputPath;
    return phase.provenance.type === provenanceFilter;
  });

  const handleCopy = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Image className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Βιβλιοθήκη & Αποθετήριο Εικόνων (Image Library)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Επισκόπηση όλων των αποθηκευμένων αρχείων εικόνας με κρυπτογραφικό έλεγχο κατακερματισμού (SHA-256), μέγεθος σε bytes και διάκριση μεταξύ πραγματικής AI φωτογραφίας και ενδεικτικών σχηματικών fixtures.
            </p>
          </div>

          {/* Filter Dropdown */}
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-zinc-500" />
            <select
              value={provenanceFilter}
              onChange={(e) => setProvenanceFilter(e.target.value)}
              className="bg-zinc-950 text-zinc-300 text-xs rounded-lg px-3 py-2 border border-zinc-700 focus:outline-none focus:border-amber-500 cursor-pointer"
            >
              <option value="all">Όλες οι Φάσεις ({allPhases.length})</option>
              <option value="has_image">Με Αποθηκευμένη Εικόνα (6)</option>
              <option value="missing">Ελλείπουσες Εικόνες (58)</option>
              <option value="PROGRAMMATIC_SEED">Canvas Seed Fixtures (6)</option>
              <option value="GENERATED_AI_VERIFIED">Γνήσιες AI Φωτογραφίες (0)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid of Image Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {filtered.map(({ exercise, phase }) => {
          const isSeed = phase.provenance.type === 'PROGRAMMATIC_SEED';
          const isDuplicate = phase.qcReport.isDuplicate;

          return (
            <div
              key={phase.id}
              className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden flex flex-col justify-between hover:border-zinc-700 transition"
            >
              {/* Image Preview Container */}
              <div className="relative aspect-square w-full bg-zinc-950 flex items-center justify-center overflow-hidden border-b border-zinc-800">
                {phase.outputPath ? (
                  <>
                    <img
                      src={`/${phase.outputPath}`}
                      alt={phase.phaseName}
                      className="w-full h-full object-contain"
                    />

                    {/* Watermark badge */}
                    <div className="absolute top-2 left-2">
                      {isSeed && (
                        <span className="px-2 py-0.5 rounded bg-amber-950/80 text-amber-300 text-[10px] font-mono border border-amber-700/80 flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3 text-amber-400" />
                          <span>FIXTURE</span>
                        </span>
                      )}
                    </div>

                    {isDuplicate && (
                      <div className="absolute bottom-0 inset-x-0 bg-rose-950/90 text-rose-200 text-[10px] font-mono p-1 text-center border-t border-rose-800">
                        DUPLICATE (SHA-256 MATCH)
                      </div>
                    )}
                  </>
                ) : (
                  <div className="text-center p-4 text-zinc-600 space-y-1">
                    <XCircle className="w-8 h-8 mx-auto stroke-1" />
                    <span className="text-[11px] block text-zinc-500 font-mono">
                      No Image Asset
                    </span>
                  </div>
                )}
              </div>

              {/* Card Meta */}
              <div className="p-3.5 space-y-2 text-xs flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-zinc-500 text-[10px] font-mono mb-1">
                    <span className="text-amber-500 font-bold">
                      Φάση {phase.phaseNumber}
                    </span>
                    <span>{phase.fileSizeBytes ? `${(phase.fileSizeBytes / 1024).toFixed(1)} KB` : '0 KB'}</span>
                  </div>
                  <h4 className="font-bold text-zinc-200 line-clamp-1">{exercise.english_name}</h4>
                  <p className="text-[11px] text-zinc-400 line-clamp-1">{phase.phaseName}</p>
                </div>

                {/* Hash Box */}
                {phase.imageChecksum && (
                  <div className="pt-2 border-t border-zinc-800/80">
                    <div className="flex items-center justify-between text-[10px] text-zinc-500 mb-0.5">
                      <span>SHA-256:</span>
                      <button
                        onClick={() => handleCopy(phase.imageChecksum!)}
                        className="text-zinc-400 hover:text-amber-400 cursor-pointer flex items-center gap-1"
                      >
                        {copiedHash === phase.imageChecksum ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                        <span>{copiedHash === phase.imageChecksum ? 'Αντιγράφηκε' : 'Copy'}</span>
                      </button>
                    </div>
                    <div className="font-mono text-[9px] text-zinc-400 truncate bg-zinc-950 p-1 rounded border border-zinc-800">
                      {phase.imageChecksum}
                    </div>
                  </div>
                )}

                {/* Inspect Action */}
                <button
                  onClick={() => onOpenPhase(exercise.id, phase.phaseNumber)}
                  className="w-full mt-2 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-medium flex items-center justify-center gap-1 transition cursor-pointer"
                >
                  <Eye className="w-3 h-3 text-amber-400" />
                  <span>Επιθεώρηση στο Studio</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
