import React from 'react';
import {
  CheckCircle2,
  XCircle,
  Play,
  FlaskConical,
  RotateCw,
  ShieldCheck,
  ShieldAlert,
} from 'lucide-react';
import { TestSuiteReport } from '../types/pipeline';

interface AutomatedTestsViewProps {
  report: TestSuiteReport | null;
  isRunning: boolean;
  onRunTests: () => void;
}

export const AutomatedTestsView: React.FC<AutomatedTestsViewProps> = ({
  report,
  isRunning,
  onRunTests,
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Overview Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Αυτοματοποιημένη Σουίτα Επαλήθευσης & Ακεραιότητας ({report?.totalTests || 25} Σημεία Ελέγχου)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Μαθηματικός και λογικός έλεγχος όλων των συνθηκών αποτυχίας: απόρριψη ψευδούς προέλευσης (provenance), ανίχνευση συγκρούσεων SHA-256, διαχείριση σφαλμάτων quota 429, ανθεκτικότητα ComfyUI εκτός σύνδεσης, προστασία path traversal, Sofia Catalog Commit, Idempotency, WebP RIFF headers και επαλήθευση εξαγωγών Sofia.
            </p>
          </div>

          <div className="flex items-center gap-3">
            {report && (
              <div
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono font-medium ${
                  report.allPassed
                    ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800'
                    : 'bg-rose-950/60 text-rose-300 border-rose-800'
                }`}
              >
                {report.allPassed ? (
                  <>
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                    <span>ALL TESTS PASSED ({report.passedTests}/{report.totalTests})</span>
                  </>
                ) : (
                  <>
                    <ShieldAlert className="w-4 h-4 text-rose-400" />
                    <span>FAILED ({report.failedTests}/{report.totalTests})</span>
                  </>
                )}
              </div>
            )}

            <button
              onClick={onRunTests}
              disabled={isRunning}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isRunning ? 'animate-spin' : ''}`} />
              <span>{isRunning ? 'Executing Suite...' : 'Re-Run All Tests'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Tests Grid */}
      {report ? (
        <div className="space-y-4">
          {report.tests.map((t, idx) => (
            <div
              key={t.id}
              className={`p-5 rounded-xl border transition ${
                t.passed
                  ? 'bg-zinc-900/60 border-zinc-800 hover:border-zinc-700'
                  : 'bg-rose-950/20 border-rose-900/60'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                <div className="flex items-center gap-2.5">
                  {t.passed ? (
                    <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                  ) : (
                    <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                  )}
                  <h3 className="text-sm font-semibold text-zinc-100">{t.name}</h3>
                </div>
                <span
                  className={`text-xs px-2.5 py-0.5 rounded font-mono font-medium self-start sm:self-auto ${
                    t.passed
                      ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                      : 'bg-rose-950 text-rose-300 border border-rose-800'
                  }`}
                >
                  {t.passed ? 'PASSED' : 'FAILED'}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs bg-zinc-950/70 p-3.5 rounded-lg border border-zinc-800/80 mb-3">
                <div>
                  <span className="text-zinc-500 font-mono block mb-0.5">EXPECTED:</span>
                  <span className="text-zinc-300">{t.expected}</span>
                </div>
                <div>
                  <span className="text-zinc-500 font-mono block mb-0.5">ACTUAL:</span>
                  <span className="text-zinc-300 font-mono text-[11px] break-all">{t.actual}</span>
                </div>
              </div>

              <p className="text-xs text-zinc-400 leading-relaxed">{t.details}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="p-12 text-center text-zinc-500">
          Click &quot;Re-Run All Tests&quot; to execute the comprehensive automated test suite.
        </div>
      )}
    </div>
  );
};
