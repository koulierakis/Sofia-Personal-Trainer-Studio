import React, { useState } from 'react';
import {
  Download,
  ShieldAlert,
  FileCode,
  PackageCheck,
  FileCheck,
  AlertTriangle,
  FolderArchive,
  ArrowDownToLine,
  UploadCloud,
  CheckCircle2,
  RefreshCw,
  Terminal,
  Layers,
} from 'lucide-react';
import { IntegrityDashboardStats } from '../types/pipeline';

interface SofiaExportPanelProps {
  stats: IntegrityDashboardStats | null;
}

interface DryRunReport {
  timestamp: string;
  totalSofiaExercises: number;
  totalCalculatedTasks: number;
  existingMatchedExercises: number;
  newExercisesDiscovered: number;
  missingPhotographyTasks: number;
  alreadyApprovedCount: number;
  exercises: Array<{
    id: string;
    name: string;
    phasesRequired: number;
    matchedInKinesioForge: boolean;
    missingPhases: number[];
  }>;
}

export const SofiaExportPanel: React.FC<SofiaExportPanelProps> = ({ stats }) => {
  const [includeFixtures, setIncludeFixtures] = useState(true);
  const [activeJsonTab, setActiveJsonTab] = useState<'catalog' | 'audit' | 'manifest'>('catalog');

  // Intake State
  const [catalogJsonInput, setCatalogJsonInput] = useState<string>('');
  const [dryRunReport, setDryRunReport] = useState<DryRunReport | null>(null);
  const [isIntaking, setIsIntaking] = useState(false);
  const [intakeSuccessMsg, setIntakeSuccessMsg] = useState<string | null>(null);
  const [intakeErrorMsg, setIntakeErrorMsg] = useState<string | null>(null);

  const handleDownloadSofia = () => {
    window.location.href = `/api/export/sofia?fixtures=${includeFixtures}`;
  };

  const handleDownloadKinesio = () => {
    window.location.href = `/api/export/kinesioforge?fixtures=${includeFixtures}`;
  };

  const handleDownloadWindowsStarterKit = () => {
    window.location.href = '/api/download/windows-starter-kit';
  };

  const loadSampleSofiaCatalog = () => {
    const sample = [
      {
        id: 'ex-01-rotational-cossack-squat-to-diagonal-landm',
        name: 'Rotational Cossack Squat to Diagonal Landmine Press',
        greekName: 'Περιστροφικό Cossack Squat με Διαγώνιο Landmine Press',
        category: 'Functional Athleticism',
        phasesCount: 6,
      },
      {
        id: 'ex-02-zercher-curtsy-lunge-to-lateral-step-up',
        name: 'Zercher Curtsy Lunge to Lateral Step-Up',
        greekName: 'Zercher Curtsy Lunge με Πλευρικό Step-Up',
        category: 'Lower Body Unilateral Strength',
        phasesCount: 6,
      },
      {
        id: 'ex-sofia-single-leg-rdl-plyo',
        name: 'Single-Leg Romanian Deadlift to Plyometric Jump',
        greekName: 'Μονοποδικό Ρουμανικό Deadlift με Πλειομετρικό Άλμα',
        category: 'Posterior Chain Explosiveness',
        phasesCount: 6,
      },
    ];
    setCatalogJsonInput(JSON.stringify(sample, null, 2));
    setIntakeErrorMsg(null);
    setIntakeSuccessMsg(null);
  };

  const handleRunDryRun = async () => {
    if (!catalogJsonInput.trim()) {
      setIntakeErrorMsg('Παρακαλώ εισάγετε ένα έγκυρο JSON κατάλογο Sofia.');
      return;
    }

    setIsIntaking(true);
    setIntakeErrorMsg(null);
    setIntakeSuccessMsg(null);

    try {
      let parsed;
      try {
        parsed = JSON.parse(catalogJsonInput);
      } catch (e: any) {
        throw new Error('Μη έγκυρη σύνταξη JSON: ' + e.message);
      }

      const res = await fetch('/api/sofia/dry-run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ catalog: parsed }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Αποτυχία Dry-run ανάλυσης.');
      }

      setDryRunReport(data.report);
      setIntakeSuccessMsg(
        `Dry-Run Ολοκληρώθηκε: ${data.report.totalSofiaExercises} ασκήσεις αναλύθηκαν (${data.report.existingMatchedExercises} ταυτοποιήθηκαν, ${data.report.newExercisesDiscovered} νέες).`
      );
    } catch (err: any) {
      setIntakeErrorMsg(err.message);
    } finally {
      setIsIntaking(false);
    }
  };

  const handleCommitCatalog = async () => {
    if (!catalogJsonInput.trim()) return;

    setIsIntaking(true);
    setIntakeErrorMsg(null);
    setIntakeSuccessMsg(null);

    try {
      const parsed = JSON.parse(catalogJsonInput);
      const res = await fetch('/api/sofia/commit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ catalog: parsed }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Αποτυχία καταχώρισης καταλόγου.');
      }

      setIntakeSuccessMsg(
        `Επιτυχής Καταχώριση: ${data.result.addedCount} νέες ασκήσεις εντάχθηκαν, ${data.result.updatedCount || 0} ενημερώθηκαν. ${data.result.scheduledTasks} εργασίες φωτογράφισης προγραμματίστηκαν στην ουρά! (Σύνολο: ${data.result.totalExercises} ασκήσεις, ${data.result.totalPhases} φάσεις)`
      );
    } catch (err: any) {
      setIntakeErrorMsg(err.message);
    } finally {
      setIsIntaking(false);
    }
  };

  const isProduction = stats?.isProductionReady ?? false;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Top Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Sofia Personal Trainer Studio Export & Intake Engine
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Δημιουργία πακέτων εξαγωγής για το Sofia Personal Trainer Studio και ανάλυση dry-run για νέους καταλόγους ασκήσεων. Εξαγωγή WebP assets, SHA-256 manifests και Windows Starter Kit.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleDownloadSofia}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs shadow-md transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Λήψη Sofia Bundle ZIP (WebP)</span>
            </button>
            <button
              onClick={handleDownloadKinesio}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 font-medium text-xs border border-zinc-700 transition cursor-pointer"
            >
              <ArrowDownToLine className="w-4 h-4" />
              <span>KinesioForge Batch ZIP</span>
            </button>
            <button
              onClick={handleDownloadWindowsStarterKit}
              title="Λήψη πακέτου εκκίνησης ComfyUI για Windows (run-comfyui-direct.bat)"
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 font-medium text-xs border border-indigo-700/60 transition cursor-pointer"
            >
              <Terminal className="w-4 h-4" />
              <span>Windows Starter Kit</span>
            </button>
          </div>
        </div>
      </div>

      {/* Production Readiness Guard Warning */}
      {!isProduction && (
        <div className="rounded-xl border border-amber-500/40 bg-amber-950/20 p-5 shadow-lg">
          <div className="flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 shrink-0">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div className="space-y-2">
              <h3 className="text-sm font-semibold text-amber-200">
                Αυστηρή Πύλη Ετοιμότητας Παραγωγής: INCOMPLETE (Μη Ολοκληρωμένο)
              </h3>
              <p className="text-xs text-amber-300/90 leading-relaxed">
                Το εξαγόμενο πακέτο επισημαίνεται αυστηρά ως{' '}
                <strong className="text-amber-100 font-mono">isProductionReady: false</strong>. Περιέχει 58 μη ολοκληρωμένες φάσεις κίνησης, και τα 6 υπάρχοντα αρχεία PNG αναγνωρίζονται ρητά ως διανυσματικά seeds ανάπτυξης. Απαγορεύεται η χρήση των fixtures ως τελικών φωτογραφιών Sofia.
              </p>
              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeFixtures}
                    onChange={(e) => setIncludeFixtures(e.target.checked)}
                    className="rounded border-zinc-700 text-amber-500 focus:ring-0 bg-zinc-950"
                  />
                  <span>
                    Συμπερίληψη των 6 διανυσματικών fixtures στο αρχείο ZIP (για δοκιμή του αγωγού)
                  </span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Section 2: Sofia Catalog Intake & Dry-Run Analyzer */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800 pb-3">
          <div className="flex items-center gap-2">
            <UploadCloud className="w-5 h-5 text-sky-400" />
            <div>
              <h3 className="text-sm font-bold text-zinc-100">
                Εισαγωγή Καταλόγου Sofia & Dry-Run Ανάλυση (Catalog Intake)
              </h3>
              <p className="text-xs text-zinc-400">
                Ελέγξτε τη συμβατότητα εξωτερικών ασκήσεων του Sofia Personal Trainer χωρίς να τροποποιήσετε άμεσα την τρέχουσα βάση.
              </p>
            </div>
          </div>
          <button
            onClick={loadSampleSofiaCatalog}
            className="text-xs px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-amber-400 font-mono border border-zinc-700 transition cursor-pointer self-start sm:self-auto"
          >
            Φόρτωση Δείγματος (Sample JSON)
          </button>
        </div>

        <div className="space-y-3">
          <textarea
            value={catalogJsonInput}
            onChange={(e) => setCatalogJsonInput(e.target.value)}
            placeholder='Επικολλήστε εδώ το JSON του καταλόγου Sofia (π.χ. [ { "id": "ex-01-...", "name": "...", "phasesCount": 6 } ])...'
            rows={6}
            className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-xs font-mono text-zinc-200 placeholder-zinc-600 focus:outline-none focus:border-amber-500 resize-y"
          />

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleRunDryRun}
              disabled={isIntaking || !catalogJsonInput.trim()}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-sky-600 hover:bg-sky-500 disabled:opacity-50 text-white font-semibold text-xs shadow transition cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isIntaking ? 'animate-spin' : ''}`} />
              <span>Εκτέλεση Dry-Run Ανάλυσης</span>
            </button>

            {dryRunReport && (
              <button
                onClick={handleCommitCatalog}
                disabled={isIntaking}
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-semibold text-xs shadow transition cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Καταχώριση στον Αγωγό & Προγραμματισμός Ουράς</span>
              </button>
            )}
          </div>

          {intakeSuccessMsg && (
            <div className="p-3 rounded-lg bg-emerald-950/60 border border-emerald-800/80 text-emerald-300 text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{intakeSuccessMsg}</span>
            </div>
          )}

          {intakeErrorMsg && (
            <div className="p-3 rounded-lg bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{intakeErrorMsg}</span>
            </div>
          )}

          {/* Dry Run Report Results Card */}
          {dryRunReport && (
            <div className="p-4 rounded-xl bg-zinc-950 border border-zinc-800 space-y-3 mt-4">
              <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
                <span className="text-xs font-mono font-bold text-sky-400">
                  Αναφορά Συμβατότητας Sofia Dry-Run
                </span>
                <span className="text-[11px] font-mono text-zinc-500">
                  {new Date(dryRunReport.timestamp).toLocaleTimeString('el-GR')}
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800">
                  <div className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">Ασκήσεις Sofia</div>
                  <div className="text-base font-bold text-zinc-200 mt-0.5">{dryRunReport.totalSofiaExercises}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800">
                  <div className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">Ταυτοποιημένες</div>
                  <div className="text-base font-bold text-emerald-400 mt-0.5">{dryRunReport.existingMatchedExercises}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800">
                  <div className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">Νέες Ανακαλύφθηκαν</div>
                  <div className="text-base font-bold text-amber-400 mt-0.5">{dryRunReport.newExercisesDiscovered}</div>
                </div>
                <div className="p-2.5 rounded-lg bg-zinc-900 border border-zinc-800">
                  <div className="text-[10px] text-zinc-500 uppercase tracking-wider font-mono">Απαιτούμενες Φωτογραφίες</div>
                  <div className="text-base font-bold text-rose-400 mt-0.5">{dryRunReport.missingPhotographyTasks}</div>
                </div>
              </div>

              <div className="space-y-1.5 max-h-48 overflow-y-auto pt-2">
                {dryRunReport.exercises.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-2 rounded bg-zinc-900/60 border border-zinc-800/60 text-xs"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <span className={`w-2 h-2 rounded-full ${item.matchedInKinesioForge ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                      <span className="font-mono text-zinc-300 truncate">{item.name}</span>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 font-mono text-[11px]">
                      <span className="text-zinc-500">{item.phasesRequired} φάσεις</span>
                      {item.missingPhases.length > 0 ? (
                        <span className="px-1.5 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-900/60">
                          {item.missingPhases.length} λείπουν
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.5 rounded bg-emerald-950/80 text-emerald-300 border border-emerald-900/60">
                          Πλήρες
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Bundle Contents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2">
          <div className="flex items-center justify-between text-zinc-300">
            <span className="text-xs font-semibold font-mono text-amber-400">catalog.json</span>
            <FileCode className="w-4 h-4 text-zinc-500" />
          </div>
          <p className="text-xs text-zinc-400">
            Σχήμα καταλόγου Sofia Studio με βιομηχανικές οδηγίες στα Ελληνικά και Αγγλικά, μυϊκές ομάδες, εξοπλισμό και ορισμούς φάσεων.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2">
          <div className="flex items-center justify-between text-zinc-300">
            <span className="text-xs font-semibold font-mono text-amber-400">audit_report.json</span>
            <FileCheck className="w-4 h-4 text-zinc-500" />
          </div>
          <p className="text-xs text-zinc-400">
            Αποκαλύπτει διπλές συγκρούσεις SHA-256 (duplicate collisions), απογραφή ελλειπόντων φάσεων και ρητούς λόγους απόρριψης παραγωγής.
          </p>
        </div>

        <div className="p-4 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2">
          <div className="flex items-center justify-between text-zinc-300">
            <span className="text-xs font-semibold font-mono text-amber-400">manifest.json</span>
            <PackageCheck className="w-4 h-4 text-zinc-500" />
          </div>
          <p className="text-xs text-zinc-400">
            Πλήρες manifest που περιέχει την προέλευση κάθε αρχείου (provenance), ετικέτες μοντέλων δημιουργίας και κρυπτογραφικά hashes SHA-256.
          </p>
        </div>
      </div>

      {/* Interactive Manifest & Schema Preview */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-4">
        <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
          <h3 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider">
            Προεπισκόπηση Δεδομένων Εξαγωγής (Export Payload Preview)
          </h3>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveJsonTab('catalog')}
              className={`px-3 py-1 rounded text-xs font-mono font-medium transition cursor-pointer ${
                activeJsonTab === 'catalog'
                  ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              catalog.json
            </button>
            <button
              onClick={() => setActiveJsonTab('audit')}
              className={`px-3 py-1 rounded text-xs font-mono font-medium transition cursor-pointer ${
                activeJsonTab === 'audit'
                  ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              audit_report.json
            </button>
            <button
              onClick={() => setActiveJsonTab('manifest')}
              className={`px-3 py-1 rounded text-xs font-mono font-medium transition cursor-pointer ${
                activeJsonTab === 'manifest'
                  ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              manifest.json
            </button>
          </div>
        </div>

        <div className="p-4 rounded-lg bg-zinc-950 border border-zinc-800 font-mono text-xs text-zinc-300 max-h-96 overflow-y-auto leading-relaxed">
          {activeJsonTab === 'catalog' && (
            <pre>
              {JSON.stringify(
                {
                  sofiaStudioVersion: '2.4.0',
                  catalogName: 'KinesioForge Athletic Kinematics Curriculum',
                  isProductionReady: false,
                  readinessStatus: [
                    'APPLICATION_BUILD_READY',
                    'IMAGE_LIBRARY_INCOMPLETE',
                    'IMAGE_LIBRARY_REVIEW_PENDING',
                  ],
                  contentSummary: {
                    totalExercises: 11,
                    totalRequiredPhases: 64,
                    packagedImages: includeFixtures ? 6 : 0,
                    genuinePhotographs: 0,
                    seedFixtures: includeFixtures ? 6 : 0,
                    missingPhases: 58,
                  },
                },
                null,
                2
              )}
            </pre>
          )}

          {activeJsonTab === 'audit' && (
            <pre>
              {JSON.stringify(
                {
                  auditTimestamp: new Date().toISOString(),
                  isProductionReady: false,
                  verdict:
                    'REJECTED FOR PRODUCTION: 58 phases missing; 6 existing images are schematic vector silhouettes with duplicate frame collisions.',
                  duplicateAnalysis: [
                    {
                      sha256:
                        '1df118f593bb36cbe482c3f81e33c6751e3abf066b593eb4b1432f83ee07ff67',
                      impactedPhases: [
                        'ex-01-rotational-cossack-squat-to-diagonal-landm (Phase 1)',
                        'ex-01-rotational-cossack-squat-to-diagonal-landm (Phase 6)',
                      ],
                    },
                  ],
                },
                null,
                2
              )}
            </pre>
          )}

          {activeJsonTab === 'manifest' && (
            <pre>
              {JSON.stringify(
                {
                  project: 'KinesioForge AI Image Engine',
                  exportType: 'Sofia Personal Trainer Studio Export',
                  provenanceVerification: 'STRICT_ENFORCEMENT',
                  samplePhase: {
                    id: 'ex-01-rotational-cossack-squat-to-diagonal-landm_phase-01',
                    provenance: {
                      type: 'PROGRAMMATIC_SEED',
                      provider: 'programmatic',
                      model: 'schematic-canvas-fixture-v1',
                      isSeeded: true,
                      sizeBytes: 23624,
                    },
                    qcReport: {
                      overallStatus: 'failed',
                      isPlaceholderDetected: true,
                      verdictSummary:
                        'REJECTED FOR PRODUCTION: Development fixture vector graphic.',
                    },
                  },
                },
                null,
                2
              )}
            </pre>
          )}
        </div>
      </div>
    </div>
  );
};
