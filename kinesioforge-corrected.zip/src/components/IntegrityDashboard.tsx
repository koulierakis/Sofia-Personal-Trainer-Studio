import React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileCheck,
  Cpu,
  Layers,
  Copy,
  Camera,
  Activity,
  ArrowRight,
} from 'lucide-react';
import { ExerciseRecord, IntegrityDashboardStats } from '../types/pipeline';

interface IntegrityDashboardProps {
  stats: IntegrityDashboardStats | null;
  exercises: ExerciseRecord[];
  onSelectExercise: (exerciseId: string, phaseNumber?: number) => void;
  onNavigateTab: (tab: string) => void;
}

export const IntegrityDashboard: React.FC<IntegrityDashboardProps> = ({
  stats,
  exercises,
  onSelectExercise,
  onNavigateTab,
}) => {
  if (!stats) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500"></div>
      </div>
    );
  }

  const genuineCoverage =
    stats.totalPhases > 0
      ? ((stats.genuineAIGenerated / stats.totalPhases) * 100).toFixed(1)
      : '0.0';

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Critical Alert Banner */}
      <div className="rounded-xl border border-rose-500/30 bg-rose-950/20 p-5 shadow-lg backdrop-blur-sm">
        <div className="flex items-start gap-4">
          <div className="p-2.5 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400 shrink-0">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <h2 className="text-base font-semibold text-rose-200">
                Data Authenticity & Production-Readiness Alert
              </h2>
              <span className="text-xs px-2 py-0.5 rounded bg-rose-900/60 text-rose-300 font-mono border border-rose-700/50">
                Audit Status: FAILED
              </span>
            </div>
            <p className="text-sm text-rose-300/90 leading-relaxed">
              The independent export audit confirmed that all 6 existing PNG files are simplistic 23KB programmatic silhouettes, Phase 01 and Phase 06 share identical binary data, and 58 of 64 movement phases have no generated photography. Production readiness is strictly enforced as{' '}
              <strong className="text-rose-100 font-mono">FALSE</strong> until all 64 genuine athletic photographs are generated and verified.
            </p>
            <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
              <span className="text-zinc-400">
                Genuine AI Photographic Coverage:{' '}
                <strong className="text-rose-400 font-mono">{genuineCoverage}%</strong> (0/64)
              </span>
              <span className="text-zinc-600">•</span>
              <span className="text-zinc-400">
                Development Fixtures:{' '}
                <strong className="text-amber-400 font-mono">6</strong> (Ex 01 Canvas Vectors)
              </span>
              <span className="text-zinc-600">•</span>
              <span className="text-zinc-400">
                Missing Movement Phases:{' '}
                <strong className="text-zinc-300 font-mono">58</strong> / 64
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {/* Card 1: Total Phases */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Required Movement Phases</span>
            <Layers className="w-4 h-4 text-zinc-500" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono text-zinc-100">{stats.totalPhases}</span>
            <span className="text-xs text-zinc-500">across 11 exercises</span>
          </div>
          <p className="text-xs text-zinc-400 mt-2">
            9 exercises with 6 phases + 2 exercises with 5 phases (64 total)
          </p>
        </div>

        {/* Card 2: Genuine AI Photographs */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Genuine AI Photographs</span>
            <Camera className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono text-zinc-100">{stats.genuineAIGenerated}</span>
            <span className="text-xs font-mono text-rose-400">({genuineCoverage}%)</span>
          </div>
          <p className="text-xs text-zinc-400 mt-2">
            Strictly requires real model execution; seed vectors do not count
          </p>
        </div>

        {/* Card 3: Missing Phases */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Missing Movement Phases</span>
            <XCircle className="w-4 h-4 text-rose-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono text-amber-400">{stats.missingPhases}</span>
            <span className="text-xs text-zinc-500">/ 64 needed</span>
          </div>
          <p className="text-xs text-zinc-400 mt-2">
            Ready to generate via Gemini Image or local ComfyUI GPU
          </p>
        </div>

        {/* Card 4: Duplicate Collisions */}
        <div className="p-4 rounded-xl bg-zinc-900/80 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-2">
            <span className="text-xs font-medium uppercase tracking-wider">Duplicate Binaries</span>
            <Copy className="w-4 h-4 text-rose-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono text-rose-400">{stats.duplicateCount}</span>
            <span className="text-xs text-zinc-500">collision flagged</span>
          </div>
          <p className="text-xs text-zinc-400 mt-2">
            Phase 01 vs Phase 06 share identical binary (1df118f5...)
          </p>
        </div>
      </div>

      {/* Readiness Categorization Matrix */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-6">
        <h3 className="text-sm font-semibold text-zinc-200 mb-4 flex items-center gap-2">
          <Activity className="w-4 h-4 text-amber-400" />
          <span>Multi-Tier Production Readiness Categorization</span>
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-lg border border-emerald-900/40 bg-emerald-950/20">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-emerald-400 font-mono">
                APPLICATION_BUILD_READY
              </span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-xs text-zinc-400">
              TypeScript SPA, Express server, Vite middleware, export streams, and state persistence verified.
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-amber-900/40 bg-amber-950/20">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-amber-400 font-mono">
                IMAGE_LIBRARY_INCOMPLETE
              </span>
              <AlertTriangle className="w-4 h-4 text-amber-400" />
            </div>
            <p className="text-xs text-zinc-400">
              58 of 64 movement phases have no image. 6 exist as programmatic vector fixtures.
            </p>
          </div>

          <div className="p-3.5 rounded-lg border border-rose-900/40 bg-rose-950/20">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold text-rose-400 font-mono">
                PRODUCTION_CONTENT_READY
              </span>
              <XCircle className="w-4 h-4 text-rose-400" />
            </div>
            <p className="text-xs text-zinc-400">
              STRICTLY FALSE. Commercial release blocked until 64 genuine photorealistic images are verified.
            </p>
          </div>
        </div>
      </div>

      {/* Forensic Duplicate Inspector */}
      {stats.duplicateDetections.length > 0 && (
        <div className="rounded-xl border border-rose-900/50 bg-zinc-900/70 p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Copy className="w-4 h-4 text-rose-400" />
              <h3 className="text-sm font-semibold text-zinc-200">
                Forensic Binary Duplicate Analysis (Collision Detected)
              </h3>
            </div>
            <span className="text-xs px-2 py-0.5 rounded bg-rose-950 text-rose-300 font-mono border border-rose-800">
              SHA-256 Collisions: {stats.duplicateDetections.length}
            </span>
          </div>

          <div className="space-y-4">
            {stats.duplicateDetections.map((dup, idx) => (
              <div key={idx} className="p-4 rounded-lg bg-zinc-950/80 border border-zinc-800">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono text-zinc-400">Hash:</span>
                    <span className="text-xs font-mono text-rose-300 bg-rose-950/50 px-2 py-0.5 rounded border border-rose-900/40">
                      {dup.hash}
                    </span>
                  </div>
                  <span className="text-xs text-zinc-500">Binary Size: 23,624 bytes (Identical)</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {dup.phases.map((ph, pIdx) => (
                    <div
                      key={pIdx}
                      className="p-3 rounded-md bg-zinc-900 border border-zinc-800 flex items-center justify-between"
                    >
                      <div>
                        <div className="text-xs font-medium text-zinc-200">
                          {ph.exerciseId}
                        </div>
                        <div className="text-xs text-amber-400 font-mono">
                          Movement Phase {String(ph.phaseNumber).padStart(2, '0')}{' '}
                          {ph.phaseNumber === 1 ? '(Setup)' : '(Reset & Stabilization)'}
                        </div>
                      </div>
                      <button
                        onClick={() => onSelectExercise(ph.exerciseId, ph.phaseNumber)}
                        className="text-xs text-zinc-400 hover:text-amber-400 flex items-center gap-1 cursor-pointer"
                      >
                        <span>Inspect</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  ))}
                </div>

                <p className="text-xs text-rose-300/80 mt-3 border-t border-zinc-800/80 pt-2">
                  <strong>Biomechanical Diagnosis:</strong> In athletic performance, Setup and Reset are kinetically distinct positions. Phase 01 represents bilateral sumo stance barbell alignment, whereas Phase 06 represents post-press eccentric reset. Reusing identical pixel binaries violates kinematic truth.
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 64-Phase Comprehensive Movement Matrix */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h3 className="text-sm font-semibold text-zinc-200">
              64-Phase Curriculum Matrix (11 Exercises)
            </h3>
            <p className="text-xs text-zinc-400">
              Real-time asset provenance and generation state for each phase
            </p>
          </div>
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1.5 text-zinc-400">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>Fixture Vector (6)</span>
            </span>
            <span className="flex items-center gap-1.5 text-zinc-400">
              <span className="w-2.5 h-2.5 rounded-full bg-zinc-700"></span>
              <span>Missing Photo (58)</span>
            </span>
            <span className="flex items-center gap-1.5 text-zinc-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>Genuine AI (0)</span>
            </span>
          </div>
        </div>

        <div className="space-y-3">
          {exercises.map((ex, idx) => (
            <div
              key={ex.id}
              className="p-3.5 rounded-lg bg-zinc-900/80 border border-zinc-800 hover:border-zinc-700 transition"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-amber-500 w-6">
                    #{String(idx + 1).padStart(2, '0')}
                  </span>
                  <span className="text-xs font-medium text-zinc-200">
                    {ex.english_name}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 font-mono">
                    {ex.totalPhases === 5 ? '5 Phases (Five-phase movement)' : '6 Phases'}
                  </span>
                </div>
                <button
                  onClick={() => onSelectExercise(ex.id)}
                  className="text-xs text-amber-400 hover:text-amber-300 font-medium flex items-center gap-1 cursor-pointer self-start sm:self-auto"
                >
                  <span>Open Studio</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              {/* Phase dots bar */}
              <div className="flex items-center gap-2">
                {ex.phases.map((ph) => {
                  const isSeed = ph.provenance.type === 'PROGRAMMATIC_SEED';
                  const isGenuine = ph.provenance.type === 'GENERATED_AI_VERIFIED';
                  const isDuplicate = ph.qcReport.isDuplicate;

                  let dotColor = 'bg-zinc-800 border-zinc-700 text-zinc-500';
                  let statusLabel = 'Missing Photo';

                  if (isDuplicate) {
                    dotColor = 'bg-rose-950 border-rose-700 text-rose-300';
                    statusLabel = 'Duplicate Collision';
                  } else if (isSeed) {
                    dotColor = 'bg-amber-950 border-amber-600 text-amber-300';
                    statusLabel = 'Canvas Fixture';
                  } else if (isGenuine) {
                    dotColor = 'bg-emerald-950 border-emerald-600 text-emerald-300';
                    statusLabel = 'Genuine Photo';
                  }

                  return (
                    <button
                      key={ph.id}
                      onClick={() => onSelectExercise(ex.id, ph.phaseNumber)}
                      title={`Phase ${ph.phaseNumber}: ${ph.phaseName} (${statusLabel})`}
                      className={`flex-1 py-1.5 px-2 rounded border text-[11px] font-mono font-medium transition cursor-pointer hover:brightness-125 flex items-center justify-between ${dotColor}`}
                    >
                      <span>P{ph.phaseNumber}</span>
                      <span className="text-[9px] uppercase tracking-tighter truncate max-w-[80px] hidden md:inline">
                        {statusLabel}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
