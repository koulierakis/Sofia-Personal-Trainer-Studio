import React, { useState } from 'react';
import {
  Cpu,
  CheckCircle2,
  XCircle,
  RotateCw,
  Terminal,
  Settings2,
  HelpCircle,
  ExternalLink,
  Layers,
  Copy,
  Check,
} from 'lucide-react';

interface ComfyUiStudioProps {
  comfyStatus: {
    online: boolean;
    url?: string;
    serverUrl?: string;
    error?: string;
    message?: string;
    device?: string;
    vramTotalGb?: number;
    vramFreeGb?: number;
    vramOptimized: boolean;
    availableCheckpoints?: string[];
  } | null;
  onRefresh: () => void;
}

export const ComfyUiStudio: React.FC<ComfyUiStudioProps> = ({
  comfyStatus,
  onRefresh,
}) => {
  const [serverUrl, setServerUrl] = useState(
    comfyStatus?.serverUrl || comfyStatus?.url || 'http://127.0.0.1:8188'
  );
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [copiedCmd, setCopiedCmd] = useState(false);

  const launchCommand =
    'python main.py --listen 127.0.0.1 --port 8188 --lowvram';

  const handleCopyCmd = () => {
    navigator.clipboard.writeText(launchCommand);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);

    try {
      const resp = await fetch('/api/comfyui/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serverUrl }),
      });
      const data = await resp.json();
      setTestResult(data.result);
      onRefresh();
    } catch (err: any) {
      setTestResult({
        online: false,
        error: err.message,
      });
    } finally {
      setIsTesting(false);
    }
  };

  const isOnline = testResult ? testResult.online : (comfyStatus?.online ?? false);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Overview Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <Cpu className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                ComfyUI Local GPU Adapter (NVIDIA GeForce RTX 3060 12GB)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Provides dedicated local hardware generation for all 64 photorealistic exercise phases. Configured with medvram optimization for 12GB VRAM buffer safety.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div
              className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono font-medium ${
                isOnline
                  ? 'bg-emerald-950/60 text-emerald-400 border-emerald-800'
                  : 'bg-rose-950/40 text-rose-300 border-rose-900'
              }`}
            >
              {isOnline ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>COMFYUI ONLINE</span>
                </>
              ) : (
                <>
                  <XCircle className="w-4 h-4 text-rose-400" />
                  <span>COMFYUI OFFLINE (Local 127.0.0.1:8188)</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Server Config & Diagnostic Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Connection Config (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-4">
            <h3 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
              <Settings2 className="w-4 h-4 text-amber-400" />
              <span>Connection & Endpoint Configuration</span>
            </h3>

            <div className="space-y-2">
              <label className="text-xs font-medium text-zinc-400">
                ComfyUI REST & WebSocket Server URL
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={serverUrl}
                  onChange={(e) => setServerUrl(e.target.value)}
                  placeholder="http://127.0.0.1:8188"
                  className="bg-zinc-950 text-zinc-200 text-xs font-mono rounded-lg px-3 py-2.5 border border-zinc-700 focus:outline-none focus:border-amber-500 flex-1"
                />
                <button
                  onClick={handleTestConnection}
                  disabled={isTesting}
                  className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs rounded-lg transition disabled:opacity-50 cursor-pointer flex items-center gap-1.5"
                >
                  <RotateCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
                  <span>{isTesting ? 'Testing...' : 'Test Connection'}</span>
                </button>
              </div>
              <p className="text-[11px] text-zinc-500">
                Default: <code>http://127.0.0.1:8188</code>. If running inside a container or WSL, use your host IP.
              </p>
            </div>

            {/* Test Diagnostics Result Box */}
            {testResult && (
              <div
                className={`p-3.5 rounded-lg border text-xs space-y-1.5 ${
                  testResult.online
                    ? 'bg-emerald-950/30 border-emerald-800/80 text-emerald-300'
                    : 'bg-zinc-950 border-zinc-800 text-zinc-400'
                }`}
              >
                <div className="font-semibold text-zinc-200">Diagnostics Output:</div>
                <div>Status: {testResult.online ? '✔ Connected' : '✖ Unreachable'}</div>
                {testResult.device && <div>Device: {testResult.device}</div>}
                {testResult.vramTotalGb && (
                  <div>
                    VRAM: {testResult.vramFreeGb}GB free / {testResult.vramTotalGb}GB total
                  </div>
                )}
                {testResult.error && (
                  <div className="text-rose-300">Notice: {testResult.error}</div>
                )}
              </div>
            )}
          </div>

          {/* Baseline RTX 3060 12GB Workflow Specifications */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-3">
            <h3 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>RTX 3060 12GB Baseline Generation Settings</span>
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500 block">VRAM Profile</span>
                <span className="text-zinc-200 font-mono font-medium">--medvram (Safe 12GB)</span>
              </div>
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500 block">Resolution</span>
                <span className="text-zinc-200 font-mono font-medium">1024 x 1024 px</span>
              </div>
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500 block">Inference Steps</span>
                <span className="text-zinc-200 font-mono font-medium">28 steps</span>
              </div>
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
                <span className="text-zinc-500 block">CFG Guidance</span>
                <span className="text-zinc-200 font-mono font-medium">7.0</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Step-by-Step Windows Launch Instructions (6 cols) */}
        <div className="lg:col-span-6 space-y-6">
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-4">
            <h3 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
              <Terminal className="w-4 h-4 text-amber-400" />
              <span>Step-by-Step Windows GPU Launch Guide</span>
            </h3>

            <div className="space-y-3 text-xs text-zinc-300">
              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-full bg-zinc-800 text-amber-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  1
                </span>
                <div>
                  <strong className="text-zinc-200">Start ComfyUI on your Windows GPU Host</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Open Windows Terminal / Command Prompt in your ComfyUI directory.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-full bg-zinc-800 text-amber-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  2
                </span>
                <div className="space-y-1.5 w-full">
                  <strong className="text-zinc-200">Execute with CORS & Network Binding:</strong>
                  <div className="flex items-center gap-2 p-2 rounded bg-zinc-950 border border-zinc-800 font-mono text-[11px] text-amber-300">
                    <span className="truncate flex-1">{launchCommand}</span>
                    <button
                      onClick={handleCopyCmd}
                      className="p-1 hover:text-white transition cursor-pointer"
                      title="Copy command"
                    >
                      {copiedCmd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-zinc-500">
                    <code>--enable-cors-header *</code> allows KinesioForge to post prompts and retrieve image binaries without browser security blocks.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-full bg-zinc-800 text-amber-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  3
                </span>
                <div>
                  <strong className="text-zinc-200">Ensure Checkpoint Is Installed</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Place an SDXL or SD1.5 photorealistic checkpoint (e.g., <code>v1-5-pruned-emaonly.safetensors</code> or <code>sd_xl_base_1.0.safetensors</code>) in <code>ComfyUI/models/checkpoints/</code>.
                  </p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="w-5 h-5 rounded-full bg-zinc-800 text-amber-400 font-bold flex items-center justify-center shrink-0 text-xs">
                  4
                </span>
                <div>
                  <strong className="text-zinc-200">Click &quot;Test Connection&quot; Above</strong>
                  <p className="text-zinc-400 mt-0.5">
                    Once online, switch to the 64-Phase Movement Studio and generate all 64 movement phases with zero quota limits!
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
