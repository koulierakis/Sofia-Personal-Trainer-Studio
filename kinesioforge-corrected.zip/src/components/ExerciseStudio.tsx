import React, { useState } from 'react';
import {
  Camera,
  Cpu,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  RotateCw,
  UserCheck,
  FileText,
  Dumbbell,
  AlertCircle,
} from 'lucide-react';
import { ExerciseRecord, PhaseRecord } from '../types/pipeline';

interface ExerciseStudioProps {
  exercises: ExerciseRecord[];
  selectedExerciseId: string;
  selectedPhaseNumber: number;
  onSelectExercise: (id: string, phaseNum?: number) => void;
  onRefreshData: () => void;
}

export const ExerciseStudio: React.FC<ExerciseStudioProps> = ({
  exercises,
  selectedExerciseId,
  selectedPhaseNumber,
  onSelectExercise,
  onRefreshData,
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isRunningQc, setIsRunningQc] = useState(false);
  const [generationError, setGenerationError] = useState<string | null>(null);
  const [copiedHash, setCopiedHash] = useState(false);
  const [humanNotes, setHumanNotes] = useState('');
  const [humanStatus, setHumanStatus] = useState<
    'approved' | 'rejected' | 'needs_regeneration'
  >('needs_regeneration');
  const [isSavingReview, setIsSavingReview] = useState(false);

  const [reviewMsg, setReviewMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const currentExercise =
    exercises.find((e) => e.id === selectedExerciseId) || exercises[0];

  const currentPhase =
    currentExercise?.phases.find((p) => p.phaseNumber === selectedPhaseNumber) ||
    currentExercise?.phases[0];

  const handleCopyHash = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(true);
    setTimeout(() => setCopiedHash(false), 2000);
  };

  const handleGenerate = async (provider: 'gemini' | 'comfyui') => {
    if (!currentExercise || !currentPhase) return;
    setIsGenerating(true);
    setGenerationError(null);
    setReviewMsg(null);

    try {
      const resp = await fetch(
        `/api/exercises/${currentExercise.id}/phases/${currentPhase.phaseNumber}/generate`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ provider }),
        }
      );

      const data = await resp.json();
      if (!resp.ok || !data.success) {
        throw new Error(data.error || 'Generation failed');
      }

      onRefreshData();
    } catch (err: any) {
      setGenerationError(err.message || 'Generation failed');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleRunQc = async () => {
    if (!currentExercise || !currentPhase) return;
    setIsRunningQc(true);
    setReviewMsg(null);

    try {
      const resp = await fetch(
        `/api/exercises/${currentExercise.id}/phases/${currentPhase.phaseNumber}/qc`,
        {
          method: 'POST',
        }
      );
      const data = await resp.json();
      if (!resp.ok || !data.success) {
        throw new Error(data.error || 'QC failed');
      }

      onRefreshData();
      setReviewMsg({ type: 'success', text: 'Ο εμβιομηχανικός έλεγχος ποιότητας (QC) ολοκληρώθηκε επιτυχώς!' });
    } catch (err: any) {
      setReviewMsg({ type: 'error', text: `Σφάλμα ελέγχου QC: ${err.message}` });
    } finally {
      setIsRunningQc(false);
    }
  };

  const handleSaveReview = async () => {
    if (!currentExercise || !currentPhase) return;
    setIsSavingReview(true);
    setReviewMsg(null);

    try {
      const resp = await fetch(
        `/api/exercises/${currentExercise.id}/phases/${currentPhase.phaseNumber}/review`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            status: humanStatus,
            notes: humanNotes,
            reviewer: 'Sofia Lead Biomechanist',
          }),
        }
      );
      if (!resp.ok) {
        const d = await resp.json().catch(() => ({}));
        throw new Error(d.error || 'Failed to save review');
      }
      onRefreshData();
      setReviewMsg({ type: 'success', text: 'Η αξιολόγηση αποθηκεύτηκε επιτυχώς!' });
    } catch (err: any) {
      setReviewMsg({ type: 'error', text: `Σφάλμα αποθήκευσης αξιολόγησης: ${err.message}` });
    } finally {
      setIsSavingReview(false);
    }
  };

  if (!currentExercise || !currentPhase) return null;

  const isSeed = currentPhase.provenance.type === 'PROGRAMMATIC_SEED';
  const isDuplicate = currentPhase.qcReport.isDuplicate;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Exercise Selector Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 p-4 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="space-y-1">
          <label className="text-xs font-medium text-zinc-400 uppercase tracking-wider">
            Select Curriculum Exercise (11 Total)
          </label>
          <div className="flex items-center gap-2">
            <select
              value={currentExercise.id}
              onChange={(e) => onSelectExercise(e.target.value, 1)}
              className="bg-zinc-950 text-zinc-200 text-sm font-medium rounded-lg px-3 py-2 border border-zinc-700 focus:outline-none focus:border-amber-500 w-full sm:w-[450px] cursor-pointer"
            >
              {exercises.map((ex, i) => (
                <option key={ex.id} value={ex.id}>
                  #{String(i + 1).padStart(2, '0')}: {ex.english_name} (
                  {ex.totalPhases} phases)
                </option>
              ))}
            </select>
            <span className="text-xs px-2 py-1 rounded bg-zinc-800 text-zinc-300 font-mono border border-zinc-700 shrink-0">
              {currentExercise.epipedo_dyskalias}
            </span>
          </div>
        </div>

        {/* Phase Navigation Tabs */}
        <div>
          <label className="text-xs font-medium text-zinc-400 uppercase tracking-wider block mb-1">
            Movement Phases ({currentExercise.totalPhases}{' '}
            {currentExercise.totalPhases === 5
              ? 'Phases • Five-Phase Movement'
              : 'Phases'}
            )
          </label>
          <div className="flex items-center gap-1.5">
            {currentExercise.phases.map((ph) => {
              const isActive = ph.phaseNumber === currentPhase.phaseNumber;
              const hasFile = !!ph.outputPath;
              const isPhSeed = ph.provenance.type === 'PROGRAMMATIC_SEED';
              const isPhDup = ph.qcReport.isDuplicate;

              let btnStyle = 'bg-zinc-950 text-zinc-400 border-zinc-800';
              if (isActive) {
                btnStyle = 'bg-amber-500 text-zinc-950 font-bold border-amber-400';
              } else if (isPhDup) {
                btnStyle = 'bg-rose-950/60 text-rose-300 border-rose-800';
              } else if (isPhSeed) {
                btnStyle = 'bg-amber-950/50 text-amber-300 border-amber-800';
              } else if (hasFile) {
                btnStyle = 'bg-emerald-950/50 text-emerald-300 border-emerald-800';
              }

              return (
                <button
                  key={ph.id}
                  onClick={() => onSelectExercise(currentExercise.id, ph.phaseNumber)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-mono transition cursor-pointer ${btnStyle}`}
                >
                  Phase {ph.phaseNumber}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Main Studio Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual Asset & Provenance (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Image Canvas Box */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
                  <span>Phase {currentPhase.phaseNumber}: {currentPhase.phaseName}</span>
                </h3>
                <p className="text-xs text-zinc-400 font-mono mt-0.5">
                  ID: {currentPhase.id}
                </p>
              </div>

              {/* Provenance Badge */}
              {isSeed ? (
                <span className="px-2.5 py-1 rounded-md bg-amber-950/80 text-amber-300 text-xs font-mono font-medium border border-amber-700/80 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  <span>PROGRAMMATIC_SEED (Fixture)</span>
                </span>
              ) : currentPhase.provenance.type === 'GENERATED_AI_VERIFIED' ? (
                <span className="px-2.5 py-1 rounded-md bg-emerald-950/80 text-emerald-300 text-xs font-mono font-medium border border-emerald-700 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>GENERATED_AI_VERIFIED</span>
                </span>
              ) : (
                <span className="px-2.5 py-1 rounded-md bg-zinc-800 text-zinc-400 text-xs font-mono font-medium border border-zinc-700 flex items-center gap-1.5">
                  <XCircle className="w-3.5 h-3.5 text-zinc-500" />
                  <span>PLACEHOLDER (No binary)</span>
                </span>
              )}
            </div>

            {/* Duplicate Collision Warning */}
            {isDuplicate && (
              <div className="p-3.5 rounded-lg bg-rose-950/40 border border-rose-800 text-xs text-rose-300 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <strong className="text-rose-200">
                    CRITICAL: Duplicate Frame Collision Detected
                  </strong>
                  <p>
                    This phase contains the identical binary data as{' '}
                    <span className="font-mono text-rose-100">
                      {currentPhase.qcReport.duplicateOfPhaseId}
                    </span>
                    . In kinetic training, Setup and Reset are separate biomechanical states. Reusing identical frames is invalid for production.
                  </p>
                </div>
              </div>
            )}

            {/* Image Preview Box */}
            <div className="relative aspect-square w-full rounded-xl bg-zinc-950 border border-zinc-800 overflow-hidden flex items-center justify-center group">
              {currentPhase.outputPath ? (
                <>
                  <img
                    src={`/${currentPhase.outputPath}`}
                    alt={`Phase ${currentPhase.phaseNumber}`}
                    className="w-full h-full object-contain"
                  />
                  {/* Overlay Watermark for Programmatic Seed */}
                  {isSeed && (
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-zinc-950 via-zinc-950/80 to-transparent p-4 text-center">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 border border-amber-500/40 text-amber-300 text-xs font-mono">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>DEVELOPMENT FIXTURE — Schematic Canvas Silhouette (~23KB)</span>
                      </div>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center p-8 space-y-3">
                  <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-600">
                    <Camera className="w-8 h-8" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-zinc-300">
                      No Photorealistic Binary Generated
                    </p>
                    <p className="text-xs text-zinc-500 max-w-sm">
                      This movement phase is currently in PLACEHOLDER state. Trigger real generation below using Gemini or ComfyUI.
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Binary Metadata & SHA-256 */}
            {currentPhase.imageChecksum && (
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-xs space-y-2">
                <div className="flex items-center justify-between text-zinc-400">
                  <span>SHA-256 Hash:</span>
                  <button
                    onClick={() => handleCopyHash(currentPhase.imageChecksum!)}
                    className="flex items-center gap-1 text-zinc-400 hover:text-amber-400 cursor-pointer"
                  >
                    {copiedHash ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
                  </button>
                </div>
                <div className="font-mono text-zinc-300 text-[11px] break-all bg-zinc-900 p-2 rounded border border-zinc-800">
                  {currentPhase.imageChecksum}
                </div>
                <div className="flex items-center justify-between text-zinc-400 text-[11px] pt-1">
                  <span>
                    Size: <strong>{currentPhase.fileSizeBytes?.toLocaleString()} bytes</strong>
                  </span>
                  <span>
                    Provider: <strong>{currentPhase.provenance.provider}</strong>
                  </span>
                  <span>
                    Device: <strong>{currentPhase.provenance.device || 'N/A'}</strong>
                  </span>
                </div>
              </div>
            )}

            {/* Generation Controls */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span className="font-medium uppercase tracking-wider">Execute Real Generation</span>
                <span className="text-[11px] text-zinc-500">Zero fake fallbacks enforced</span>
              </div>

              {generationError && (
                <div className="p-3 rounded-lg bg-rose-950/50 border border-rose-800 text-xs text-rose-300">
                  <strong>Generation Error:</strong> {generationError}
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <button
                  onClick={() => handleGenerate('gemini')}
                  disabled={isGenerating}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-sky-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white font-medium text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isGenerating ? 'Calling Provider...' : 'Generate with Gemini Image API'}
                  </span>
                </button>

                <button
                  onClick={() => handleGenerate('comfyui')}
                  disabled={isGenerating}
                  className="flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-zinc-950 font-bold text-xs shadow-md transition disabled:opacity-50 cursor-pointer"
                >
                  <Cpu className="w-4 h-4" />
                  <span>
                    {isGenerating ? 'Calling ComfyUI...' : 'Generate with ComfyUI (RTX 3060)'}
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Prompts, Biomechanical QC & Human Review (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Prompt Inspection Box */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-3">
            <h4 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" />
              <span>Commercial Production Prompt</span>
            </h4>
            <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 text-xs text-zinc-300 leading-relaxed font-sans max-h-48 overflow-y-auto">
              {currentPhase.fullPrompt}
            </div>
            <div className="p-3 rounded-lg bg-zinc-950/60 border border-zinc-800/80 text-[11px] text-zinc-400 space-y-1">
              <div className="text-zinc-300 font-medium">Kinematic Directive (Greek):</div>
              <p>
                {currentExercise.odigies_ektelesis[currentPhase.phaseKey] ||
                  'Ακολουθήστε αυστηρά την ανατομική ευθυγράμμιση και τη σταθεροποίηση πυρήνα.'}
              </p>
            </div>
          </div>

          {/* Biomechanical Quality Control Card */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Dumbbell className="w-4 h-4 text-amber-400" />
                <h4 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider">
                  Biomechanical QC Audit
                </h4>
              </div>
              <button
                onClick={handleRunQc}
                disabled={isRunningQc || !currentPhase.outputPath}
                className="text-xs px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition disabled:opacity-40 cursor-pointer flex items-center gap-1"
              >
                <RotateCw className={`w-3 h-3 ${isRunningQc ? 'animate-spin' : ''}`} />
                <span>{isRunningQc ? 'Inspecting...' : 'Inspect Binary'}</span>
              </button>
            </div>

            {/* Score Indicators */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-center">
                <div className="text-xs text-zinc-400">Anatomical Plausibility</div>
                <div className="text-2xl font-bold font-mono mt-1 text-zinc-100">
                  {currentPhase.qcReport.anatomicalScore}/100
                </div>
              </div>
              <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800 text-center">
                <div className="text-xs text-zinc-400">Biomechanical Score</div>
                <div className="text-2xl font-bold font-mono mt-1 text-zinc-100">
                  {currentPhase.qcReport.biomechanicalScore}/100
                </div>
              </div>
            </div>

            {/* QC Findings List */}
            <div className="space-y-2 text-xs">
              <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 space-y-1">
                <span className="text-zinc-400 font-medium">Kinetic Chain & Joint Alignment:</span>
                <p className="text-zinc-300">{currentPhase.qcReport.jointAlignment}</p>
              </div>

              <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 space-y-1">
                <span className="text-zinc-400 font-medium">Equipment Grip & Placement:</span>
                <p className="text-zinc-300">{currentPhase.qcReport.equipmentGrip}</p>
              </div>

              {currentPhase.qcReport.detectedIssues.length > 0 && (
                <div className="p-2.5 rounded bg-rose-950/30 border border-rose-900/50 space-y-1">
                  <span className="text-rose-300 font-medium">Detected Flaws / Blockers:</span>
                  <ul className="list-disc list-inside text-rose-300/90 space-y-0.5">
                    {currentPhase.qcReport.detectedIssues.map((issue, idx) => (
                      <li key={idx}>{issue}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="p-2.5 rounded bg-zinc-950 border border-zinc-800 text-xs">
              <span className="text-zinc-400">Verdict Summary: </span>
              <span className="text-amber-300 font-medium">
                {currentPhase.qcReport.verdictSummary}
              </span>
            </div>
          </div>

          {/* Human Review Approval Panel */}
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-5 space-y-4">
            <div className="flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-amber-400" />
              <h4 className="text-xs font-semibold text-zinc-200 uppercase tracking-wider">
                Human-in-the-Loop Review
              </h4>
            </div>

            <div className="space-y-3">
              {reviewMsg && (
                <div
                  className={`p-2.5 rounded-lg border text-xs flex items-center justify-between ${
                    reviewMsg.type === 'success'
                      ? 'bg-emerald-950/60 border-emerald-800 text-emerald-300'
                      : 'bg-rose-950/60 border-rose-800 text-rose-300'
                  }`}
                >
                  <span>{reviewMsg.text}</span>
                  <button
                    onClick={() => setReviewMsg(null)}
                    className="text-xs font-bold opacity-70 hover:opacity-100 ml-2 cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              )}

              <div className="flex items-center gap-2">
                <select
                  value={humanStatus}
                  onChange={(e) => setHumanStatus(e.target.value as any)}
                  className="bg-zinc-950 text-zinc-200 text-xs rounded-lg px-3 py-2 border border-zinc-700 flex-1 cursor-pointer"
                >
                  <option value="needs_regeneration">Needs Regeneration (Fixture / Flaw)</option>
                  <option value="rejected">Rejected (Anatomical Failure)</option>
                  <option value="approved">Approved (Commercial Quality)</option>
                </select>

                <button
                  onClick={handleSaveReview}
                  disabled={isSavingReview}
                  className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-amber-400 font-medium text-xs rounded-lg border border-zinc-700 transition cursor-pointer"
                >
                  {isSavingReview ? 'Saving...' : 'Save Review'}
                </button>
              </div>

              <textarea
                value={humanNotes}
                onChange={(e) => setHumanNotes(e.target.value)}
                placeholder="Optional biomechanical review notes..."
                rows={2}
                className="w-full bg-zinc-950 text-zinc-300 text-xs rounded-lg p-2.5 border border-zinc-800 focus:outline-none focus:border-amber-500"
              />

              {currentPhase.humanReview.reviewedAt && (
                <div className="text-[11px] text-zinc-500">
                  Last reviewed on {new Date(currentPhase.humanReview.reviewedAt).toLocaleString()} by{' '}
                  {currentPhase.humanReview.reviewer || 'Inspector'}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
