import React, { useState } from 'react';
import { Search, Filter, Dumbbell, ChevronDown, ChevronUp, ArrowRight, Layers, CheckCircle2 } from 'lucide-react';
import { ExerciseRecord } from '../types/pipeline';

interface ExerciseDatabaseViewProps {
  exercises: ExerciseRecord[];
  onOpenStudio: (exerciseId: string, phaseNumber?: number) => void;
}

export const ExerciseDatabaseView: React.FC<ExerciseDatabaseViewProps> = ({
  exercises,
  onOpenStudio,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState<string>('all');
  const [expandedExerciseId, setExpandedExerciseId] = useState<string | null>(null);

  const filteredExercises = exercises.filter((ex) => {
    const matchesSearch =
      ex.english_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ex.onomasia_askisis.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ex.id.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesDiff =
      selectedDifficulty === 'all' ||
      ex.epipedo_dyskalias.toLowerCase() === selectedDifficulty.toLowerCase();

    return matchesSearch && matchesDiff;
  });

  const toggleExpand = (id: string) => {
    setExpandedExerciseId((prev) => (prev === id ? null : id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Header & Filter Controls */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-5 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Dumbbell className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-zinc-100">
              Βάση Δεδομένων Κινησιολογίας & Ασκήσεων (Exercise Curriculum)
            </h2>
          </div>
          <p className="text-xs text-zinc-400">
            11 αναλυτικά πρωτόκολλα αθλητικής κινητικής αλυσίδας με 64 φάσεις, εμβιομηχανική ανάλυση και οδηγίες στα Ελληνικά και Αγγλικά.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Αναζήτηση άσκησης..."
              className="bg-zinc-950 text-zinc-200 text-xs rounded-lg pl-9 pr-3 py-2 border border-zinc-700 focus:outline-none focus:border-amber-500 w-48 sm:w-64"
            />
          </div>

          {/* Difficulty Filter */}
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="bg-zinc-950 text-zinc-300 text-xs rounded-lg px-3 py-2 border border-zinc-700 focus:outline-none focus:border-amber-500 cursor-pointer"
          >
            <option value="all">Όλα τα Επίπεδα</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
            <option value="elite">Elite</option>
          </select>
        </div>
      </div>

      {/* Exercises List */}
      <div className="space-y-4">
        {filteredExercises.map((ex, index) => {
          const isExpanded = expandedExerciseId === ex.id;
          const completedCount = ex.phases.filter(
            (p) => p.provenance.type === 'GENERATED_AI_VERIFIED'
          ).length;

          return (
            <div
              key={ex.id}
              className="rounded-xl border border-zinc-800 bg-zinc-900/60 overflow-hidden transition hover:border-zinc-700"
            >
              {/* Exercise Card Summary */}
              <div
                onClick={() => toggleExpand(ex.id)}
                className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer select-none"
              >
                <div className="flex items-start sm:items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-zinc-800 text-amber-400 font-mono font-bold text-xs flex items-center justify-center shrink-0 border border-zinc-700">
                    #{String(index + 1).padStart(2, '0')}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-zinc-100">
                        {ex.english_name}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold bg-zinc-800 text-amber-400 border border-zinc-700">
                        {ex.epipedo_dyskalias}
                      </span>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-mono bg-zinc-800 text-zinc-400 border border-zinc-700">
                        {ex.totalPhases === 5 ? '5 Φάσεις' : '6 Φάσεις'}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-400 mt-1 line-clamp-1">
                      {ex.onomasia_askisis}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 self-end sm:self-auto">
                  <div className="text-right text-xs">
                    <span className="text-zinc-500 block text-[10px] uppercase">Πρόοδος Φωτογραφίας</span>
                    <span className="font-mono text-zinc-300 font-bold">
                      {completedCount} / {ex.totalPhases} Έτοιμες
                    </span>
                  </div>

                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onOpenStudio(ex.id);
                    }}
                    className="px-3 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 font-medium text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <span>Studio</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>

                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-zinc-500" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-zinc-500" />
                  )}
                </div>
              </div>

              {/* Expanded Kinematic Details */}
              {isExpanded && (
                <div className="p-5 border-t border-zinc-800/80 bg-zinc-950/70 space-y-4 text-xs">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Objectives & Mechanics */}
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 space-y-1">
                        <strong className="text-amber-400 block">Στόχος Κινησιολογίας:</strong>
                        <p className="text-zinc-300 leading-relaxed">{ex.stoxos}</p>
                      </div>

                      <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 space-y-1">
                        <strong className="text-zinc-300 block">Εμβιομηχανική Ανάλυση:</strong>
                        <p className="text-zinc-400 leading-relaxed">{ex.mixaniki_analysi}</p>
                      </div>
                    </div>

                    {/* Muscles & Equipment */}
                    <div className="space-y-3">
                      <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 space-y-1">
                        <strong className="text-zinc-300 block">Κύριες Μυϊκές Ομάδες:</strong>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {ex.myikes_omades.kyries.map((m, mIdx) => (
                            <span
                              key={mIdx}
                              className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 text-[11px]"
                            >
                              {m}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 space-y-1">
                        <strong className="text-zinc-300 block">Απαιτούμενος Εξοπλισμός:</strong>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {ex.apaitoumenos_exoplismos.map((eq, eqIdx) => (
                            <span
                              key={eqIdx}
                              className="px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 text-[11px]"
                            >
                              {eq}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Movement Phases Stepper */}
                  <div className="space-y-2 pt-2">
                    <strong className="text-zinc-200 block text-xs uppercase tracking-wider">
                      Φάσεις Κίνησης ({ex.totalPhases})
                    </strong>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                      {ex.phases.map((ph) => (
                        <div
                          key={ph.id}
                          onClick={() => onOpenStudio(ex.id, ph.phaseNumber)}
                          className="p-3 rounded-lg bg-zinc-900 border border-zinc-800 hover:border-amber-500/50 transition cursor-pointer flex flex-col justify-between"
                        >
                          <div>
                            <div className="flex items-center justify-between text-zinc-400 mb-1">
                              <span className="font-mono text-amber-400 font-bold text-xs">
                                Φάση {ph.phaseNumber}
                              </span>
                              <span className="text-[10px] uppercase font-mono">
                                {ph.provenance.type === 'PROGRAMMATIC_SEED'
                                  ? 'Fixture'
                                  : ph.provenance.type === 'GENERATED_AI_VERIFIED'
                                  ? 'Έτοιμη'
                                  : 'Missing'}
                              </span>
                            </div>
                            <span className="text-zinc-200 font-medium block">
                              {ph.phaseName}
                            </span>
                          </div>
                          <span className="text-[11px] text-zinc-500 mt-2 line-clamp-1">
                            {ex.odigies_ektelesis[ph.phaseKey] || ph.fullPrompt}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
