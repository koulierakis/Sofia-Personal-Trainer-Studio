import React, { useState, useEffect } from 'react';
import { User, Sparkles, Check, Plus, ShieldCheck, Camera } from 'lucide-react';
import { AthleteProfile, DEFAULT_GREEK_ATHLETE } from '../types/pipeline';

export const AthleteProfilesView: React.FC = () => {
  const [profiles, setProfiles] = useState<AthleteProfile[]>([DEFAULT_GREEK_ATHLETE]);
  const [selectedProfileId, setSelectedProfileId] = useState<string>(DEFAULT_GREEK_ATHLETE.id);
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState<Partial<AthleteProfile>>(DEFAULT_GREEK_ATHLETE);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fetchProfiles = async () => {
    try {
      const resp = await fetch('/api/athletes');
      if (resp.ok) {
        const data = await resp.json();
        setProfiles(data.profiles || [DEFAULT_GREEK_ATHLETE]);
      }
    } catch (err) {
      console.error('Error fetching athlete profiles:', err);
    }
  };

  useEffect(() => {
    fetchProfiles();
  }, []);

  const activeProfile = profiles.find((p) => p.id === selectedProfileId) || profiles[0];

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setStatusMessage(null);
    try {
      const resp = await fetch('/api/athletes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (resp.ok) {
        setStatusMessage('Το προφίλ αθλητή αποθηκεύτηκε επιτυχώς!');
        setIsEditing(false);
        fetchProfiles();
        setTimeout(() => setStatusMessage(null), 3000);
      } else {
        const data = await resp.json().catch(() => ({}));
        throw new Error(data.error || 'Σφάλμα κατά την αποθήκευση');
      }
    } catch (err: any) {
      setErrorMessage(`Σφάλμα: ${err.message}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-8">
      {/* Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Προφίλ Αθλητών & Οπτική Συνέπεια Ταυτότητας (Athlete Profiles)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Διασφαλίζει απόλυτη συνέπεια φυσιογνωμίας, μυϊκής κατανομής, μαύρης αθλητικής ενδυμασίας και φωτισμού σε όλες τις 64 φάσεις της σειράς ασκήσεων.
            </p>
          </div>

          <button
            onClick={() => {
              setIsEditing(true);
              setFormData({
                name: 'Νέος Αθλητής',
                age: 'Young adult under 30',
                ethnicity: 'Mediterranean / Greek features',
                build: 'Athletic chiseled physique',
                hair: 'Short dark hair',
                attire: 'Fitted black t-shirt and leggings',
                environment: 'Minimalist private gym studio',
                lighting: 'Studio rim directional warm lighting',
                referenceNotes: 'Custom athlete definition',
                isDefault: false,
              });
            }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold text-xs transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Προσθήκη Νέου Προφίλ</span>
          </button>
        </div>
      </div>

      {statusMessage && (
        <div className="p-3.5 rounded-lg bg-emerald-950/40 border border-emerald-800 text-xs text-emerald-300 font-medium">
          {statusMessage}
        </div>
      )}

      {errorMessage && (
        <div className="p-3.5 rounded-lg bg-rose-950/40 border border-rose-800 text-xs text-rose-300 font-medium">
          {errorMessage}
        </div>
      )}

      {/* Main Grid: Profiles List & Active Detail */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Profiles List (4 cols) */}
        <div className="lg:col-span-4 space-y-3">
          <h3 className="text-xs font-semibold text-zinc-400 uppercase tracking-wider mb-2">
            Διαθέσιμα Πρότυπα Αθλητών
          </h3>
          {profiles.map((p) => (
            <div
              key={p.id}
              onClick={() => {
                setSelectedProfileId(p.id);
                setIsEditing(false);
                setFormData(p);
              }}
              className={`p-4 rounded-xl border transition cursor-pointer ${
                p.id === selectedProfileId
                  ? 'bg-zinc-900 border-amber-500 text-zinc-100 shadow-md'
                  : 'bg-zinc-900/50 border-zinc-800 text-zinc-400 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-xs">{p.name}</span>
                {p.isDefault && (
                  <span className="text-[10px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-400 border border-amber-500/20 font-mono">
                    ΠΡΟΕΠΙΛΟΓΗ
                  </span>
                )}
              </div>
              <p className="text-[11px] text-zinc-500 line-clamp-1">{p.build}</p>
            </div>
          ))}
        </div>

        {/* Right Column: Detailed View / Editor (8 cols) */}
        <div className="lg:col-span-8">
          <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div>
                <h3 className="text-base font-bold text-zinc-100 flex items-center gap-2">
                  <span>{activeProfile?.name}</span>
                  {activeProfile?.isDefault && (
                    <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  )}
                </h3>
                <p className="text-xs text-zinc-400 mt-0.5">
                  ID: <code className="font-mono text-zinc-300">{activeProfile?.id}</code>
                </p>
              </div>

              {!isEditing && (
                <button
                  onClick={() => {
                    setIsEditing(true);
                    setFormData(activeProfile);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs border border-zinc-700 transition cursor-pointer"
                >
                  Επεξεργασία Προδιαγραφών
                </button>
              )}
            </div>

            {isEditing ? (
              <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-zinc-400">Όνομα Προφίλ</label>
                    <input
                      type="text"
                      value={formData.name || ''}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full bg-zinc-950 text-zinc-200 p-2.5 rounded-lg border border-zinc-700"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-zinc-400">Ηλικία & Κατηγορία</label>
                    <input
                      type="text"
                      value={formData.age || ''}
                      onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                      className="w-full bg-zinc-950 text-zinc-200 p-2.5 rounded-lg border border-zinc-700"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-zinc-400">Σωματότυπος & Μυϊκός Ορισμός</label>
                  <input
                    type="text"
                    value={formData.build || ''}
                    onChange={(e) => setFormData({ ...formData, build: e.target.value })}
                    className="w-full bg-zinc-950 text-zinc-200 p-2.5 rounded-lg border border-zinc-700"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-zinc-400">Ενδυμασία (Attire)</label>
                  <input
                    type="text"
                    value={formData.attire || ''}
                    onChange={(e) => setFormData({ ...formData, attire: e.target.value })}
                    className="w-full bg-zinc-950 text-zinc-200 p-2.5 rounded-lg border border-zinc-700"
                    required
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-zinc-400">Περιβάλλον & Studio Lighting</label>
                  <textarea
                    rows={3}
                    value={formData.environment || ''}
                    onChange={(e) => setFormData({ ...formData, environment: e.target.value })}
                    className="w-full bg-zinc-950 text-zinc-200 p-2.5 rounded-lg border border-zinc-700"
                    required
                  />
                </div>

                <div className="flex items-center gap-3 pt-3">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-bold rounded-lg transition cursor-pointer"
                  >
                    Αποθήκευση
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsEditing(false)}
                    className="px-4 py-2 bg-zinc-800 text-zinc-300 rounded-lg border border-zinc-700 hover:bg-zinc-700 transition cursor-pointer"
                  >
                    Ακύρωση
                  </button>
                </div>
              </form>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1">
                  <span className="text-zinc-500 font-mono block">Ηλικία & Χαρακτηριστικά:</span>
                  <span className="text-zinc-200 font-medium">{activeProfile?.age}</span>
                </div>

                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1">
                  <span className="text-zinc-500 font-mono block">Εθνοτικά Χαρακτηριστικά:</span>
                  <span className="text-zinc-200 font-medium">{activeProfile?.ethnicity}</span>
                </div>

                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1">
                  <span className="text-zinc-500 font-mono block">Σωματική Διάπλαση:</span>
                  <span className="text-zinc-200 font-medium">{activeProfile?.build}</span>
                </div>

                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1">
                  <span className="text-zinc-500 font-mono block">Μαλλιά & Όψη:</span>
                  <span className="text-zinc-200 font-medium">{activeProfile?.hair}</span>
                </div>

                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1 md:col-span-2">
                  <span className="text-zinc-500 font-mono block">Ενδυμασία & Εξοπλισμός Προπόνησης:</span>
                  <span className="text-zinc-200 font-medium">{activeProfile?.attire}</span>
                </div>

                <div className="p-3.5 rounded-lg bg-zinc-950 border border-zinc-800 space-y-1 md:col-span-2">
                  <span className="text-zinc-500 font-mono block">Φωτισμός & Minimal Studio:</span>
                  <span className="text-zinc-300">{activeProfile?.environment}</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
