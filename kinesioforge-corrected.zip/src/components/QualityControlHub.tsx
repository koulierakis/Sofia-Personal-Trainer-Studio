import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  RotateCw,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Eye,
  Filter,
} from 'lucide-react';
import { ExerciseRecord, PhaseRecord } from '../types/pipeline';

interface QualityControlHubProps {
  exercises: ExerciseRecord[];
  onOpenPhase: (exerciseId: string, phaseNumber: number) => void;
  onRefresh: () => void;
}

export const QualityControlHub: React.FC<QualityControlHubProps> = ({
  exercises,
  onOpenPhase,
  onRefresh,
}) => {
  const [qcFilter, setQcFilter] = useState<'all' | 'failed' | 'warning' | 'passed' | 'uninspected'>('all');
  const [isAuditingAll, setIsAuditingAll] = useState(false);

  const allPhases: Array<{ exercise: ExerciseRecord; phase: PhaseRecord }> = [];
  exercises.forEach((ex) => {
    ex.phases.forEach((ph) => {
      allPhases.push({ exercise: ex, phase: ph });
    });
  });

  const filtered = allPhases.filter(({ phase }) => {
    if (qcFilter === 'all') return true;
    return phase.qcReport.overallStatus === qcFilter;
  });

  const failedCount = allPhases.filter((p) => p.phase.qcReport.overallStatus === 'failed').length;
  const passedCount = allPhases.filter((p) => p.phase.qcReport.overallStatus === 'passed').length;
  const uninspectedCount = allPhases.filter((p) => p.phase.qcReport.overallStatus === 'uninspected').length;
  const duplicateCount = allPhases.filter((p) => p.phase.qcReport.isDuplicate).length;

  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleAuditSingle = async (exerciseId: string, phaseNum: number) => {
    setErrorMsg(null);
    try {
      const res = await fetch(`/api/exercises/${exerciseId}/phases/${phaseNum}/qc`, {
        method: 'POST',
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Σφάλμα ελέγχου QC.');
      }
      onRefresh();
    } catch (err: any) {
      setErrorMsg(`Σφάλμα ελέγχου: ${err.message}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {errorMsg && (
        <div className="p-3.5 rounded-lg bg-rose-950/80 border border-rose-800 text-rose-300 text-xs flex items-center justify-between">
          <span>{errorMsg}</span>
          <button
            onClick={() => setErrorMsg(null)}
            className="text-rose-400 hover:text-rose-200 font-bold ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
      {/* Overview Banner */}
      <div className="p-6 rounded-xl bg-zinc-900 border border-zinc-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-500" />
              <h2 className="text-base font-bold text-zinc-100">
                Κέντρο Εμβιομηχανικού Ελέγχου Ποιότητας (Quality Control Hub)
              </h2>
            </div>
            <p className="text-xs text-zinc-400 max-w-2xl">
              Αυστηρός έλεγχος ανατομικής ευθυγράμμισης, ορθότητας λαβής, κρυπτογραφικών διπλοτύπων και αυτόματη απόρριψη μη φωτορεαλιστικών σχηματικών αρχείων.
            </p>
          </div>
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-5 border-t border-zinc-800 text-xs">
          <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
            <span className="text-zinc-500 block uppercase">Απορρίψεις (Failed)</span>
            <span className="text-xl font-bold font-mono text-rose-400 mt-0.5 block">{failedCount}</span>
            <span className="text-[11px] text-zinc-500">Περιλαμβάνει τα 6 canvas fixtures</span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
            <span className="text-zinc-500 block uppercase">Εγκεκριμένες Φωτογραφίες</span>
            <span className="text-xl font-bold font-mono text-emerald-400 mt-0.5 block">{passedCount}</span>
            <span className="text-[11px] text-zinc-500">Απαιτείται γνήσιο AI binary</span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
            <span className="text-zinc-500 block uppercase">Συγκρούσεις Διπλοτύπων</span>
            <span className="text-xl font-bold font-mono text-rose-400 mt-0.5 block">{duplicateCount}</span>
            <span className="text-[11px] text-zinc-500">Ταυτόσημα SHA-256 hashes</span>
          </div>

          <div className="p-3 rounded-lg bg-zinc-950 border border-zinc-800">
            <span className="text-zinc-500 block uppercase">Σε Αναμονή Ελέγχου</span>
            <span className="text-xl font-bold font-mono text-zinc-300 mt-0.5 block">{uninspectedCount}</span>
            <span className="text-[11px] text-zinc-500">Φάσεις χωρίς εικόνα ή QC</span>
          </div>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 text-xs overflow-x-auto pb-1">
        {(['all', 'failed', 'passed', 'uninspected'] as const).map((st) => (
          <button
            key={st}
            onClick={() => setQcFilter(st)}
            className={`px-3 py-1.5 rounded-lg border font-mono transition cursor-pointer capitalize ${
              qcFilter === st
                ? 'bg-zinc-800 text-amber-400 border-zinc-700'
                : 'bg-zinc-900/50 text-zinc-500 border-zinc-800/80 hover:text-zinc-300'
            }`}
          >
            {st === 'all' ? 'Όλες οι Φάσεις' : st}
          </button>
        ))}
      </div>

      {/* Auditing Table */}
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/50 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950 text-zinc-400 uppercase font-mono text-[11px] border-b border-zinc-800">
              <tr>
                <th className="p-3.5">Άσκηση & Φάση</th>
                <th className="p-3.5">Προέλευση</th>
                <th className="p-3.5">Κατάσταση QC</th>
                <th className="p-3.5">Ανατομικό Score</th>
                <th className="p-3.5">Εμβιομηχανικό Score</th>
                <th className="p-3.5">Ευρήματα & Σφάλματα</th>
                <th className="p-3.5">Ενέργειες</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-800/70">
              {filtered.map(({ exercise, phase }) => {
                const qc = phase.qcReport;
                let qcBadge = 'bg-zinc-800 text-zinc-400 border-zinc-700';
                if (qc.overallStatus === 'passed') {
                  qcBadge = 'bg-emerald-950 text-emerald-300 border-emerald-800';
                } else if (qc.overallStatus === 'failed') {
                  qcBadge = 'bg-rose-950 text-rose-300 border-rose-800';
                }

                return (
                  <tr key={phase.id} className="hover:bg-zinc-800/40 transition">
                    <td className="p-3.5">
                      <div className="font-semibold text-zinc-100">{exercise.english_name}</div>
                      <div className="text-[11px] text-amber-400 font-mono">
                        Φάση {phase.phaseNumber}: {phase.phaseName}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <span className="font-mono text-[10px] px-2 py-0.5 rounded bg-zinc-950 border border-zinc-800 text-zinc-300">
                        {phase.provenance.type}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${qcBadge}`}>
                        {qc.overallStatus.toUpperCase()}
                      </span>
                      {qc.isDuplicate && (
                        <div className="text-[10px] text-rose-400 font-mono mt-0.5">
                          DUPLICATE HASH
                        </div>
                      )}
                    </td>
                    <td className="p-3.5 font-mono text-zinc-300">
                      {qc.anatomicalScore > 0 ? `${qc.anatomicalScore}/100` : '-'}
                    </td>
                    <td className="p-3.5 font-mono text-zinc-300">
                      {qc.biomechanicalScore > 0 ? `${qc.biomechanicalScore}/100` : '-'}
                    </td>
                    <td className="p-3.5 max-w-xs text-[11px] text-zinc-400">
                      {qc.detectedIssues.length > 0 ? (
                        <span className="text-rose-300">{qc.detectedIssues[0]}</span>
                      ) : (
                        <span>{qc.verdictSummary}</span>
                      )}
                    </td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => onOpenPhase(exercise.id, phase.phaseNumber)}
                          className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-amber-400 border border-zinc-700 cursor-pointer"
                          title="Επιθεώρηση στο Studio"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {phase.outputPath && (
                          <button
                            onClick={() => handleAuditSingle(exercise.id, phase.phaseNumber)}
                            className="p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 cursor-pointer"
                            title="Επανέλεγχος Vision QC"
                          >
                            <RotateCw className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
