import React from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Cpu,
  Sparkles,
  Download,
  Play,
  RotateCcw,
} from 'lucide-react';
import { IntegrityDashboardStats } from '../types/pipeline';

interface HeaderProps {
  stats: IntegrityDashboardStats | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onRunTests: () => void;
  onReAudit: () => void;
  isRunningTests: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  stats,
  activeTab,
  setActiveTab,
  onRunTests,
  onReAudit,
  isRunningTests,
}) => {
  const isProduction = stats?.isProductionReady ?? false;
  const comfyOnline = stats?.comfyUiStatus?.online ?? false;
  const geminiAvailable = stats?.geminiStatus?.available ?? false;

  return (
    <header className="border-b border-zinc-800 bg-zinc-950/90 sticky top-0 z-50 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Logo & Identity */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-orange-600 flex items-center justify-center shadow-lg shadow-orange-950/40 border border-orange-400/30">
              <span className="text-zinc-950 font-black text-xl tracking-tighter">KF</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-zinc-100 tracking-tight">
                  KinesioForge AI Image Engine
                </h1>
                <span className="text-xs px-2 py-0.5 rounded-full font-mono bg-zinc-800 text-zinc-300 border border-zinc-700">
                  v2.4-hardened
                </span>
              </div>
              <p className="text-xs text-zinc-400">
                Sofia Personal Trainer Studio Biomechanical Pipeline & Authenticity Auditor
              </p>
            </div>
          </div>

          {/* Real-time Status Badges */}
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {/* Production Readiness Gate */}
            {isProduction ? (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-emerald-950/80 text-emerald-400 border border-emerald-800 font-medium">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>PRODUCTION READY</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-rose-950/80 text-rose-300 border border-rose-800/80 font-medium">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-400 animate-pulse" />
                <span>NOT PRODUCTION READY (0/64 Photos)</span>
              </div>
            )}

            {/* ComfyUI GPU Badge */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border font-medium ${
                comfyOnline
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-800'
                  : 'bg-zinc-900 text-zinc-400 border-zinc-800'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>ComfyUI RTX 3060: {comfyOnline ? 'ONLINE' : 'OFFLINE'}</span>
            </div>

            {/* Gemini API Badge */}
            <div
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md border font-medium ${
                geminiAvailable
                  ? 'bg-sky-950/60 text-sky-300 border-sky-800'
                  : 'bg-amber-950/60 text-amber-300 border-amber-800'
              }`}
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Gemini: {geminiAvailable ? 'ONLINE' : 'QUOTA / PENDING'}</span>
            </div>

            {/* Actions */}
            <button
              onClick={onRunTests}
              disabled={isRunningTests}
              className="flex items-center gap-1 px-3 py-1 bg-amber-500 hover:bg-amber-400 text-zinc-950 font-semibold rounded-md shadow transition disabled:opacity-50 cursor-pointer"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>{isRunningTests ? 'Testing...' : 'Run Tests A-H'}</span>
            </button>

            <button
              onClick={onReAudit}
              title="Audit disk files and compute sha256 hashes"
              className="p-1.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-md border border-zinc-700 transition cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 mt-4 overflow-x-auto border-t border-zinc-800/80 pt-2 text-xs scrollbar-thin">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'dashboard'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            📊 Πίνακας (Dashboard)
          </button>
          <button
            onClick={() => setActiveTab('exercises')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'exercises'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            🏋️ Βάση Ασκήσεων (11)
          </button>
          <button
            onClick={() => setActiveTab('studio')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'studio'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            🎬 Sequence Studio (64)
          </button>
          <button
            onClick={() => setActiveTab('queue')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'queue'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            ⚡ Ουρά Παραγωγής (Queue)
          </button>
          <button
            onClick={() => setActiveTab('qc')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'qc'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            🛡️ Έλεγχος Ποιότητας (QC)
          </button>
          <button
            onClick={() => setActiveTab('library')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'library'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            🖼️ Βιβλιοθήκη Εικόνων
          </button>
          <button
            onClick={() => setActiveTab('athletes')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'athletes'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            👤 Προφίλ Αθλητών
          </button>
          <button
            onClick={() => setActiveTab('comfyui')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'comfyui'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            🖥️ ComfyUI RTX 3060
          </button>
          <button
            onClick={() => setActiveTab('sofia')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'sofia'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            📦 Sofia Integration
          </button>
          <button
            onClick={() => setActiveTab('tests')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'tests'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            🧪 Δοκιμές (Tests A-R)
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-2.5 py-1.5 rounded-md font-medium transition cursor-pointer shrink-0 ${
              activeTab === 'settings'
                ? 'bg-zinc-800 text-amber-400 border border-zinc-700'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            ⚙️ Ρυθμίσεις & Workflows
          </button>
        </div>
      </div>
    </header>
  );
};
