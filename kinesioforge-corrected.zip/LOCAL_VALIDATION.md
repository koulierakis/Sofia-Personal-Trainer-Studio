# KinesioForge: inspected and corrected supplied archive

Original ZIP SHA256: 7dae8c8ec9ff93c352e8849e20a9a4a23240c6317b23c61d3daf0b0ffaa8fc42.
Source snapshot, not a Git repository. Original data/assets remain intact. Six PNG files are PROGRAMMATIC_SEED graphics, not exercise photos; phases 1 and 6 are identical. This package does not contain a working GPU model or a Gemini key.

Verified with Node 24 and Bun 1.4.3 frozen installation:
  npx --yes bun@1.4.3 install --frozen-lockfile
  npm run lint
  npm run build
  node --import tsx --test tests/safety.test.ts
  npm start

Eight new regression tests pass; the supplied API suite passed 25 checks. Fixture/mocked tests are NOT evidence of model execution. The genuine API pilot imported six Sofia prompts idempotently, but generation failed: ComfyUI fetch failed on 127.0.0.1:8188 and GEMINI_API_KEY is absent. No model IDs/seeds/outputs were fabricated.

Free local route: run ComfyUI on the same Windows computer with an actually installed checkpoint. Current official CLI supports --listen 127.0.0.1 --port 8188 --lowvram, not --medvram. --lowvram is a compatibility mode and may have no effect under dynamic VRAM; speed/memory suitability must be measured. Do not expose the service publicly or enable wildcard CORS. Studio listens only on loopback. This cloud machine cannot use the Windows machine's localhost.

Start ComfyUI, start this app, then Test Connection. Read actual availableCheckpoints. To configure queue jobs with an exact installed filename, POST /api/queue/settings JSON {"provider":"comfyui","concurrency":1,"checkpoint":"ACTUAL_INSTALLED_FILENAME.safetensors"}. This requires the model to be listed by the live server. Completed jobs are preserved. Alternatively the per-phase /generate API accepts checkpoint explicitly. Model aliases such as sdxl-base-1.0 are not installed checkpoint filenames.

Pilot data is derived only from authoritative Sofia functional-033 and mapped to engine ID sofia-functional-033. Import sofia-integration/pilot-catalog.json via the existing Sofia integration API/UI. Do not start full backlog production until all pilot phases execute, decode, differ where required and pass visual screening. Human approval remains separate. Engine default text-to-image prompts cannot guarantee anatomical correctness or athlete identity.

Export via /api/export/sofia with no fixtures parameter. Seeds are excluded by default; failed WebP conversion now aborts, and checksums bind to exported WebP bytes. Pass the ZIP through Sofia's images:kinesio audit/import commands with an explicitly reviewed ID/phase mapping. Never unzip directly over the Sofia repository. The supplied mapping template is pending and cannot be imported until actually reviewed. Do not change its review flags without checking the photographs.

No credentials are included. Gemini is optional: a genuine key must be supplied securely by its owner; no paid resources were provisioned. API model availability and quota remain unverified without authentication.

The corrected server reads .env.local then .env, without overriding injected process credentials. Keep credential files local and never include them in exports.
